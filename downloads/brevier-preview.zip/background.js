import { n as normalizeEntitlement, e as entitlementIsStale, T as TRIAL_DURATION_MS, i as isProEntitlement, F as FREE_ENTITLEMENT, g as gateSettings } from "./assets/entitlements-CH9aZEtA.js";
import { i as isPopupRequest, a as isOffscreenEvent, b as isContentMessage, e as errorMessage } from "./assets/messages-DlSg0HH_.js";
import { s as spokenLanguage, d as detectHunyuanRestricted } from "./assets/region-BGLr_vDp.js";
import { P as PRO_USAGE_KEY, n as normalizeUsage, l as loadSettings, r as remainingProMs, a as loadProUsage, b as addProUsage, s as saveProUsage } from "./assets/storage-CHoSrN8J.js";
function upsertCaption(history2, event, limit) {
  if (event.kind === "final" && event.lineId) {
    const index = history2.findIndex(
      (item) => item.kind === "final" && item.lineId === event.lineId
    );
    if (index >= 0) {
      const next = history2.slice();
      next[index] = { ...history2[index], ...event };
      return next;
    }
  }
  return [...history2, event].slice(-30);
}
var browserPolyfill$1 = { exports: {} };
var browserPolyfill = browserPolyfill$1.exports;
var hasRequiredBrowserPolyfill;
function requireBrowserPolyfill() {
  if (hasRequiredBrowserPolyfill) return browserPolyfill$1.exports;
  hasRequiredBrowserPolyfill = 1;
  (function(module, exports) {
    (function(global, factory) {
      {
        factory(module);
      }
    })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : browserPolyfill, function(module2) {
      if (typeof browser === "undefined" || Object.getPrototypeOf(browser) !== Object.prototype) {
        const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
        const SEND_RESPONSE_DEPRECATION_WARNING = "Returning a Promise is the preferred way to send a reply from an onMessage/onMessageExternal listener, as the sendResponse will be removed from the specs (See https://developer.mozilla.org/docs/Mozilla/Add-ons/WebExtensions/API/runtime/onMessage)";
        const wrapAPIs = (extensionAPIs) => {
          const apiMetadata = {
            "alarms": {
              "clear": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "clearAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "get": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "bookmarks": {
              "create": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getChildren": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getRecent": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getSubTree": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTree": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "move": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeTree": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "browserAction": {
              "disable": {
                "minArgs": 0,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "enable": {
                "minArgs": 0,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "getBadgeBackgroundColor": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getBadgeText": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getPopup": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTitle": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "openPopup": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "setBadgeBackgroundColor": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setBadgeText": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setIcon": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "setPopup": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setTitle": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "browsingData": {
              "remove": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "removeCache": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeCookies": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeDownloads": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeFormData": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeHistory": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeLocalStorage": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removePasswords": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removePluginData": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "settings": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "commands": {
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "contextMenus": {
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "cookies": {
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAllCookieStores": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "set": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "devtools": {
              "inspectedWindow": {
                "eval": {
                  "minArgs": 1,
                  "maxArgs": 2,
                  "singleCallbackArg": false
                }
              },
              "panels": {
                "create": {
                  "minArgs": 3,
                  "maxArgs": 3,
                  "singleCallbackArg": true
                },
                "elements": {
                  "createSidebarPane": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              }
            },
            "downloads": {
              "cancel": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "download": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "erase": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getFileIcon": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "open": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "pause": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeFile": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "resume": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "show": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "extension": {
              "isAllowedFileSchemeAccess": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "isAllowedIncognitoAccess": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "history": {
              "addUrl": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "deleteAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "deleteRange": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "deleteUrl": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getVisits": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "i18n": {
              "detectLanguage": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAcceptLanguages": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "identity": {
              "launchWebAuthFlow": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "idle": {
              "queryState": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "management": {
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getSelf": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "setEnabled": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "uninstallSelf": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "notifications": {
              "clear": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "create": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getPermissionLevel": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "pageAction": {
              "getPopup": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTitle": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "hide": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setIcon": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "setPopup": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setTitle": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "show": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "permissions": {
              "contains": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "request": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "runtime": {
              "getBackgroundPage": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getPlatformInfo": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "openOptionsPage": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "requestUpdateCheck": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "sendMessage": {
                "minArgs": 1,
                "maxArgs": 3
              },
              "sendNativeMessage": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "setUninstallURL": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "sessions": {
              "getDevices": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getRecentlyClosed": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "restore": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "storage": {
              "local": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "managed": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "sync": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              }
            },
            "tabs": {
              "captureVisibleTab": {
                "minArgs": 0,
                "maxArgs": 2
              },
              "create": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "detectLanguage": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "discard": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "duplicate": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "executeScript": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getCurrent": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getZoom": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getZoomSettings": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "goBack": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "goForward": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "highlight": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "insertCSS": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "move": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "query": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "reload": {
                "minArgs": 0,
                "maxArgs": 2
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeCSS": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "sendMessage": {
                "minArgs": 2,
                "maxArgs": 3
              },
              "setZoom": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "setZoomSettings": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "update": {
                "minArgs": 1,
                "maxArgs": 2
              }
            },
            "topSites": {
              "get": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "webNavigation": {
              "getAllFrames": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getFrame": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "webRequest": {
              "handlerBehaviorChanged": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "windows": {
              "create": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getCurrent": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getLastFocused": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            }
          };
          if (Object.keys(apiMetadata).length === 0) {
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          }
          class DefaultWeakMap extends WeakMap {
            constructor(createItem, items = void 0) {
              super(items);
              this.createItem = createItem;
            }
            get(key) {
              if (!this.has(key)) {
                this.set(key, this.createItem(key));
              }
              return super.get(key);
            }
          }
          const isThenable = (value) => {
            return value && typeof value === "object" && typeof value.then === "function";
          };
          const makeCallback = (promise, metadata) => {
            return (...callbackArgs) => {
              if (extensionAPIs.runtime.lastError) {
                promise.reject(extensionAPIs.runtime.lastError);
              } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                promise.resolve(callbackArgs[0]);
              } else {
                promise.resolve(callbackArgs);
              }
            };
          };
          const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
          const wrapAsyncFunction = (name, metadata) => {
            return function asyncFunctionWrapper(target, ...args) {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                if (metadata.fallbackToNoCallback) {
                  try {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  } catch (cbError) {
                    console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                    target[name](...args);
                    metadata.fallbackToNoCallback = false;
                    metadata.noCallback = true;
                    resolve();
                  }
                } else if (metadata.noCallback) {
                  target[name](...args);
                  resolve();
                } else {
                  target[name](...args, makeCallback({
                    resolve,
                    reject
                  }, metadata));
                }
              });
            };
          };
          const wrapMethod = (target, method, wrapper) => {
            return new Proxy(method, {
              apply(targetMethod, thisObj, args) {
                return wrapper.call(thisObj, target, ...args);
              }
            });
          };
          let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
          const wrapObject = (target, wrappers = {}, metadata = {}) => {
            let cache = /* @__PURE__ */ Object.create(null);
            let handlers = {
              has(proxyTarget2, prop) {
                return prop in target || prop in cache;
              },
              get(proxyTarget2, prop, receiver) {
                if (prop in cache) {
                  return cache[prop];
                }
                if (!(prop in target)) {
                  return void 0;
                }
                let value = target[prop];
                if (typeof value === "function") {
                  if (typeof wrappers[prop] === "function") {
                    value = wrapMethod(target, target[prop], wrappers[prop]);
                  } else if (hasOwnProperty(metadata, prop)) {
                    let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                    value = wrapMethod(target, target[prop], wrapper);
                  } else {
                    value = value.bind(target);
                  }
                } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                  value = wrapObject(value, wrappers[prop], metadata[prop]);
                } else if (hasOwnProperty(metadata, "*")) {
                  value = wrapObject(value, wrappers[prop], metadata["*"]);
                } else {
                  Object.defineProperty(cache, prop, {
                    configurable: true,
                    enumerable: true,
                    get() {
                      return target[prop];
                    },
                    set(value2) {
                      target[prop] = value2;
                    }
                  });
                  return value;
                }
                cache[prop] = value;
                return value;
              },
              set(proxyTarget2, prop, value, receiver) {
                if (prop in cache) {
                  cache[prop] = value;
                } else {
                  target[prop] = value;
                }
                return true;
              },
              defineProperty(proxyTarget2, prop, desc) {
                return Reflect.defineProperty(cache, prop, desc);
              },
              deleteProperty(proxyTarget2, prop) {
                return Reflect.deleteProperty(cache, prop);
              }
            };
            let proxyTarget = Object.create(target);
            return new Proxy(proxyTarget, handlers);
          };
          const wrapEvent = (wrapperMap) => ({
            addListener(target, listener, ...args) {
              target.addListener(wrapperMap.get(listener), ...args);
            },
            hasListener(target, listener) {
              return target.hasListener(wrapperMap.get(listener));
            },
            removeListener(target, listener) {
              target.removeListener(wrapperMap.get(listener));
            }
          });
          let loggedSendResponseDeprecationWarning = false;
          const onMessageWrappers = new DefaultWeakMap((listener) => {
            if (typeof listener !== "function") {
              return listener;
            }
            return function onMessage(message, sender, sendResponse) {
              let didCallSendResponse = false;
              let wrappedSendResponse;
              let sendResponsePromise = new Promise((resolve) => {
                wrappedSendResponse = function(response) {
                  if (!loggedSendResponseDeprecationWarning) {
                    console.warn(SEND_RESPONSE_DEPRECATION_WARNING, new Error().stack);
                    loggedSendResponseDeprecationWarning = true;
                  }
                  didCallSendResponse = true;
                  resolve(response);
                };
              });
              let result;
              try {
                result = listener(message, sender, wrappedSendResponse);
              } catch (err) {
                result = Promise.reject(err);
              }
              const isResultThenable = result !== true && isThenable(result);
              if (result !== true && !isResultThenable && !didCallSendResponse) {
                return false;
              }
              const sendPromisedResult = (promise) => {
                promise.then((msg) => {
                  sendResponse(msg);
                }, (error) => {
                  let message2;
                  if (error && (error instanceof Error || typeof error.message === "string")) {
                    message2 = error.message;
                  } else {
                    message2 = "An unexpected error occurred";
                  }
                  sendResponse({
                    __mozWebExtensionPolyfillReject__: true,
                    message: message2
                  });
                }).catch((err) => {
                  console.error("Failed to send onMessage rejected reply", err);
                });
              };
              if (isResultThenable) {
                sendPromisedResult(result);
              } else {
                sendPromisedResult(sendResponsePromise);
              }
              return true;
            };
          });
          const wrappedSendMessageCallback = ({
            reject,
            resolve
          }, reply) => {
            if (extensionAPIs.runtime.lastError) {
              if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                resolve();
              } else {
                reject(extensionAPIs.runtime.lastError);
              }
            } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
              reject(new Error(reply.message));
            } else {
              resolve(reply);
            }
          };
          const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
            if (args.length < metadata.minArgs) {
              throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
            }
            if (args.length > metadata.maxArgs) {
              throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
            }
            return new Promise((resolve, reject) => {
              const wrappedCb = wrappedSendMessageCallback.bind(null, {
                resolve,
                reject
              });
              args.push(wrappedCb);
              apiNamespaceObj.sendMessage(...args);
            });
          };
          const staticWrappers = {
            runtime: {
              onMessage: wrapEvent(onMessageWrappers),
              onMessageExternal: wrapEvent(onMessageWrappers),
              sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          };
          const settingMetadata = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          apiMetadata.privacy = {
            network: {
              "*": settingMetadata
            },
            services: {
              "*": settingMetadata
            },
            websites: {
              "*": settingMetadata
            }
          };
          return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
        };
        if (typeof chrome != "object" || !chrome || !chrome.runtime || !chrome.runtime.id) {
          throw new Error("This script should only be loaded in a browser extension.");
        }
        module2.exports = wrapAPIs(chrome);
      } else {
        module2.exports = browser;
      }
    });
  })(browserPolyfill$1);
  return browserPolyfill$1.exports;
}
var browserPolyfillExports = requireBrowserPolyfill();
if (typeof window !== "undefined") {
  window.addEventListener("message", (event) => {
    if (event.origin !== "https://extensionpay.com") return;
    if (event.source != window) return;
    if (event.data === "extpay-fetch-user" || event.data === "extpay-trial-start") {
      window.postMessage(`${event.data}-received`);
      browserPolyfillExports.runtime.sendMessage(event.data);
    }
  }, false);
}
function ExtPay(extension_id) {
  const HOST = `https://extensionpay.com`;
  const EXTENSION_URL = `${HOST}/extension/${extension_id}`;
  function timeout(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  async function get(key) {
    try {
      return await browserPolyfillExports.storage.sync.get(key);
    } catch (e) {
      return await browserPolyfillExports.storage.local.get(key);
    }
  }
  async function set(dict) {
    try {
      return await browserPolyfillExports.storage.sync.set(dict);
    } catch (e) {
      return await browserPolyfillExports.storage.local.set(dict);
    }
  }
  browserPolyfillExports.management && browserPolyfillExports.management.getSelf().then(async (ext_info) => {
    if (!ext_info.permissions.includes("storage")) {
      var permissions = ext_info.hostPermissions.concat(ext_info.permissions);
      throw `ExtPay Setup Error: please include the "storage" permission in manifest.json["permissions"] or else ExtensionPay won't work correctly.

You can copy and paste this to your manifest.json file to fix this error:

"permissions": [
    ${permissions.map((x) => `"    ${x}"`).join(",\n")}${permissions.length > 0 ? "," : ""}
    "storage"
]
`;
    }
  });
  get(["extensionpay_installed_at", "extensionpay_user"]).then(async (storage) => {
    if (storage.extensionpay_installed_at) return;
    const user = storage.extensionpay_user;
    const date = user ? user.installedAt : (/* @__PURE__ */ new Date()).toISOString();
    await set({ "extensionpay_installed_at": date });
  });
  const paid_callbacks = [];
  const trial_callbacks = [];
  async function create_key() {
    var body = {};
    var ext_info;
    if (browserPolyfillExports.management) {
      ext_info = await browserPolyfillExports.management.getSelf();
    } else if (browserPolyfillExports.runtime) {
      ext_info = await browserPolyfillExports.runtime.sendMessage("extpay-extinfo");
      if (!ext_info) {
        const is_dev_mode = !("update_url" in browserPolyfillExports.runtime.getManifest());
        ext_info = { installType: is_dev_mode ? "development" : "normal" };
      }
    } else {
      throw "ExtPay needs to be run in a browser extension context";
    }
    if (ext_info.installType == "development") {
      body.development = true;
    }
    const resp = await fetch(`${EXTENSION_URL}/api/new-key`, {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "Content-type": "application/json"
      },
      body: JSON.stringify(body)
    });
    if (!resp.ok) {
      throw resp.status, `${HOST}/home`;
    }
    const api_key = await resp.json();
    await set({ extensionpay_api_key: api_key });
    return api_key;
  }
  async function get_key() {
    const storage = await get(["extensionpay_api_key"]);
    if (storage.extensionpay_api_key) {
      return storage.extensionpay_api_key;
    }
    return null;
  }
  const datetime_re = /^\d\d\d\d-\d\d-\d\dT/;
  async function fetch_user() {
    var storage = await get(["extensionpay_user", "extensionpay_installed_at"]);
    const api_key = await get_key();
    if (!api_key) {
      return {
        paid: false,
        paidAt: null,
        installedAt: storage.extensionpay_installed_at ? new Date(storage.extensionpay_installed_at) : /* @__PURE__ */ new Date(),
        // sometimes this function gets called before the initial install time can be flushed to storage
        trialStartedAt: null
      };
    }
    const resp = await fetch(`${EXTENSION_URL}/api/v2/user?api_key=${api_key}`, {
      method: "GET",
      headers: {
        "Accept": "application/json"
      }
    });
    if (!resp.ok) throw "ExtPay error while fetching user: " + await resp.text();
    const user_data = await resp.json();
    const parsed_user = {};
    for (var [key, value] of Object.entries(user_data)) {
      if (value && value.match && value.match(datetime_re)) {
        value = new Date(value);
      }
      parsed_user[key] = value;
    }
    parsed_user.installedAt = new Date(storage.extensionpay_installed_at);
    if (parsed_user.paidAt) {
      if (!storage.extensionpay_user || storage.extensionpay_user && !storage.extensionpay_user.paidAt) {
        paid_callbacks.forEach((cb) => cb(parsed_user));
      }
    }
    if (parsed_user.trialStartedAt) {
      if (!storage.extensionpay_user || storage.extensionpay_user && !storage.extensionpay_user.trialStartedAt) {
        trial_callbacks.forEach((cb) => cb(parsed_user));
      }
    }
    await set({ extensionpay_user: user_data });
    return parsed_user;
  }
  async function get_plans() {
    const resp = await fetch(`${EXTENSION_URL}/api/v2/current-plans`, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-type": "application/json"
      }
    });
    if (!resp.ok) {
      throw `ExtPay: HTTP error while getting plans. Received http code: ${resp.status}`;
    }
    return await resp.json();
  }
  async function open_popup(url, width, height) {
    if (browserPolyfillExports.windows && browserPolyfillExports.windows.create) {
      const current_window = await browserPolyfillExports.windows.getCurrent();
      const left = Math.round((current_window.width - width) * 0.5 + current_window.left);
      const top = Math.round((current_window.height - height) * 0.5 + current_window.top);
      try {
        browserPolyfillExports.windows.create({
          url,
          type: "popup",
          focused: true,
          width,
          height,
          left,
          top
        });
      } catch (e) {
        browserPolyfillExports.windows.create({
          url,
          type: "popup",
          width,
          height,
          left,
          top
        });
      }
    } else {
      window.open(url, null, `toolbar=no,location=no,directories=no,status=no,menubar=no,width=${width},height=${height},left=450`);
    }
  }
  async function open_payment_page(plan_nickname) {
    var api_key = await get_key();
    if (!api_key) {
      api_key = await create_key();
    }
    let url = `${EXTENSION_URL}/choose-plan?api_key=${api_key}`;
    if (plan_nickname) {
      url = `${EXTENSION_URL}/choose-plan/${plan_nickname}?api_key=${api_key}`;
    }
    if (browserPolyfillExports.tabs && browserPolyfillExports.tabs.create) {
      await browserPolyfillExports.tabs.create({ url, active: true });
    } else {
      window.open(url, "_blank");
    }
  }
  async function open_trial_page(period) {
    var api_key = await get_key();
    if (!api_key) {
      api_key = await create_key();
    }
    var url = `${EXTENSION_URL}/trial?api_key=${api_key}`;
    if (period) {
      url += `&period=${period}`;
    }
    open_popup(url, 500, 700);
  }
  async function open_login_page() {
    var api_key = await get_key();
    if (!api_key) {
      api_key = await create_key();
    }
    const url = `${EXTENSION_URL}/reactivate?api_key=${api_key}&back=choose-plan&v2`;
    open_popup(url, 500, 800);
  }
  var polling = false;
  async function poll_user_paid() {
    if (polling) return;
    polling = true;
    var user = await fetch_user();
    for (var i = 0; i < 2 * 60; ++i) {
      if (user.paidAt) {
        polling = false;
        return user;
      }
      await timeout(1e3);
      user = await fetch_user();
    }
    polling = false;
  }
  return {
    getUser: function() {
      return fetch_user();
    },
    onPaid: {
      addListener: function(callback) {
        const content_script_template = `"content_scripts": [
                {
            "matches": ["${HOST}/*"],
            "js": ["ExtPay.js"],
            "run_at": "document_start"
        }]`;
        const manifest = browserPolyfillExports.runtime.getManifest();
        if (!manifest.content_scripts) {
          throw `ExtPay setup error: To use the onPaid callback handler, please include ExtPay as a content script in your manifest.json. You can copy the example below into your manifest.json or check the docs: https://github.com/Glench/ExtPay#2-configure-your-manifestjson

        ${content_script_template}`;
        }
        const extpay_content_script_entry = manifest.content_scripts.find((obj) => {
          return obj.matches.includes(HOST.replace(":3000", "") + "/*");
        });
        if (!extpay_content_script_entry) {
          throw `ExtPay setup error: To use the onPaid callback handler, please include ExtPay as a content script in your manifest.json matching "${HOST}/*". You can copy the example below into your manifest.json or check the docs: https://github.com/Glench/ExtPay#2-configure-your-manifestjson

        ${content_script_template}`;
        } else {
          if (!extpay_content_script_entry.run_at || extpay_content_script_entry.run_at !== "document_start") {
            throw `ExtPay setup error: To use the onPaid callback handler, please make sure the ExtPay content script in your manifest.json runs at document start. You can copy the example below into your manifest.json or check the docs: https://github.com/Glench/ExtPay#2-configure-your-manifestjson

        ${content_script_template}`;
          }
        }
        paid_callbacks.push(callback);
      }
      // removeListener: function(callback) {
      //     // TODO
      // }
    },
    getPlans: get_plans,
    openPaymentPage: open_payment_page,
    openTrialPage: open_trial_page,
    openLoginPage: open_login_page,
    onTrialStarted: {
      addListener: function(callback) {
        trial_callbacks.push(callback);
      }
    },
    startBackground: function() {
      browserPolyfillExports.runtime.onMessage.addListener(function(message, sender, send_response) {
        if (message == "extpay-fetch-user") {
          poll_user_paid();
        } else if (message == "extpay-trial-start") {
          fetch_user();
        } else if (message == "extpay-extinfo" && browserPolyfillExports.management) {
          return browserPolyfillExports.management.getSelf();
        }
      });
    }
  };
}
const EXTENSIONPAY_ID = "brevier";
const STORAGE_KEY = "entitlement";
let client = null;
function getClient() {
  client ??= ExtPay(EXTENSIONPAY_ID);
  return client;
}
function toEntitlement(user, now) {
  const trialStartedAt = user.trialStartedAt ? user.trialStartedAt.getTime() : null;
  const trialing = !user.paid && trialStartedAt !== null && now - trialStartedAt < TRIAL_DURATION_MS;
  return {
    status: user.paid ? "pro" : trialing ? "trial" : "free",
    source: "extpay",
    checkedAt: now,
    trialStartedAt,
    email: user.email ?? null
  };
}
class ExtPayEntitlementProvider {
  constructor(pay) {
    this.pay = pay;
  }
  supportsPurchases = true;
  async get() {
    const stored = await chrome.storage.local.get(STORAGE_KEY);
    return normalizeEntitlement(stored[STORAGE_KEY]);
  }
  async refresh(force = false) {
    const current = await this.get();
    if (!force && !entitlementIsStale(current)) return current;
    try {
      const user = await this.pay.getUser();
      const next = toEntitlement(user, Date.now());
      await chrome.storage.local.set({ [STORAGE_KEY]: next });
      return next;
    } catch {
      return current;
    }
  }
  async listPlans() {
    const plans = await this.pay.getPlans();
    return plans.map((plan) => ({
      nickname: typeof plan.nickname === "string" ? plan.nickname : null,
      unitAmountCents: plan.unitAmountCents,
      currency: plan.currency,
      interval: plan.interval ?? null,
      intervalCount: plan.intervalCount ?? null
    }));
  }
  async openUpgrade(planNickname) {
    await this.pay.openPaymentPage(planNickname);
  }
  async openLogin() {
    await this.pay.openLoginPage();
  }
}
function createExtPayProvider() {
  const pay = getClient();
  pay.startBackground();
  return new ExtPayEntitlementProvider(pay);
}
async function createEntitlementProvider() {
  return createExtPayProvider();
}
const OFFSCREEN_URL = "offscreen/offscreen.html";
const CAPTURED_TAB_KEY = "capturedTabId";
const SESSION_PRO_KEY = "sessionPro";
const USAGE_FLUSH_MS = 3e4;
const BADGE_COLOR = "#dc2626";
const DEFAULT_TITLE = "Brevier";
const ACTIVE_TITLE = "Brevier — captions are ON";
async function rememberCapturedTab(tabId) {
  try {
    if (tabId === null) {
      await chrome.storage.session.remove(CAPTURED_TAB_KEY);
    } else {
      await chrome.storage.session.set({ [CAPTURED_TAB_KEY]: tabId });
    }
  } catch {
  }
}
async function getRememberedTab() {
  try {
    const stored = await chrome.storage.session.get(CAPTURED_TAB_KEY);
    const value = stored[CAPTURED_TAB_KEY];
    return typeof value === "number" ? value : null;
  } catch {
    return null;
  }
}
async function rememberSessionPro(active) {
  try {
    if (active) {
      await chrome.storage.session.set({ [SESSION_PRO_KEY]: true });
    } else {
      await chrome.storage.session.remove(SESSION_PRO_KEY);
    }
  } catch {
  }
}
async function getRememberedSessionPro() {
  try {
    const stored = await chrome.storage.session.get(SESSION_PRO_KEY);
    return stored[SESSION_PRO_KEY] === true;
  } catch {
    return false;
  }
}
let state = {
  capturing: false,
  status: "idle",
  detail: "Idle",
  progress: null,
  error: null,
  tabId: null,
  engine: "moonshine",
  language: "en",
  audioLevel: 0,
  captionCount: 0,
  lastCaptionAt: null,
  translationStatus: "off",
  translationDetail: "",
  proAllowanceMsLeft: null
};
let history = [];
let starting = false;
let initialized = false;
let entitlementProvider = null;
function provider() {
  entitlementProvider ??= createEntitlementProvider();
  return entitlementProvider;
}
async function currentEntitlement() {
  try {
    return await (await provider()).get();
  } catch {
    return FREE_ENTITLEMENT;
  }
}
async function refreshedEntitlement(force = false) {
  try {
    return await (await provider()).refresh(force);
  } catch {
    return currentEntitlement();
  }
}
let proUsage = null;
let proUsageDirty = false;
let proUsageFlushedAt = 0;
let meterChain = Promise.resolve();
let lastMeterAt = 0;
let sessionMetering = false;
async function currentProUsage() {
  proUsage ??= await loadProUsage();
  return proUsage;
}
function usesProFeatures(settings) {
  return spokenLanguage(settings) !== "en" || settings.translation.enabled && settings.translation.provider === "hunyuan";
}
async function allowanceMsLeft() {
  const entitlement = await currentEntitlement();
  if (isProEntitlement(entitlement)) return null;
  return remainingProMs(await currentProUsage());
}
async function flushProUsage(force = false) {
  if (proUsage === null || !proUsageDirty) return;
  if (!force && Date.now() - proUsageFlushedAt < USAGE_FLUSH_MS) return;
  proUsageFlushedAt = Date.now();
  proUsageDirty = false;
  try {
    await saveProUsage(proUsage);
  } catch {
    proUsageDirty = true;
  }
}
function minutesCeil(ms) {
  return Math.ceil(ms / 6e4);
}
async function meterTick() {
  if (!state.capturing || !sessionMetering) {
    lastMeterAt = Date.now();
    return;
  }
  const now = Date.now();
  const delta = now - lastMeterAt;
  lastMeterAt = now;
  if (delta <= 0) return;
  const current = await currentProUsage();
  const before = remainingProMs(current, now);
  proUsage = addProUsage(current, delta, now);
  proUsageDirty = true;
  const after = remainingProMs(proUsage, now);
  if (minutesCeil(before) !== minutesCeil(after)) {
    state = { ...state, proAllowanceMsLeft: after };
    broadcastState();
  }
  await flushProUsage();
}
function meterProUsage() {
  meterChain = meterChain.then(meterTick).catch(() => {
  });
}
async function finalizeMetering() {
  await meterTick();
  sessionMetering = false;
  await flushProUsage(true);
}
async function refreshAllowanceState() {
  const left = await allowanceMsLeft();
  if (state.proAllowanceMsLeft === left) return;
  state = { ...state, proAllowanceMsLeft: left };
  broadcastState();
}
async function effectiveSettings(settings, proOverride) {
  const entitlement = await currentEntitlement();
  const paid = isProEntitlement(entitlement);
  const allowance = !paid && remainingProMs(await currentProUsage()) > 0;
  const pro = proOverride ?? (paid || allowance);
  const gated = gateSettings(settings, pro, !detectHunyuanRestricted());
  return {
    settings: gated.settings,
    gateNotice: gated.notice,
    pro,
    viaAllowance: pro && !paid
  };
}
function broadcastState() {
  syncActionIndicator();
  void chrome.runtime.sendMessage({ type: "bg:state", state }).catch(() => {
  });
}
let badgedTabId = null;
let indicatorChain = Promise.resolve();
async function clearActionBadge(tabId) {
  try {
    await chrome.action.setBadgeText({ text: "", tabId });
    await chrome.action.setTitle({ title: DEFAULT_TITLE, tabId });
  } catch {
  }
}
async function applyActionIndicator() {
  const next = state.capturing ? state.tabId : null;
  const previous = badgedTabId;
  if (previous === next) return;
  badgedTabId = next;
  if (previous !== null) await clearActionBadge(previous);
  if (next === null) return;
  try {
    await chrome.action.setBadgeText({ text: "ON", tabId: next });
    await chrome.action.setBadgeBackgroundColor({ color: BADGE_COLOR, tabId: next });
    await chrome.action.setTitle({ title: ACTIVE_TITLE, tabId: next });
  } catch {
  }
}
function syncActionIndicator() {
  indicatorChain = indicatorChain.then(applyActionIndicator).catch(() => {
  });
}
async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: [chrome.runtime.ContextType.OFFSCREEN_DOCUMENT]
  });
  return contexts.length > 0;
}
function getTabStreamId(tabId) {
  return new Promise((resolve, reject) => {
    chrome.tabCapture.getMediaStreamId({ targetTabId: tabId }, (streamId) => {
      const error = chrome.runtime.lastError;
      if (error) {
        reject(new Error(error.message));
        return;
      }
      resolve(streamId);
    });
  });
}
async function ensureOffscreenDocument() {
  if (await hasOffscreenDocument()) return;
  await chrome.offscreen.createDocument({
    url: OFFSCREEN_URL,
    reasons: [chrome.offscreen.Reason.USER_MEDIA, chrome.offscreen.Reason.WORKERS],
    justification: "Capture tab audio and run the speech recognition engine"
  });
}
async function closeOffscreenDocument() {
  try {
    if (await hasOffscreenDocument()) {
      await chrome.offscreen.closeDocument();
    }
  } catch {
  }
}
async function sendToOffscreen(message) {
  try {
    return await chrome.runtime.sendMessage(message);
  } catch (error) {
    console.warn("[brevier] offscreen message failed", error);
    return null;
  }
}
async function sendToTab(tabId, message) {
  try {
    await chrome.tabs.sendMessage(tabId, message);
    return true;
  } catch {
    return false;
  }
}
async function bindContentWithRetry(tabId, active, settings, attempts = 3) {
  for (let attempt = 0; attempt < attempts; attempt++) {
    const delivered = await sendToTab(tabId, {
      type: "content:bind",
      active,
      settings,
      history
    });
    if (delivered) return;
    await new Promise((resolve) => setTimeout(resolve, 300));
  }
}
const INTERNAL_PAGE = /^(chrome|chrome-extension|chrome-untrusted|devtools|edge|about|view-source):/i;
function explainCaptureFailure(error) {
  const message = errorMessage(error);
  if (/error starting tab capture/i.test(message)) {
    return "Chrome refused to capture this tab. Tab audio can only be captured on regular websites (http/https) — not on chrome:// pages, extension pages, the Web Store, or DevTools. Open the site that is playing audio and click Start again.";
  }
  return message;
}
async function startCapture() {
  if (starting || state.capturing) return;
  starting = true;
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (tab?.id === void 0) {
      throw new Error("No active tab to capture.");
    }
    const tabUrl = tab.url ?? tab.pendingUrl ?? "";
    if (tabUrl && INTERNAL_PAGE.test(tabUrl)) {
      throw new Error(
        "Captions cannot be added to this page. Open the website that is playing audio (a video or call tab, for example) and click Start there."
      );
    }
    const settings = await loadSettings();
    const effective = await effectiveSettings(settings);
    state = {
      ...state,
      status: "starting",
      detail: "Requesting tab audio…",
      error: null,
      engine: effective.settings.engine,
      language: spokenLanguage(effective.settings),
      audioLevel: 0,
      captionCount: 0,
      lastCaptionAt: null,
      translationStatus: effective.settings.translation.enabled ? "loading" : "off",
      translationDetail: "",
      gateNotice: effective.gateNotice,
      proAllowanceMsLeft: await allowanceMsLeft()
    };
    broadcastState();
    let streamId;
    try {
      streamId = await getTabStreamId(tab.id);
    } catch (error) {
      throw new Error(explainCaptureFailure(error));
    }
    await ensureOffscreenDocument();
    sessionMetering = effective.viaAllowance && usesProFeatures(effective.settings);
    lastMeterAt = Date.now();
    state = { ...state, capturing: true, tabId: tab.id, detail: "Starting…" };
    await rememberCapturedTab(tab.id);
    await rememberSessionPro(sessionMetering);
    broadcastState();
    const response = await sendToOffscreen({
      type: "offscreen:start",
      target: "offscreen",
      streamId,
      settings: effective.settings
    });
    if (!response) {
      throw new Error("The audio pipeline did not start (offscreen document unavailable).");
    }
    await bindContentWithRetry(tab.id, true, effective.settings);
  } catch (error) {
    const message = errorMessage(error);
    state = {
      ...state,
      capturing: false,
      status: "error",
      detail: message,
      error: message,
      progress: null
    };
    sessionMetering = false;
    await rememberCapturedTab(null);
    await rememberSessionPro(false);
    await closeOffscreenDocument();
    await flushProUsage(true);
  } finally {
    starting = false;
    broadcastState();
  }
}
async function stopCapture() {
  while (starting) {
    await new Promise((resolve) => setTimeout(resolve, 50));
  }
  const tabId = state.tabId;
  await finalizeMetering();
  await rememberSessionPro(false);
  const allowanceLeft = await allowanceMsLeft();
  history = [];
  state = {
    ...state,
    capturing: false,
    status: "idle",
    detail: "Idle",
    progress: null,
    error: null,
    tabId: null,
    audioLevel: 0,
    captionCount: 0,
    lastCaptionAt: null,
    translationStatus: "off",
    translationDetail: "",
    gateNotice: null,
    proAllowanceMsLeft: allowanceLeft
  };
  await rememberCapturedTab(null);
  broadcastState();
  await sendToOffscreen({ type: "offscreen:stop", target: "offscreen" });
  await closeOffscreenDocument();
  if (tabId !== null) {
    await sendToTab(tabId, { type: "content:unbind" });
  }
}
async function applySettingsChange() {
  const settings = await loadSettings();
  const grace = state.capturing && sessionMetering;
  const effective = await effectiveSettings(settings, grace ? true : void 0);
  if (state.capturing) {
    sessionMetering = effective.viaAllowance && usesProFeatures(effective.settings);
    lastMeterAt = Date.now();
    await rememberSessionPro(sessionMetering);
  }
  state = {
    ...state,
    engine: effective.settings.engine,
    language: spokenLanguage(effective.settings),
    gateNotice: effective.gateNotice,
    proAllowanceMsLeft: await allowanceMsLeft()
  };
  broadcastState();
  if (state.capturing) {
    await sendToOffscreen({
      type: "offscreen:update-settings",
      target: "offscreen",
      settings: effective.settings
    });
    if (state.tabId !== null) {
      await sendToTab(state.tabId, { type: "content:settings", settings: effective.settings });
    }
  }
}
function explainPurchaseFailure(error) {
  const message = errorMessage(error);
  if (/^\d{3}$/.test(message)) {
    return `The payment service answered HTTP ${message}. Check that this build's ExtensionPay ID matches the extension registered on extensionpay.com.`;
  }
  return `Could not open the payment page: ${message}`;
}
async function openPurchasePage(action, planNickname) {
  try {
    const entitlements = await provider();
    if (!entitlements.supportsPurchases) {
      return { ok: false, error: "Purchases are disabled in development builds." };
    }
    if (action === "upgrade") await entitlements.openUpgrade(planNickname);
    else await entitlements.openLogin();
    return { ok: true };
  } catch (error) {
    console.error("[brevier] opening the payment page failed", error);
    return { ok: false, error: explainPurchaseFailure(error) };
  }
}
async function handlePopupRequest(request) {
  await recoverState();
  switch (request.type) {
    case "popup:start":
      await startCapture();
      return { ok: true, state };
    case "popup:stop":
      await stopCapture();
      return { ok: true, state };
    case "popup:get-state":
      return { ok: true, state };
    case "popup:settings-changed":
      await applySettingsChange();
      return { ok: true, state };
    case "popup:get-entitlement": {
      const entitlements = await provider();
      const entitlement = await refreshedEntitlement(true);
      return {
        ok: true,
        entitlement,
        supportsPurchases: entitlements.supportsPurchases,
        proAllowanceMsLeft: await allowanceMsLeft(),
        plans: isProEntitlement(entitlement) ? [] : await entitlements.listPlans().catch(() => [])
      };
    }
    case "popup:open-upgrade":
      return openPurchasePage("upgrade", request.plan);
    case "popup:open-login":
      return openPurchasePage("login");
  }
}
function handleOffscreenEvent(message) {
  switch (message.type) {
    case "offscreen:status": {
      if (message.status === "error") {
        const tabId = state.tabId;
        const error = message.error ?? message.detail ?? "Transcription engine error";
        state = {
          ...state,
          capturing: false,
          tabId: null,
          status: "error",
          detail: error,
          error,
          progress: null,
          translationStatus: "off",
          translationDetail: ""
        };
        sessionMetering = false;
        broadcastState();
        void rememberCapturedTab(null);
        void rememberSessionPro(false);
        void flushProUsage(true);
        void refreshAllowanceState();
        if (tabId !== null) {
          void sendToTab(tabId, { type: "content:unbind" });
        }
        void closeOffscreenDocument();
        break;
      }
      state = {
        ...state,
        status: message.status,
        detail: message.detail ?? state.detail,
        error: null,
        progress: message.status === "ready" ? null : state.progress
      };
      broadcastState();
      break;
    }
    case "offscreen:progress":
      state = { ...state, progress: message.progress };
      broadcastState();
      break;
    case "offscreen:audio":
      if (typeof message.level !== "number") break;
      state = { ...state, audioLevel: message.level };
      meterProUsage();
      broadcastState();
      break;
    case "offscreen:translation":
      state = {
        ...state,
        translationStatus: message.status,
        translationDetail: message.detail
      };
      broadcastState();
      break;
    case "offscreen:caption": {
      if (message.event.kind === "final") {
        const isUpdate = message.event.lineId !== void 0 && history.some(
          (item) => item.kind === "final" && item.lineId === message.event.lineId
        );
        history = upsertCaption(history, message.event);
        state = {
          ...state,
          captionCount: isUpdate ? state.captionCount : state.captionCount + 1,
          lastCaptionAt: message.event.at
        };
      } else {
        state = { ...state, lastCaptionAt: message.event.at };
      }
      if (state.tabId !== null) {
        void sendToTab(state.tabId, { type: "content:caption", event: message.event });
      }
      broadcastState();
      break;
    }
  }
}
async function handleContentReady(sender) {
  await recoverState();
  const tabId = sender.tab?.id;
  if (tabId === void 0) return { ok: false };
  const settings = await loadSettings();
  const active = state.capturing && state.tabId === tabId;
  await sendToTab(tabId, { type: "content:bind", active, settings, history });
  return { ok: true, active };
}
async function recoverState() {
  if (initialized) return;
  initialized = true;
  try {
    const remembered = await getRememberedTab();
    if (!await hasOffscreenDocument()) {
      if (remembered !== null) {
        await clearActionBadge(remembered);
        await rememberCapturedTab(null);
      }
      await refreshAllowanceState();
      return;
    }
    const response = await sendToOffscreen({
      type: "offscreen:get-state",
      target: "offscreen"
    });
    const offscreenState = response?.state;
    if (!offscreenState) {
      await refreshAllowanceState();
      return;
    }
    const settings = await loadSettings();
    if (offscreenState.capturing) {
      const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      sessionMetering = await getRememberedSessionPro();
      lastMeterAt = Date.now();
      state = {
        capturing: true,
        status: offscreenState.status,
        detail: offscreenState.detail,
        progress: offscreenState.progress,
        error: offscreenState.error,
        tabId: remembered ?? activeTab?.id ?? null,
        engine: settings.engine,
        language: spokenLanguage(settings),
        audioLevel: 0,
        captionCount: 0,
        lastCaptionAt: null,
        translationStatus: offscreenState.translationStatus ?? "off",
        translationDetail: offscreenState.translationDetail ?? "",
        proAllowanceMsLeft: await allowanceMsLeft()
      };
      broadcastState();
    } else if (remembered !== null) {
      await clearActionBadge(remembered);
      await rememberCapturedTab(null);
    }
    await refreshAllowanceState();
  } catch {
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (isPopupRequest(message)) {
    void handlePopupRequest(message).then(sendResponse);
    return true;
  }
  if (isOffscreenEvent(message)) {
    handleOffscreenEvent(message);
    sendResponse({ ok: true });
    return false;
  }
  if (isContentMessage(message)) {
    void handleContentReady(sender).then(sendResponse);
    return true;
  }
  return false;
});
chrome.tabs.onRemoved.addListener((tabId) => {
  void (async () => {
    await recoverState();
    const remembered = await getRememberedTab();
    if (state.capturing && state.tabId === tabId || remembered === tabId) {
      await stopCapture();
    }
  })();
});
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName !== "local" || !(PRO_USAGE_KEY in changes)) return;
  if (proUsageDirty) return;
  const incoming = normalizeUsage(changes[PRO_USAGE_KEY].newValue);
  if (proUsage !== null && JSON.stringify(incoming) === JSON.stringify(proUsage)) return;
  proUsage = incoming;
  void refreshAllowanceState();
});
