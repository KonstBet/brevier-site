const ENTITLEMENT_MAX_AGE_MS = 12 * 60 * 60 * 1e3;
const FREE_ENTITLEMENT = {
  status: "free",
  subscriber: false,
  checkedAt: 0
};
const HUNYUAN_REGION_NOTICE = "Hunyuan-MT is not available in your region — translation switched to Chrome.";
function pickTime(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function normalizeEntitlement(input) {
  if (typeof input !== "object" || input === null) return { ...FREE_ENTITLEMENT };
  const raw = input;
  return {
    status: raw.status === "pro" ? "pro" : "free",
    subscriber: raw.subscriber === true,
    checkedAt: pickTime(raw.checkedAt) ?? 0
  };
}
function isProEntitlement(state) {
  return state.status === "pro";
}
function entitlementIsStale(state, now = Date.now()) {
  return now - state.checkedAt > ENTITLEMENT_MAX_AGE_MS;
}
function gateSettings(settings, hunyuanAllowed = true) {
  if (hunyuanAllowed || settings.translation.provider !== "hunyuan") {
    return { settings, notice: null };
  }
  const gated = {
    ...settings,
    translation: { ...settings.translation, provider: "chrome" }
  };
  return { settings: gated, notice: HUNYUAN_REGION_NOTICE };
}
export {
  FREE_ENTITLEMENT as F,
  entitlementIsStale as e,
  gateSettings as g,
  isProEntitlement as i,
  normalizeEntitlement as n
};
