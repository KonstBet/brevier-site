function formatPlanPrice(plan) {
  const amount = plan.unitAmountCents / 100;
  try {
    return new Intl.NumberFormat(void 0, {
      style: "currency",
      currency: plan.currency
    }).format(amount);
  } catch {
    return `${plan.currency.toUpperCase()} ${amount.toFixed(2)}`;
  }
}
function comparePlans(a, b) {
  const group = (plan) => plan.interval === "once" || plan.interval === null ? 0 : 1;
  return group(a) - group(b) || a.unitAmountCents - b.unitAmountCents;
}
function planLabel(plan) {
  const nickname = plan.nickname?.trim();
  if (!nickname) return null;
  return nickname.charAt(0).toUpperCase() + nickname.slice(1);
}
function isRecurring(plan) {
  return plan.interval !== null && plan.interval !== "once";
}
function priciest(plans) {
  return plans.reduce((a, b) => b.unitAmountCents > a.unitAmountCents ? b : a);
}
function planRoles(plans) {
  if (plans.length < 2) return plans.map(() => "standard");
  const recurring = plans.filter(isRecurring);
  const featured = priciest(recurring.length > 0 ? recurring : plans);
  const cheapest = plans.reduce((a, b) => b.unitAmountCents < a.unitAmountCents ? b : a);
  return plans.map((plan) => {
    if (plan === featured) return "featured";
    if (plan === cheapest && !isRecurring(plan)) return "quiet";
    return "standard";
  });
}
function formatPlanTerm(plan) {
  const unit = plan.interval === "year" ? "year" : plan.interval === "month" ? "month" : plan.interval === "week" ? "week" : plan.interval === "day" ? "day" : null;
  if (unit === null) return "one-time";
  const count = plan.intervalCount ?? 1;
  return count === 1 ? `per ${unit}` : `every ${count} ${unit}s`;
}
const ENTITLEMENT_MAX_AGE_MS = 12 * 60 * 60 * 1e3;
const FREE_ENTITLEMENT = {
  status: "free",
  subscriber: false,
  plan: null,
  paidAt: 0,
  checkedAt: 0
};
const HUNYUAN_REGION_NOTICE = "Hunyuan-MT is not available in your region — translation switched to Chrome.";
function pickTime(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function pickPlan(value) {
  if (typeof value !== "object" || value === null) return null;
  const raw = value;
  const nickname = typeof raw.nickname === "string" ? raw.nickname.trim() || null : null;
  const interval = typeof raw.interval === "string" ? raw.interval : null;
  if (nickname === null && interval === null) return null;
  return { nickname, interval };
}
function normalizeEntitlement(input) {
  if (typeof input !== "object" || input === null) return { ...FREE_ENTITLEMENT };
  const raw = input;
  return {
    status: raw.status === "pro" ? "pro" : "free",
    subscriber: raw.subscriber === true,
    plan: pickPlan(raw.plan),
    paidAt: pickTime(raw.paidAt) ?? 0,
    checkedAt: pickTime(raw.checkedAt) ?? 0
  };
}
function isProEntitlement(state) {
  return state.status === "pro";
}
function passLabel(state) {
  return state.plan ? planLabel(state.plan) ?? "Supporter" : "Supporter";
}
function isOneOffPass(state) {
  return state.plan?.interval === "once";
}
function entitlementIsStale(state, now = Date.now()) {
  return now - state.checkedAt > ENTITLEMENT_MAX_AGE_MS;
}
function gateSettings(settings, hunyuanAllowed = true) {
  if (hunyuanAllowed || settings.translation.provider !== "hunyuan") {
    return { settings, notice: null };
  }
  const gated = {
    ...settings,
    translation: { ...settings.translation, provider: "chrome" }
  };
  return { settings: gated, notice: HUNYUAN_REGION_NOTICE };
}
export {
  FREE_ENTITLEMENT as F,
  isOneOffPass as a,
  planRoles as b,
  comparePlans as c,
  planLabel as d,
  entitlementIsStale as e,
  formatPlanPrice as f,
  gateSettings as g,
  formatPlanTerm as h,
  isProEntitlement as i,
  normalizeEntitlement as n,
  passLabel as p
};
