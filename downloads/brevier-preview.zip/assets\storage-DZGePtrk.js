import { B as normalizeSettings } from "./settings-CSHN75Q-.js";
const SETTINGS_KEY = "settings";
async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return normalizeSettings(stored[SETTINGS_KEY]);
}
async function updateSettings(patch) {
  const current = await loadSettings();
  const next = normalizeSettings({
    ...current,
    ...patch,
    moonshine: { ...current.moonshine, ...patch.moonshine },
    whisper: { ...current.whisper, ...patch.whisper },
    translation: {
      ...current.translation,
      ...patch.translation
    },
    overlay: { ...current.overlay, ...patch.overlay }
  });
  await chrome.storage.local.set({ [SETTINGS_KEY]: next });
  return next;
}
export {
  loadSettings as l,
  updateSettings as u
};
