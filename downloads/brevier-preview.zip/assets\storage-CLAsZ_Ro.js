import { z as normalizeSettings } from "./settings-DWyWJaRh.js";
const SETTINGS_KEY = "settings";
let settingsWriteChain = Promise.resolve();
async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return normalizeSettings(stored[SETTINGS_KEY]);
}
function updateSettings(patch) {
  const run = settingsWriteChain.then(async () => {
    const current = await loadSettings();
    const next = normalizeSettings({
      ...current,
      ...patch,
      translation: {
        ...current.translation,
        ...patch.translation
      },
      overlay: { ...current.overlay, ...patch.overlay }
    });
    await chrome.storage.local.set({ [SETTINGS_KEY]: next });
    return next;
  });
  settingsWriteChain = run.catch(() => void 0);
  return run;
}
export {
  loadSettings as l,
  updateSettings as u
};
