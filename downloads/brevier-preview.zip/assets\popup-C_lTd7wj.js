import { s as spokenLanguage, e as errorMessage, A as ARCH_META, p as supportsMoonshineLanguage, D as DEFAULT_LANGUAGE, r as resolveArch, o as KOTOBA_LANGUAGE, q as supportsParakeetTdtLanguage, u as isWhisperLanguage, l as getMoonshineLanguage, v as defaultArchFor, M as MOONSHINE_LANGUAGES, m as getModelChoice, x as PARAKEET_LANGUAGES, y as PARAKEET_TDT_LANGUAGES, z as KOTOBA_LANGUAGES, W as WHISPER_LANGUAGES } from "./settings-CSHN75Q-.js";
import { e as element, s as setHidden } from "./dom-qkm_bq4-.js";
import { p as passLabel, i as isProEntitlement, a as isOneOffPass, c as comparePlans, b as planRoles, d as planLabel, f as formatPlanPrice, g as formatPlanTerm } from "./entitlements-nWpvccq6.js";
import { u as updateSettings, l as loadSettings } from "./storage-DZGePtrk.js";
import { p as probeChromeTranslation, a as prepareChromeTranslation, T as TRANSLATION_LANGUAGES } from "./translation-languages-BWIVOYyr.js";
class ChromeTranslationPanel {
  constructor(getSettings, notifySettingsChanged2) {
    this.getSettings = getSettings;
    this.notifySettingsChanged = notifySettingsChanged2;
    this.prepareButton.addEventListener("click", () => void this.prepare());
  }
  status = element("trChromeStatus");
  prepareButton = element("trPrepare");
  refresh() {
    void this.refreshAsync();
  }
  async refreshAsync() {
    const settings = this.getSettings();
    if (!settings || !settings.translation.enabled || settings.translation.provider !== "chrome") {
      return;
    }
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    if (source === target) {
      this.setStatus("Target language is the same as the spoken language.", false);
      return;
    }
    const availability = await probeChromeTranslation(source, target);
    switch (availability) {
      case "unsupported":
        this.setStatus(
          "Built-in translation is not available in this browser (needs desktop Chrome 138+).",
          false
        );
        break;
      case "unavailable":
        this.setStatus(`This device does not support translation ${source} → ${target}.`, false);
        break;
      case "available":
        this.setStatus(`On-device translation ready (${source} → ${target}).`, false);
        break;
      default:
        this.setStatus(`One-time model download needed (${source} → ${target}).`, true);
        break;
    }
  }
  async prepare() {
    const settings = this.getSettings();
    if (!settings) return;
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    this.prepareButton.disabled = true;
    this.setStatus("Downloading translation model…", true);
    try {
      await prepareChromeTranslation(source, target, (fraction) => {
        this.status.textContent = `Downloading translation model… ${Math.round(fraction * 100)}%`;
      });
      await this.notifySettingsChanged();
      await this.refreshAsync();
    } catch (error) {
      this.status.textContent = errorMessage(error);
    } finally {
      this.prepareButton.disabled = false;
    }
  }
  setStatus(text, showPrepare) {
    this.status.textContent = text;
    setHidden(this.prepareButton, !showPrepare);
  }
}
const ENGINE_INFO = {
  auto: {
    summary: "Picks the best engine for this machine — nothing to configure.",
    facts: [
      { label: "English", value: "Parakeet on a GPU — fastest, live text almost instantly" },
      {
        label: "Other languages",
        value: "Kotoba (Japanese), Parakeet TDT (24 non-English European languages) and Whisper (the rest) on a GPU; Moonshine on CPU-only machines"
      },
      { label: "Fallback", value: "switches engines automatically if one cannot load" },
      { label: "Privacy", value: "audio never leaves this machine" }
    ]
  },
  parakeet: {
    summary: "Fastest English captions, with top-tier accuracy.",
    facts: [
      { label: "GPU", value: "required (WebGPU)" },
      { label: "Language", value: "English only" },
      { label: "Download", value: "about 640 MB once, then cached" },
      {
        label: "Speed",
        value: "live text while you speak — a partial caption takes tens of milliseconds, and the final line lands as soon as the sentence ends"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  },
  "parakeet-tdt": {
    summary: "Multilingual European captions in a single 400 MB model.",
    facts: [
      { label: "GPU", value: "required (WebGPU)" },
      { label: "Languages", value: "25 European languages — pick the spoken one above" },
      { label: "Download", value: "about 400 MB once, then cached" },
      {
        label: "Speed",
        value: "live text about a second after speech starts, with frequent partials"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  },
  kotoba: {
    summary: "Japanese-specific Whisper fine-tune, tuned for accuracy.",
    facts: [
      { label: "GPU", value: "required (WebGPU)" },
      { label: "Language", value: "Japanese only" },
      { label: "Download", value: "about 534 MB once, then cached" },
      {
        label: "Speed",
        value: "live text about two seconds after speech starts"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  },
  moonshine: {
    summary: "Runs on your CPU — uses your GPU when one is available.",
    facts: [
      { label: "GPU", value: "used when available for tiny/base models, otherwise CPU" },
      { label: "Languages", value: "6" },
      { label: "Download", value: "44–305 MB once, then cached" },
      { label: "Privacy", value: "audio never leaves this machine" }
    ]
  },
  whisper: {
    summary: "Most accurate, but needs a GPU.",
    facts: [
      { label: "GPU", value: "required (WebGPU)" },
      { label: "Languages", value: "99 — pick the spoken one above" },
      { label: "Download", value: "about 1.5 GB once, then cached" },
      {
        label: "Speed",
        value: "live text about two seconds after speech starts; a reasonably fast GPU is recommended — weak integrated GPUs may lag behind speech"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  }
};
const TRANSLATION_INFO = {
  hymt2: {
    summary: "Best on-device translation — fast on a discrete GPU.",
    facts: [
      { label: "GPU", value: "required (WebGPU)" },
      { label: "Model", value: "Hy-MT2 (1.8B, q4f16)" },
      { label: "Languages", value: "38" },
      { label: "Download", value: "about 1.1 GB once, then cached" },
      {
        label: "Speed",
        value: "fast — about 0.2–0.5 s per line on a discrete GPU; integrated GPUs may lag"
      },
      { label: "Tip", value: "switch to Google Translate (Chrome) if it is too slow" },
      {
        label: "License",
        value: "Apache-2.0 — no regional restrictions"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  },
  chrome: {
    summary: "Instant translation on your CPU — no GPU needed.",
    facts: [
      { label: "GPU", value: "not needed" },
      { label: "Download", value: "small language pack per language pair, once" },
      { label: "Speed", value: "instant; the lightest option for slower machines" },
      { label: "Requires", value: "desktop Chrome 138 or newer" }
    ]
  }
};
function moonshineModelInfo(arch, model) {
  const streaming = arch.endsWith("_streaming");
  return {
    summary: ARCH_META[arch].blurb,
    facts: [
      { label: "Download", value: `~${model.sizeMB} MB once, then cached` },
      {
        label: "Live text",
        value: streaming ? "yes — text updates while you speak" : "no — lines appear when a sentence completes"
      },
      { label: "GPU", value: "not needed (runs on your CPU)" }
    ]
  };
}
function renderFacts(container, block, options = {}) {
  const summary = document.createElement(options.collapsible ? "span" : "p");
  summary.className = "info-summary";
  summary.textContent = block.summary;
  const list = document.createElement("ul");
  list.className = "info-list";
  for (const fact of block.facts) {
    const item = document.createElement("li");
    const label = document.createElement("strong");
    label.textContent = `${fact.label}:`;
    item.append(label, document.createTextNode(` ${fact.value}`));
    list.append(item);
  }
  if (!options.collapsible) {
    container.replaceChildren(summary, list);
    return;
  }
  const details = document.createElement("details");
  details.className = "info-more";
  const toggle2 = document.createElement("summary");
  const chevron = document.createElement("span");
  chevron.className = "info-chevron";
  chevron.setAttribute("aria-hidden", "true");
  toggle2.append(summary, chevron);
  details.append(toggle2, list);
  container.replaceChildren(details);
}
class SettingsForm {
  constructor(host) {
    this.host = host;
    this.engine.addEventListener("change", () => {
      const engine = this.engine.value;
      const current = this.current;
      const patch = { engine };
      if (!current) {
        void this.host.applyPatch(patch);
        return;
      }
      const source = current.engine === "parakeet" ? current.whisper.language : spokenLanguage(current);
      if (engine === "moonshine") {
        const language = supportsMoonshineLanguage(source) ? source : DEFAULT_LANGUAGE;
        patch.moonshine = {
          language,
          modelArch: resolveArch(language, current.moonshine.modelArch)
        };
      } else if (engine === "parakeet") ;
      else if (engine === "kotoba") {
        patch.whisper = { language: KOTOBA_LANGUAGE };
      } else if (engine === "parakeet-tdt") {
        patch.whisper = {
          language: supportsParakeetTdtLanguage(source) ? source : DEFAULT_LANGUAGE
        };
      } else if (isWhisperLanguage(source)) {
        patch.whisper = { language: source };
      }
      void this.host.applyPatch(patch);
    });
    this.language.addEventListener("change", () => {
      if (this.current?.engine === "moonshine") {
        const language = getMoonshineLanguage(this.language.value);
        void this.host.applyPatch({
          moonshine: { language: language.code, modelArch: defaultArchFor(language.code) }
        });
        return;
      }
      if (this.current?.engine === "parakeet" || this.current?.engine === "kotoba") return;
      void this.host.applyPatch({ whisper: { language: this.language.value } });
    });
    this.model.addEventListener("change", () => {
      void this.host.applyPatch({ moonshine: { modelArch: this.model.value } });
    });
    this.trEnabled.addEventListener("change", () => {
      void this.host.applyPatch({ translation: { enabled: this.trEnabled.checked } });
    });
    this.trProvider.addEventListener("change", () => {
      void this.host.applyPatch({
        translation: { provider: this.trProvider.value }
      });
    });
    this.trTarget.addEventListener("change", () => {
      void this.host.applyPatch({ translation: { targetLanguage: this.trTarget.value } });
    });
    this.trDisplay.addEventListener("change", () => {
      void this.host.applyPatch({
        translation: { display: this.trDisplay.value }
      });
    });
    this.fontSize.addEventListener("input", () => {
      this.fontSizeOut.textContent = `${this.fontSize.value}px`;
      void this.host.applyPatch(
        { overlay: { fontSize: Number(this.fontSize.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.maxLines.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { maxLines: Number(this.maxLines.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.position.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { position: this.position.value } },
        { skipLanguageRefresh: true }
      );
    });
    this.offset.addEventListener("input", () => {
      this.offsetOut.textContent = `${this.offset.value}px`;
      void this.host.applyPatch(
        { overlay: { offset: Number(this.offset.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.opacity.addEventListener("input", () => {
      this.opacityOut.textContent = `${Math.round(Number(this.opacity.value) * 100)}%`;
      void this.host.applyPatch(
        { overlay: { opacity: Number(this.opacity.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.showInterim.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { showInterim: this.showInterim.checked } },
        { skipLanguageRefresh: true }
      );
    });
    renderFacts(this.trHymt2Info, TRANSLATION_INFO.hymt2, { collapsible: true });
    renderFacts(this.trChromeInfo, TRANSLATION_INFO.chrome, { collapsible: true });
  }
  engine = element("engine");
  language = element("language");
  engineNote = element("engineNote");
  modelDetails = element("modelDetails");
  model = element("model");
  modelBlurb = element("modelBlurb");
  translationBody = element("translationBody");
  trEnabled = element("trEnabled");
  trProvider = element("trProvider");
  trTarget = element("trTarget");
  trDisplay = element("trDisplay");
  trHymt2Box = element("trHymt2Box");
  trHymt2Info = element("trHymt2Info");
  trChromeBox = element("trChromeBox");
  trChromeInfo = element("trChromeInfo");
  fontSize = element("fontSize");
  fontSizeOut = element("fontSizeOut");
  maxLines = element("maxLines");
  position = element("position");
  offset = element("offset");
  offsetOut = element("offsetOut");
  opacity = element("opacity");
  opacityOut = element("opacityOut");
  showInterim = element("showInterim");
  current = null;
  /** Last settings snapshot handed to `render`; null before the first render. */
  get settings() {
    return this.current;
  }
  render(settings) {
    this.current = settings;
    this.engine.value = settings.engine;
    renderFacts(this.engineNote, ENGINE_INFO[settings.engine], { collapsible: true });
    setHidden(this.modelDetails, settings.engine !== "moonshine");
    this.renderLanguageOptions(settings);
    this.renderModelOptions(settings.moonshine.language, settings.moonshine.modelArch);
    this.renderTranslation(settings);
    this.renderOverlay(settings);
    this.host.onRendered(settings);
  }
  renderLanguageOptions(settings) {
    const selected = spokenLanguage(settings);
    this.language.replaceChildren();
    let options;
    if (settings.engine === "moonshine") {
      options = MOONSHINE_LANGUAGES.map((language) => ({
        code: language.code,
        name: language.name
      }));
    } else if (settings.engine === "parakeet") {
      options = PARAKEET_LANGUAGES;
    } else if (settings.engine === "parakeet-tdt") {
      options = PARAKEET_TDT_LANGUAGES;
    } else if (settings.engine === "kotoba") {
      options = KOTOBA_LANGUAGES;
    } else {
      options = WHISPER_LANGUAGES;
    }
    for (const option of options) {
      const item = document.createElement("option");
      item.value = option.code;
      item.textContent = option.name;
      item.selected = option.code === selected;
      this.language.append(item);
    }
  }
  renderModelOptions(languageCode, selectedArch) {
    const language = getMoonshineLanguage(languageCode);
    this.model.replaceChildren();
    for (const model of language.models) {
      const option = document.createElement("option");
      option.value = model.arch;
      option.textContent = `${ARCH_META[model.arch].label} — ~${model.sizeMB} MB${model.default ? " (default)" : ""}`;
      option.selected = model.arch === selectedArch;
      this.model.append(option);
    }
    const chosen = getModelChoice(languageCode, selectedArch);
    renderFacts(this.modelBlurb, moonshineModelInfo(chosen.arch, chosen));
  }
  renderTranslation(settings) {
    this.trEnabled.checked = settings.translation.enabled;
    setHidden(this.translationBody, !settings.translation.enabled);
    this.trProvider.value = settings.translation.provider;
    this.renderTranslationLanguages(settings.translation.targetLanguage);
    this.trDisplay.value = settings.translation.display;
    setHidden(this.trHymt2Box, settings.translation.provider !== "hymt2");
    setHidden(this.trChromeBox, settings.translation.provider !== "chrome");
  }
  renderTranslationLanguages(selected) {
    this.trTarget.replaceChildren();
    const languages = [...TRANSLATION_LANGUAGES];
    if (!languages.some((language) => language.code === selected)) {
      languages.unshift({ code: selected, name: selected });
    }
    for (const language of languages) {
      const option = document.createElement("option");
      option.value = language.code;
      option.textContent = language.name;
      option.selected = language.code === selected;
      this.trTarget.append(option);
    }
  }
  renderOverlay(settings) {
    this.fontSize.value = String(settings.overlay.fontSize);
    this.fontSizeOut.textContent = `${settings.overlay.fontSize}px`;
    this.maxLines.value = String(settings.overlay.maxLines);
    this.position.value = settings.overlay.position;
    this.offset.value = String(settings.overlay.offset);
    this.offsetOut.textContent = `${settings.overlay.offset}px`;
    this.opacity.value = String(settings.overlay.opacity);
    this.opacityOut.textContent = `${Math.round(settings.overlay.opacity * 100)}%`;
    this.showInterim.checked = settings.overlay.showInterim;
  }
}
const TICK_MS = 1e3;
const STALE_AFTER_MS = 2e4;
class StatusView {
  dot = element("statusDot");
  statusText = element("statusText");
  staleWarning = element("staleWarning");
  activity = element("activity");
  progressWrap = element("progressWrap");
  progressBar = element("progressBar");
  progressText = element("progressText");
  toggle = element("toggle");
  translationRuntime = element("trRuntime");
  state = null;
  lastStateAt = 0;
  constructor() {
    window.setInterval(() => this.tick(), TICK_MS);
  }
  get capturing() {
    return this.state?.capturing ?? false;
  }
  /** Surfaces a transport-level failure (e.g. messaging the service worker). */
  showError(message) {
    this.statusText.textContent = message;
  }
  render(incoming) {
    const state = {
      ...incoming,
      audioLevel: typeof incoming.audioLevel === "number" ? incoming.audioLevel : 0,
      captionCount: typeof incoming.captionCount === "number" ? incoming.captionCount : 0,
      lastCaptionAt: typeof incoming.lastCaptionAt === "number" ? incoming.lastCaptionAt : null,
      translationStatus: incoming.translationStatus ?? "off",
      translationDetail: typeof incoming.translationDetail === "string" ? incoming.translationDetail : ""
    };
    this.state = state;
    this.lastStateAt = Date.now();
    setHidden(this.staleWarning, true);
    this.renderActivity();
    this.renderTranslationRuntime(state);
    this.statusText.textContent = state.error ?? state.detail;
    this.dot.className = `dot ${state.status}`;
    this.toggle.textContent = state.capturing ? "Stop captions" : "Start captions";
    this.toggle.classList.toggle("stop", state.capturing);
    this.renderProgress(state);
  }
  /**
   * The offscreen pipeline sends a heartbeat every few seconds while loading,
   * so a long silence means the document was torn down or the engine wedged.
   */
  tick() {
    const state = this.state;
    if (!state) return;
    const loading = state.status === "loading" || state.status === "starting";
    const stale = state.capturing && loading && Date.now() - this.lastStateAt > STALE_AFTER_MS;
    setHidden(this.staleWarning, !stale);
    this.renderActivity();
  }
  renderActivity() {
    const state = this.state;
    if (!state?.capturing) {
      setHidden(this.activity, true);
      return;
    }
    setHidden(this.activity, false);
    const level = typeof state.audioLevel === "number" ? state.audioLevel : 0;
    const audio = level < 3e-3 ? "no audio" : "audio";
    const last = state.lastCaptionAt ? `${Math.max(0, Math.round((Date.now() - state.lastCaptionAt) / 1e3))}s ago` : "—";
    this.activity.textContent = `${audio} ${level.toFixed(3)} · captions ${state.captionCount ?? 0} · last ${last}`;
    this.activity.classList.toggle(
      "warn",
      level < 3e-3 && state.captionCount === 0 && state.status === "ready"
    );
  }
  renderTranslationRuntime(state) {
    if (!state.capturing || state.translationStatus === "off") {
      setHidden(this.translationRuntime, true);
      return;
    }
    setHidden(this.translationRuntime, false);
    this.translationRuntime.classList.toggle("warn", state.translationStatus === "error");
    this.translationRuntime.textContent = state.translationDetail || "Translation";
  }
  renderProgress(state) {
    const showProgress = Boolean(state.progress) || state.status === "loading" || state.status === "starting";
    setHidden(this.progressWrap, !showProgress);
    if (state.progress) {
      const { loaded, total, file } = state.progress;
      if (total && total > 0) {
        const percent = Math.min(100, Math.round(loaded / total * 100));
        this.progressWrap.classList.remove("indeterminate");
        this.progressBar.style.width = `${percent}%`;
        this.progressText.textContent = `${percent}% · ${file}`;
      } else {
        this.progressWrap.classList.add("indeterminate");
        this.progressText.textContent = file;
      }
      setHidden(this.progressText, false);
    } else {
      this.progressWrap.classList.toggle("indeterminate", showProgress);
      setHidden(this.progressText, true);
    }
  }
}
const status = new StatusView();
const toggle = element("toggle");
const tabNote = element("tabNote");
const diagnostics = element("diagnostics");
const notices = element("notices");
const reviewPrompt = element("reviewPrompt");
const reviewNow = element("reviewNow");
const reviewDismiss = element("reviewDismiss");
const shareButton = element("share");
const reviewButton = element("review");
const proCard = element("proCard");
const proHeading = element("proHeading");
const proState = element("proState");
const proInfo = element("proInfo");
const proPlans = element("proPlans");
const proBuy = element("proBuy");
const proLogin = element("proLogin");
const proManage = element("proManage");
const proSupport = element("proSupport");
let entitlement = null;
let plans = [];
const SITE_URL = "https://konstbet.github.io/brevier-site/";
const REVIEW_URL = "https://chromewebstore.google.com/detail/jfljjchlfbijcnbkagkiolngfebljapa/reviews";
const SHARE_TEXT = "Private, on-device live captions and translation for any Chrome tab — free.";
const CAPTION_STARTS_KEY = "captionStarts";
const REVIEW_PROMPT_SEEN_KEY = "reviewPromptSeen";
const REVIEW_AFTER_STARTS = 3;
function isPro() {
  return entitlement !== null && isProEntitlement(entitlement);
}
function isSubscriber() {
  return entitlement?.subscriber === true;
}
async function loadEntitlement() {
  try {
    const response = await chrome.runtime.sendMessage({
      type: "popup:get-entitlement"
    });
    if (response?.entitlement) entitlement = response.entitlement;
    if (response) {
      plans = Array.isArray(response.plans) ? response.plans : [];
    }
  } catch {
  }
  renderProCard();
}
const SUPPORTER_SINCE = new Intl.DateTimeFormat(void 0, { month: "short", year: "numeric" });
function paidLine(state) {
  if (state.paidAt <= 0) return "Thank you 👍";
  const when = SUPPORTER_SINCE.format(new Date(state.paidAt));
  return isOneOffPass(state) ? `Thank you · ${when}` : `Since ${when}`;
}
function renderPlans() {
  proPlans.replaceChildren();
  const ordered = [...plans].sort(comparePlans);
  const roles = planRoles(ordered);
  ordered.forEach((plan, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = roles[index] === "standard" ? "pro-plan" : `pro-plan is-${roles[index]}`;
    const name = planLabel(plan);
    if (name !== null) {
      const nameElement = document.createElement("span");
      nameElement.className = "pro-plan-name";
      nameElement.textContent = name;
      button.append(nameElement);
    }
    const price = document.createElement("strong");
    price.className = "pro-plan-price";
    price.textContent = formatPlanPrice(plan);
    const term = document.createElement("span");
    term.className = "pro-plan-term";
    term.textContent = formatPlanTerm(plan);
    button.append(price, term);
    button.addEventListener(
      "click",
      () => openPurchasePage({ type: "popup:open-upgrade", plan: plan.nickname ?? void 0 })
    );
    proPlans.append(button);
  });
  setHidden(proPlans, plans.length === 0);
}
function renderProCard() {
  const pro = isPro();
  setHidden(proCard, false);
  proCard.classList.toggle("is-pro", pro);
  if (pro) {
    const paid = entitlement;
    proHeading.textContent = paid ? passLabel(paid) : "Supporter";
    proState.textContent = paid ? paidLine(paid) : "Thank you 👍";
    setHidden(proInfo, true);
    setHidden(proPlans, true);
    setHidden(proBuy, true);
    setHidden(proLogin, true);
    setHidden(proManage, !isSubscriber());
    setHidden(proSupport, true);
    return;
  }
  proHeading.textContent = "Support Brevier";
  proState.textContent = "";
  proInfo.textContent = "All 99 languages and engines are free for everyone. A tip is a one-off thanks; a yearly Patron pass is what keeps the work going.";
  setHidden(proInfo, false);
  renderPlans();
  setHidden(proBuy, plans.length > 0);
  setHidden(proLogin, false);
  setHidden(proManage, true);
  setHidden(proSupport, false);
}
function openPurchasePage(request) {
  void chrome.runtime.sendMessage(request).then((response) => {
    const result = response;
    if (result && result.ok === false && result.error) {
      proInfo.textContent = result.error;
      setHidden(proInfo, false);
      proCard.scrollIntoView({ block: "nearest" });
    }
  }).catch((error) => {
    console.error("[brevier] purchase message failed", error);
    proInfo.textContent = "Could not reach the extension service worker. Reload the extension on chrome://extensions and try again.";
    setHidden(proInfo, false);
    proCard.scrollIntoView({ block: "nearest" });
  });
}
function openExternal(url) {
  void chrome.tabs.create({ url });
}
function bumpCaptionStarts() {
  void chrome.storage.local.get(CAPTION_STARTS_KEY).then((stored) => {
    const starts = Number(stored[CAPTION_STARTS_KEY] ?? 0) + 1;
    return chrome.storage.local.set({ [CAPTION_STARTS_KEY]: starts });
  }).catch(() => {
  });
}
function markReviewPromptSeen() {
  void chrome.storage.local.set({ [REVIEW_PROMPT_SEEN_KEY]: true }).catch(() => {
  });
}
async function maybeShowReviewPrompt() {
  if (status.capturing) return;
  try {
    const stored = await chrome.storage.local.get([CAPTION_STARTS_KEY, REVIEW_PROMPT_SEEN_KEY]);
    if (stored[REVIEW_PROMPT_SEEN_KEY] === true) return;
    if (Number(stored[CAPTION_STARTS_KEY] ?? 0) < REVIEW_AFTER_STARTS) return;
    markReviewPromptSeen();
    setHidden(reviewPrompt, false);
  } catch {
  }
}
function closeReviewPrompt() {
  markReviewPromptSeen();
  setHidden(reviewPrompt, true);
}
function openReviewPage() {
  closeReviewPrompt();
  openExternal(REVIEW_URL);
}
async function shareBrevier() {
  if (typeof navigator.share === "function") {
    try {
      await navigator.share({ title: "Brevier", text: SHARE_TEXT, url: SITE_URL });
      return;
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
    }
  }
  try {
    await navigator.clipboard.writeText(`${SHARE_TEXT} ${SITE_URL}`);
    shareButton.textContent = "Copied";
    window.setTimeout(() => {
      shareButton.textContent = "Share";
    }, 1500);
  } catch {
    openExternal(SITE_URL);
  }
}
async function notifySettingsChanged() {
  try {
    await chrome.runtime.sendMessage({ type: "popup:settings-changed" });
  } catch {
  }
}
const form = new SettingsForm({
  applyPatch: async (patch, options) => {
    const settings = await updateSettings(patch);
    if (!options?.skipLanguageRefresh) {
      form.render(settings);
    }
    await notifySettingsChanged();
  },
  onRendered: () => chromeTranslation.refresh()
});
const chromeTranslation = new ChromeTranslationPanel(
  () => form.settings,
  notifySettingsChanged
);
toggle.addEventListener("click", () => {
  const capturing = status.capturing;
  if (!capturing) bumpCaptionStarts();
  toggle.disabled = true;
  void chrome.runtime.sendMessage({ type: capturing ? "popup:stop" : "popup:start" }).then((response) => {
    const state = response?.state;
    if (state) status.render(state);
  }).catch((error) => {
    status.showError(errorMessage(error));
  }).finally(() => {
    toggle.disabled = false;
  });
});
diagnostics.addEventListener("click", () => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("debug/debug.html") });
});
notices.addEventListener("click", () => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("notices.html") });
});
shareButton.addEventListener("click", () => void shareBrevier());
reviewButton.addEventListener("click", openReviewPage);
reviewNow.addEventListener("click", openReviewPage);
reviewDismiss.addEventListener("click", closeReviewPrompt);
proBuy.addEventListener("click", () => openPurchasePage({ type: "popup:open-upgrade" }));
proLogin.addEventListener("click", () => openPurchasePage({ type: "popup:open-login" }));
proManage.addEventListener("click", () => openPurchasePage({ type: "popup:open-upgrade" }));
chrome.runtime.onMessage.addListener((message) => {
  if (typeof message === "object" && message !== null && message.type === "bg:state") {
    status.render(message.state);
  }
});
const INTERNAL_TAB = /^(chrome|chrome-extension|chrome-untrusted|devtools|edge|about|view-source):/i;
async function checkCapturableTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const url = tab?.url ?? tab?.pendingUrl ?? "";
    const internal = url !== "" && INTERNAL_TAB.test(url);
    setHidden(tabNote, !internal);
  } catch {
    setHidden(tabNote, true);
  }
}
async function init() {
  await loadEntitlement();
  const settings = await loadSettings();
  form.render(settings);
  void checkCapturableTab();
  try {
    const response = await chrome.runtime.sendMessage({
      type: "popup:get-state"
    });
    if (response?.state) status.render(response.state);
  } catch {
  }
  void maybeShowReviewPrompt();
}
void init();
