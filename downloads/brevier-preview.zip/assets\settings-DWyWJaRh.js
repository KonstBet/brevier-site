const STUDIO_LEASE_TTL_MS = 12e4;
const STUDIO_LEASE_HEARTBEAT_MS = 25e3;
function isOffscreenMessage(message) {
  return typeof message === "object" && message !== null && message.target === "offscreen";
}
function isPopupRequest(message) {
  if (typeof message !== "object" || message === null) return false;
  const type = message.type;
  return type === "popup:start" || type === "popup:stop" || type === "popup:get-state" || type === "popup:settings-changed" || type === "popup:get-entitlement" || type === "popup:open-upgrade" || type === "popup:open-login";
}
function isStudioRequest(message) {
  if (typeof message !== "object" || message === null) return false;
  const { type, owner } = message;
  return (type === "studio:acquire" || type === "studio:heartbeat" || type === "studio:release") && typeof owner === "string" && owner.length > 0;
}
function isContentMessage(message) {
  return typeof message === "object" && message !== null && message.type === "content:ready";
}
function isOffscreenEvent(message) {
  if (typeof message !== "object" || message === null) return false;
  const type = message.type;
  if (type === "offscreen:audio") {
    return typeof message.level === "number";
  }
  return type === "offscreen:status" || type === "offscreen:progress" || type === "offscreen:caption" || type === "offscreen:translation";
}
function errorMessage(error) {
  if (error instanceof Error) return error.message;
  return String(error);
}
const DEFAULT_LANGUAGE = "en";
const LANGUAGE_NAMES = {
  ar: "Arabic",
  bg: "Bulgarian",
  cs: "Czech",
  da: "Danish",
  de: "German",
  el: "Greek",
  en: "English",
  es: "Spanish",
  et: "Estonian",
  fa: "Persian",
  fi: "Finnish",
  fil: "Filipino",
  fr: "French",
  hi: "Hindi",
  hr: "Croatian",
  hu: "Hungarian",
  id: "Indonesian",
  it: "Italian",
  ja: "Japanese",
  ko: "Korean",
  lt: "Lithuanian",
  lv: "Latvian",
  mk: "Macedonian",
  ms: "Malay",
  mt: "Maltese",
  nl: "Dutch",
  pl: "Polish",
  pt: "Portuguese",
  ro: "Romanian",
  ru: "Russian",
  sk: "Slovak",
  sl: "Slovenian",
  sv: "Swedish",
  th: "Thai",
  tr: "Turkish",
  uk: "Ukrainian",
  vi: "Vietnamese",
  yue: "Cantonese",
  zh: "Chinese (Mandarin)"
};
function options(codes) {
  return codes.map((code) => ({ code, name: LANGUAGE_NAMES[code] })).sort((a, b) => a.name.localeCompare(b.name));
}
const QWEN_LANGUAGE_CODES = [
  "ar",
  "cs",
  "da",
  "de",
  "el",
  "en",
  "es",
  "fa",
  "fi",
  "fil",
  "fr",
  "hi",
  "hu",
  "id",
  "it",
  "ja",
  "ko",
  "mk",
  "ms",
  "nl",
  "pl",
  "pt",
  "ro",
  "ru",
  "sv",
  "th",
  "tr",
  "vi",
  "yue",
  "zh"
];
const QWEN_LANGUAGES = options(QWEN_LANGUAGE_CODES);
const PARAKEET_TDT_LANGUAGE_CODES = [
  "bg",
  "hr",
  "cs",
  "da",
  "nl",
  "en",
  "et",
  "fi",
  "fr",
  "de",
  "el",
  "hu",
  "it",
  "lv",
  "lt",
  "mt",
  "pl",
  "pt",
  "ro",
  "sk",
  "sl",
  "es",
  "sv",
  "ru",
  "uk"
];
const PARAKEET_TDT_LANGUAGES = options(PARAKEET_TDT_LANGUAGE_CODES);
const PARAKEET_LANGUAGES = options(["ja"]);
const PARAKEET_LANGUAGE = "ja";
const SUPPORTED_LANGUAGE_CODES = Array.from(
  /* @__PURE__ */ new Set([...QWEN_LANGUAGE_CODES, ...PARAKEET_TDT_LANGUAGE_CODES, PARAKEET_LANGUAGE])
);
const SUPPORTED_LANGUAGES = options(SUPPORTED_LANGUAGE_CODES);
const QWEN_SET = new Set(QWEN_LANGUAGE_CODES);
const TDT_SET = new Set(PARAKEET_TDT_LANGUAGE_CODES);
const SUPPORTED_SET = new Set(SUPPORTED_LANGUAGE_CODES);
function supportsQwenLanguage(code) {
  return QWEN_SET.has(code);
}
function supportsParakeetTdtLanguage(code) {
  return TDT_SET.has(code);
}
function supportsParakeetLanguage(code) {
  return code === PARAKEET_LANGUAGE;
}
function isSupportedLanguage(code) {
  return SUPPORTED_SET.has(code);
}
const DEFAULT_QWEN_MODEL = "0.6b";
const QWEN_MODELS = {
  "0.6b": {
    size: "0.6b",
    label: "0.6B",
    id: "jiangzhuo9357/Qwen3-ASR-0.6B-ONNX",
    sizeMB: 1240
  },
  "1.7b": {
    size: "1.7b",
    label: "1.7B",
    id: "jiangzhuo9357/Qwen3-ASR-1.7B-ONNX",
    sizeMB: 2600
  }
};
const QWEN_MODEL = QWEN_MODELS[DEFAULT_QWEN_MODEL];
function isQwenModelSize(value) {
  return value === "0.6b" || value === "1.7b";
}
function qwenModelFor(size) {
  return isQwenModelSize(size) ? QWEN_MODELS[size] : QWEN_MODEL;
}
const PARAKEET_JA_MODEL = {
  id: "mokemoko/parakeet-ctc-0.6b-ja-ONNX",
  sizeMB: 621,
  dtype: "q4",
  cpuDtype: "int8",
  cpuSizeMB: 812
};
const PARAKEET_TDT_MODEL = {
  id: "Olicorne/parakeet-tdt-0.6b-v3-ultra-onnx",
  sizeMB: 402,
  cpuSizeMB: 640
};
const SETTINGS_VERSION = 3;
const PARAKEET_JAPANESE_VERSION = 3;
function isLocalTranslationProvider(id) {
  return id === "hymt3";
}
const DEFAULT_SETTINGS = {
  version: SETTINGS_VERSION,
  engine: "auto",
  language: DEFAULT_LANGUAGE,
  qwenModel: DEFAULT_QWEN_MODEL,
  translation: {
    enabled: false,
    provider: "chrome",
    targetLanguage: "en",
    display: "translation"
  },
  overlay: {
    fontSize: 24,
    maxLines: 2,
    position: "bottom",
    offset: 96,
    opacity: 0.85,
    showInterim: true,
    hideDelayMs: 4500
  }
};
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
function pickNumber(value, fallback, min, max) {
  if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, value));
}
function pickString(value, fallback) {
  return typeof value === "string" ? value : fallback;
}
function pickBoolean(value, fallback) {
  return typeof value === "boolean" ? value : fallback;
}
function pickTranslationProvider(value) {
  if (value === "hymt3") return "hymt3";
  if (value === "hymt2" || value === "hunyuan") return "hymt3";
  return DEFAULT_SETTINGS.translation.provider;
}
function pickEngine(rawEngine) {
  if (rawEngine === "qwen") return "qwen";
  if (rawEngine === "parakeet") return "parakeet";
  if (rawEngine === "parakeet-tdt") return "parakeet-tdt";
  return "auto";
}
function resolveLanguage(engine, code) {
  if (!isSupportedLanguage(code)) return DEFAULT_LANGUAGE;
  if (engine === "parakeet") return PARAKEET_LANGUAGE;
  if (engine === "parakeet-tdt" && !supportsParakeetTdtLanguage(code)) return DEFAULT_LANGUAGE;
  if (engine === "qwen" && !supportsQwenLanguage(code)) return DEFAULT_LANGUAGE;
  return code;
}
function normalizeSettings(input) {
  const raw = isRecord(input) ? input : {};
  const rawWhisper = isRecord(raw.whisper) ? raw.whisper : {};
  const rawMoonshine = isRecord(raw.moonshine) ? raw.moonshine : {};
  const rawTranslation = isRecord(raw.translation) ? raw.translation : {};
  const rawOverlay = isRecord(raw.overlay) ? raw.overlay : {};
  const rawVersion = typeof raw.version === "number" ? raw.version : 0;
  const legacyParakeet = raw.engine === "parakeet" && rawVersion < PARAKEET_JAPANESE_VERSION;
  const legacyLanguage = raw.engine === "moonshine" ? pickString(rawMoonshine.language, "") : raw.engine === "whisper" ? pickString(rawWhisper.language, "") : "";
  const storedLanguage = legacyParakeet ? DEFAULT_LANGUAGE : pickString(
    raw.language,
    legacyLanguage || pickString(rawWhisper.language, pickString(rawMoonshine.language, DEFAULT_LANGUAGE))
  );
  const engine = legacyParakeet ? "auto" : pickEngine(raw.engine);
  const language = resolveLanguage(engine, storedLanguage);
  const position = rawOverlay.position === "top" ? "top" : "bottom";
  const qwenModel = isQwenModelSize(raw.qwenModel) ? raw.qwenModel : DEFAULT_QWEN_MODEL;
  const translationProvider = pickTranslationProvider(rawTranslation.provider);
  const translationDisplay = rawTranslation.display === "both" ? "both" : rawTranslation.display === "source" ? "source" : "translation";
  return {
    version: SETTINGS_VERSION,
    engine,
    language,
    qwenModel,
    translation: {
      enabled: pickBoolean(rawTranslation.enabled, DEFAULT_SETTINGS.translation.enabled),
      provider: translationProvider,
      targetLanguage: pickString(
        rawTranslation.targetLanguage,
        DEFAULT_SETTINGS.translation.targetLanguage
      ),
      display: translationDisplay
    },
    overlay: {
      fontSize: pickNumber(rawOverlay.fontSize, DEFAULT_SETTINGS.overlay.fontSize, 12, 72),
      maxLines: Math.round(
        pickNumber(rawOverlay.maxLines, DEFAULT_SETTINGS.overlay.maxLines, 1, 6)
      ),
      position,
      offset: pickNumber(rawOverlay.offset, DEFAULT_SETTINGS.overlay.offset, 0, 2e3),
      opacity: pickNumber(rawOverlay.opacity, DEFAULT_SETTINGS.overlay.opacity, 0.2, 1),
      showInterim: pickBoolean(rawOverlay.showInterim, DEFAULT_SETTINGS.overlay.showInterim),
      hideDelayMs: pickNumber(
        rawOverlay.hideDelayMs,
        DEFAULT_SETTINGS.overlay.hideDelayMs,
        0,
        6e4
      )
    }
  };
}
function engineSignature(settings) {
  return JSON.stringify({
    engine: settings.engine,
    language: settings.language,
    qwenModel: settings.qwenModel
  });
}
function spokenLanguage(settings) {
  return settings.engine === "parakeet" ? PARAKEET_LANGUAGE : settings.language;
}
function translationSignature(settings) {
  return JSON.stringify({
    enabled: settings.translation.enabled,
    provider: settings.translation.provider,
    targetLanguage: settings.translation.targetLanguage,
    sourceLanguage: spokenLanguage(settings)
  });
}
export {
  DEFAULT_QWEN_MODEL as D,
  PARAKEET_JA_MODEL as P,
  QWEN_MODEL as Q,
  STUDIO_LEASE_TTL_MS as S,
  isStudioRequest as a,
  isOffscreenEvent as b,
  isContentMessage as c,
  PARAKEET_TDT_MODEL as d,
  errorMessage as e,
  isOffscreenMessage as f,
  engineSignature as g,
  isLocalTranslationProvider as h,
  isPopupRequest as i,
  QWEN_MODELS as j,
  PARAKEET_LANGUAGE as k,
  DEFAULT_LANGUAGE as l,
  supportsParakeetTdtLanguage as m,
  supportsQwenLanguage as n,
  PARAKEET_LANGUAGES as o,
  PARAKEET_TDT_LANGUAGES as p,
  qwenModelFor as q,
  QWEN_LANGUAGES as r,
  spokenLanguage as s,
  translationSignature as t,
  SUPPORTED_LANGUAGES as u,
  STUDIO_LEASE_HEARTBEAT_MS as v,
  DEFAULT_SETTINGS as w,
  PARAKEET_TDT_LANGUAGE_CODES as x,
  supportsParakeetLanguage as y,
  normalizeSettings as z
};
