import { p as normalizeSettings } from "./region-BGLr_vDp.js";
const PRO_ALLOWANCE_MS = 15 * 60 * 1e3;
const USAGE_MAX_TICK_MS = 2e3;
function usageDateKey(now = Date.now()) {
  const date = new Date(now);
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${date.getFullYear()}-${month}-${day}`;
}
function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}
function normalizeUsage(input, now = Date.now()) {
  const today = usageDateKey(now);
  if (typeof input !== "object" || input === null) return { dateKey: today, proMsUsed: 0 };
  const raw = input;
  if (raw.dateKey !== today) return { dateKey: today, proMsUsed: 0 };
  const used = typeof raw.proMsUsed === "number" && Number.isFinite(raw.proMsUsed) ? raw.proMsUsed : 0;
  return { dateKey: today, proMsUsed: clamp(used, 0, PRO_ALLOWANCE_MS) };
}
function remainingProMs(state, now = Date.now()) {
  if (state.dateKey !== usageDateKey(now)) return PRO_ALLOWANCE_MS;
  return Math.max(0, PRO_ALLOWANCE_MS - state.proMsUsed);
}
function addProUsage(state, deltaMs, now = Date.now()) {
  const today = usageDateKey(now);
  const used = state.dateKey === today ? state.proMsUsed : 0;
  const delta = Number.isFinite(deltaMs) ? clamp(deltaMs, 0, USAGE_MAX_TICK_MS) : 0;
  return { dateKey: today, proMsUsed: Math.min(PRO_ALLOWANCE_MS, used + delta) };
}
const SETTINGS_KEY = "settings";
const PRO_USAGE_KEY = "proUsage";
async function loadSettings() {
  const stored = await chrome.storage.local.get(SETTINGS_KEY);
  return normalizeSettings(stored[SETTINGS_KEY]);
}
async function saveSettings(settings) {
  await chrome.storage.local.set({ [SETTINGS_KEY]: normalizeSettings(settings) });
}
async function updateSettings(patch) {
  const current = await loadSettings();
  const next = normalizeSettings({
    ...current,
    ...patch,
    moonshine: { ...current.moonshine, ...patch.moonshine },
    whisper: { ...current.whisper, ...patch.whisper },
    translation: {
      ...current.translation,
      ...patch.translation
    },
    overlay: { ...current.overlay, ...patch.overlay }
  });
  await saveSettings(next);
  return next;
}
async function loadProUsage(now = Date.now()) {
  const stored = await chrome.storage.local.get(PRO_USAGE_KEY);
  return normalizeUsage(stored[PRO_USAGE_KEY], now);
}
async function saveProUsage(usage) {
  await chrome.storage.local.set({ [PRO_USAGE_KEY]: usage });
}
export {
  PRO_USAGE_KEY as P,
  loadProUsage as a,
  addProUsage as b,
  PRO_ALLOWANCE_MS as c,
  loadSettings as l,
  normalizeUsage as n,
  remainingProMs as r,
  saveProUsage as s,
  updateSettings as u
};
