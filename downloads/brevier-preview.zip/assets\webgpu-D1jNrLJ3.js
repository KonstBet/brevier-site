async function hasWebGpu() {
  const gpu = globalThis.navigator?.gpu;
  if (!gpu) return false;
  try {
    return await gpu.requestAdapter() !== null;
  } catch {
    return false;
  }
}
export {
  hasWebGpu as h
};
