import { C as ChromeTranslationProvider } from "./translation-languages-DuT0gDGk.js";
import { H as Hymt3TranslationProvider } from "./provider-DCStykE9.js";
function createTranslationProvider(id) {
  switch (id) {
    case "hymt3":
      return new Hymt3TranslationProvider();
    case "chrome":
    default:
      return new ChromeTranslationProvider();
  }
}
export {
  createTranslationProvider as c
};
