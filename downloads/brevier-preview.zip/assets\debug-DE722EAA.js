import { b as bestModelFor, c as createEngine, H as Hymt3TranslationProvider } from "./provider-U0wpvxWk.js";
import { e as element } from "./dom-qkm_bq4-.js";
import { s as spokenLanguage, P as PARAKEET_JA_MODEL, c as PARAKEET_TDT_MODEL, q as qwenModelFor, Q as QWEN_MODEL, e as errorMessage } from "./settings-HWqrYUVe.js";
import { l as loadSettings } from "./storage-Beku4kBR.js";
import { c as chromeTranslatorApi, p as probeChromeTranslation } from "./translation-languages-rIHGiGRb.js";
const ui = {
  env: element("env"),
  licenseBox: element("licenseBox"),
  licenseTip: element("licenseTip"),
  licenseSupporter: element("licenseSupporter"),
  licensePatron: element("licensePatron"),
  licenseFree: element("licenseFree"),
  licenseState: element("licenseState"),
  load: element("load"),
  stop: element("stop"),
  clear: element("clear"),
  trProbe: element("trProbe"),
  trInput: element("trInput"),
  trTest: element("trTest"),
  trHymt3: element("trHymt3"),
  trClear: element("trClear"),
  log: element("log")
};
function log(message) {
  const line = `[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] ${message}`;
  ui.log.textContent += `${line}
`;
  console.log("[diagnostics]", line);
}
const manifest = chrome.runtime.getManifest();
ui.env.textContent = [
  `extension ${manifest.version}`,
  `crossOriginIsolated=${self.crossOriginIsolated}`,
  `hardwareConcurrency=${navigator.hardwareConcurrency}`,
  `SharedArrayBuffer=${typeof SharedArrayBuffer !== "undefined" ? "yes" : "no"}`,
  navigator.userAgent
].join(" · ");
let engine = null;
let lastProgressAt = 0;
ui.load.addEventListener("click", () => {
  void (async () => {
    const settings = await loadSettings();
    const language = spokenLanguage(settings);
    const best = bestModelFor(language);
    const model = settings.engine === "parakeet" ? PARAKEET_JA_MODEL.id : settings.engine === "parakeet-tdt" ? PARAKEET_TDT_MODEL.id : settings.engine === "qwen" ? qwenModelFor(settings.qwenModel).id : best?.engine === "qwen" ? QWEN_MODEL.id : best?.model ?? "unknown";
    log(`loading engine=${settings.engine} language=${language} model=${model}`);
    engine = createEngine(settings.engine);
    ui.load.disabled = true;
    ui.stop.disabled = false;
    try {
      await engine.initialize({
        settings,
        events: {
          onStatus: (status, detail) => log(`status: ${status}${detail ? ` — ${detail}` : ""}`),
          onProgress: (progress) => {
            if (!progress) {
              log("download progress: complete");
              return;
            }
            const now = Date.now();
            const percent = progress.total ? Math.round(progress.loaded / progress.total * 100) : null;
            if (now - lastProgressAt > 1e3 || percent === 100) {
              lastProgressAt = now;
              log(`download: ${percent === null ? "…" : `${percent}%`} ${progress.file}`);
            }
          },
          onCaption: (event) => log(`caption (${event.kind}): ${event.text}`),
          onError: (error) => log(`ENGINE ERROR: ${error.message}`),
          onLog: (message) => log(`engine: ${message}`)
        }
      });
      await engine.start();
      log("engine ready");
      const sampleRate = 48e3;
      const chunk = new Float32Array(sampleRate / 10);
      for (let i = 0; i < chunk.length; i++) {
        chunk[i] = 0.02 * Math.sin(2 * Math.PI * 440 * i / sampleRate);
      }
      for (let n = 0; n < 30; n++) {
        engine.pushAudio(chunk.slice(), sampleRate);
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      log("fed 3s of test audio");
      await engine.stop();
      log("stopped");
    } catch (error) {
      log(`FAILED: ${errorMessage(error)}`);
    } finally {
      ui.load.disabled = false;
    }
  })();
});
ui.stop.addEventListener("click", () => {
  void (async () => {
    await engine?.dispose();
    engine = null;
    ui.stop.disabled = true;
    log("engine disposed");
  })();
});
function deleteTdtCache() {
  return new Promise((resolve) => {
    const request = indexedDB.deleteDatabase("parakeet-cache-db");
    request.onsuccess = () => resolve();
    request.onerror = () => resolve();
    request.onblocked = () => resolve();
  });
}
ui.clear.addEventListener("click", () => {
  void (async () => {
    const keys = await caches.keys();
    const deleted = await Promise.all(keys.map((key) => caches.delete(key)));
    const count = deleted.filter(Boolean).length;
    log(`clear cached models: ${count ? `${count} cache(s) deleted` : "nothing cached"}`);
    await deleteTdtCache();
    log("cleared the Parakeet TDT model cache");
  })();
});
ui.trProbe.addEventListener("click", () => {
  void (async () => {
    const settings = await loadSettings();
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    log(`Translator API present: ${chromeTranslatorApi() ? "yes" : "no"}`);
    log(`translation availability ${source} → ${target}: ${await probeChromeTranslation(source, target)}`);
  })();
});
ui.trTest.addEventListener("click", () => {
  void (async () => {
    const settings = await loadSettings();
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    const api = chromeTranslatorApi();
    if (!api) {
      log("Translator API not available in this browser.");
      return;
    }
    ui.trTest.disabled = true;
    try {
      log(`creating translator ${source} → ${target}…`);
      const translator = await api.create({
        sourceLanguage: source,
        targetLanguage: target,
        monitor: (monitor) => {
          monitor.addEventListener("downloadprogress", (event) => {
            const loaded = event.loaded ?? 0;
            log(`translation model download: ${Math.round(loaded * 100)}%`);
          });
        }
      });
      const text = ui.trInput.value.trim() || "It was the best of times.";
      log(`translating: ${text}`);
      log(`result: ${await translator.translate(text)}`);
      translator.destroy();
    } catch (error) {
      log(`TRANSLATION ERROR: ${errorMessage(error)}`);
    } finally {
      ui.trTest.disabled = false;
    }
  })();
});
ui.trClear.addEventListener("click", () => {
  void (async () => {
    const deleted = await caches.delete("transformers-cache");
    log(`clear cached translation models: ${deleted ? "deleted" : "nothing cached"}`);
  })();
});
function runLocalTranslation(provider, label, button) {
  void (async () => {
    const settings = await loadSettings();
    const text = ui.trInput.value.trim() || "It was the best of times.";
    button.disabled = true;
    let lastProgressAt2 = 0;
    const startedAt = Date.now();
    try {
      log(
        `${label} ${spokenLanguage(settings)} → ${settings.translation.targetLanguage}: preparing…`
      );
      await provider.initialize({
        sourceLanguage: spokenLanguage(settings),
        targetLanguage: settings.translation.targetLanguage,
        onProgress: (progress) => {
          if (!progress) {
            log(`${label} model ready`);
            return;
          }
          const now = Date.now();
          if (now - lastProgressAt2 < 1e3) return;
          lastProgressAt2 = now;
          const percent = progress.fraction === null ? "…" : `${Math.round(progress.fraction * 100)}%`;
          log(`${label} download: ${percent} ${progress.detail}`);
        }
      });
      log(`${label} ready in ${((Date.now() - startedAt) / 1e3).toFixed(1)}s`);
      log(`translating: ${text}`);
      const result = await provider.translate(text);
      log(`result (${Date.now() - startedAt}ms total): ${result}`);
    } catch (error) {
      log(`${label} ERROR: ${errorMessage(error)}`);
    } finally {
      provider.dispose();
      button.disabled = false;
    }
  })();
}
ui.trHymt3.addEventListener(
  "click",
  () => runLocalTranslation(new Hymt3TranslationProvider(), "Hy-MT3", ui.trHymt3)
);
log("diagnostics page ready");
