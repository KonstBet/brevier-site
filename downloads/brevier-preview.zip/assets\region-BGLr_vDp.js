const ARCH_META = {
  medium_streaming: {
    label: "Medium · streaming",
    blurb: "Most accurate English model; designed for live audio."
  },
  small_streaming: {
    label: "Small · streaming",
    blurb: "Balanced streaming model; much smaller download."
  },
  tiny_streaming: {
    label: "Tiny · streaming",
    blurb: "Fastest streaming model; ideal for slower machines."
  },
  base_streaming: {
    label: "Base · streaming",
    blurb: "Streaming base model."
  },
  base: {
    label: "Base",
    blurb: "Non-streaming base model for this language."
  },
  tiny: {
    label: "Tiny",
    blurb: "Non-streaming tiny model for this language."
  }
};
const MOONSHINE_LANGUAGES = [
  {
    code: "en",
    name: "English",
    license: "MIT",
    models: [
      { arch: "medium_streaming", sizeMB: 305 },
      { arch: "small_streaming", sizeMB: 166 },
      { arch: "tiny_streaming", sizeMB: 51, default: true },
      { arch: "base", sizeMB: 141 },
      { arch: "tiny", sizeMB: 44 }
    ]
  },
  { code: "es", name: "Spanish", license: "MIT", models: [{ arch: "base", sizeMB: 65 }] },
  { code: "ar", name: "Arabic", license: "MIT", models: [{ arch: "base", sizeMB: 141 }] },
  { code: "ja", name: "Japanese", license: "MIT", models: [
    { arch: "base", sizeMB: 141 },
    { arch: "tiny", sizeMB: 72, default: true }
  ] },
  { code: "zh", name: "Mandarin Chinese", license: "MIT", models: [{ arch: "base", sizeMB: 141 }] },
  { code: "vi", name: "Vietnamese", license: "MIT", models: [{ arch: "base", sizeMB: 141 }] }
];
const DEFAULT_LANGUAGE = "en";
const PARAKEET_MODEL = {
  id: "onnx-community/parakeet-ctc-0.6b-ONNX",
  sizeMB: 642,
  dtype: "q4"
};
const PARAKEET_LANGUAGES = [{ code: "en", name: "English" }];
const PARAKEET_LANGUAGE = PARAKEET_LANGUAGES[0].code;
const PARAKEET_TDT_MODEL = {
  id: "Olicorne/parakeet-tdt-0.6b-v3-ultra-onnx",
  sizeMB: 402
};
const PARAKEET_TDT_LANGUAGE_CODES = [
  "bg",
  "hr",
  "cs",
  "da",
  "nl",
  "en",
  "et",
  "fi",
  "fr",
  "de",
  "el",
  "hu",
  "it",
  "lv",
  "lt",
  "mt",
  "pl",
  "pt",
  "ro",
  "sk",
  "sl",
  "es",
  "sv",
  "ru",
  "uk"
];
const WHISPER_MODEL = "onnx-community/whisper-large-v3-turbo";
const WHISPER_MODEL_SIZE_MB = 1500;
const KOTOBA_MODEL = "onnx-community/kotoba-whisper-v2.2-ONNX";
const KOTOBA_MODEL_SIZE_MB = 534;
const KOTOBA_MODEL_DTYPE = {
  encoder_model: "q4f16",
  decoder_model_merged: "q4f16"
};
function getMoonshineLanguage(code) {
  return MOONSHINE_LANGUAGES.find((language) => language.code === code) ?? MOONSHINE_LANGUAGES[0];
}
function supportsMoonshineLanguage(code) {
  return MOONSHINE_LANGUAGES.some((language) => language.code === code);
}
function defaultArchFor(languageCode) {
  const language = getMoonshineLanguage(languageCode);
  return language.models.find((model) => model.default)?.arch ?? language.models[0].arch;
}
function resolveArch(languageCode, arch) {
  const language = getMoonshineLanguage(languageCode);
  const found = language.models.find((model) => model.arch === arch);
  return found?.arch ?? defaultArchFor(languageCode);
}
function getModelChoice(languageCode, arch) {
  const language = getMoonshineLanguage(languageCode);
  return language.models.find((model) => model.arch === arch) ?? language.models.find((model) => model.default) ?? language.models[0];
}
const WHISPER_LANGUAGES = [
  { code: "af", name: "Afrikaans" },
  { code: "sq", name: "Albanian" },
  { code: "am", name: "Amharic" },
  { code: "ar", name: "Arabic" },
  { code: "hy", name: "Armenian" },
  { code: "as", name: "Assamese" },
  { code: "az", name: "Azerbaijani" },
  { code: "ba", name: "Bashkir" },
  { code: "eu", name: "Basque" },
  { code: "be", name: "Belarusian" },
  { code: "bn", name: "Bengali" },
  { code: "bs", name: "Bosnian" },
  { code: "br", name: "Breton" },
  { code: "bg", name: "Bulgarian" },
  { code: "ca", name: "Catalan" },
  { code: "zh", name: "Chinese" },
  { code: "hr", name: "Croatian" },
  { code: "cs", name: "Czech" },
  { code: "da", name: "Danish" },
  { code: "nl", name: "Dutch" },
  { code: "en", name: "English" },
  { code: "et", name: "Estonian" },
  { code: "fo", name: "Faroese" },
  { code: "fi", name: "Finnish" },
  { code: "fr", name: "French" },
  { code: "gl", name: "Galician" },
  { code: "ka", name: "Georgian" },
  { code: "de", name: "German" },
  { code: "el", name: "Greek" },
  { code: "gu", name: "Gujarati" },
  { code: "ht", name: "Haitian creole" },
  { code: "ha", name: "Hausa" },
  { code: "haw", name: "Hawaiian" },
  { code: "he", name: "Hebrew" },
  { code: "hi", name: "Hindi" },
  { code: "hu", name: "Hungarian" },
  { code: "is", name: "Icelandic" },
  { code: "id", name: "Indonesian" },
  { code: "it", name: "Italian" },
  { code: "ja", name: "Japanese" },
  { code: "jw", name: "Javanese" },
  { code: "kn", name: "Kannada" },
  { code: "kk", name: "Kazakh" },
  { code: "km", name: "Khmer" },
  { code: "ko", name: "Korean" },
  { code: "lo", name: "Lao" },
  { code: "la", name: "Latin" },
  { code: "lv", name: "Latvian" },
  { code: "ln", name: "Lingala" },
  { code: "lt", name: "Lithuanian" },
  { code: "lb", name: "Luxembourgish" },
  { code: "mk", name: "Macedonian" },
  { code: "mg", name: "Malagasy" },
  { code: "ms", name: "Malay" },
  { code: "ml", name: "Malayalam" },
  { code: "mt", name: "Maltese" },
  { code: "mi", name: "Maori" },
  { code: "mr", name: "Marathi" },
  { code: "mn", name: "Mongolian" },
  { code: "my", name: "Myanmar" },
  { code: "ne", name: "Nepali" },
  { code: "no", name: "Norwegian" },
  { code: "nn", name: "Nynorsk" },
  { code: "oc", name: "Occitan" },
  { code: "ps", name: "Pashto" },
  { code: "fa", name: "Persian" },
  { code: "pl", name: "Polish" },
  { code: "pt", name: "Portuguese" },
  { code: "pa", name: "Punjabi" },
  { code: "ro", name: "Romanian" },
  { code: "ru", name: "Russian" },
  { code: "sa", name: "Sanskrit" },
  { code: "sr", name: "Serbian" },
  { code: "sn", name: "Shona" },
  { code: "sd", name: "Sindhi" },
  { code: "si", name: "Sinhala" },
  { code: "sk", name: "Slovak" },
  { code: "sl", name: "Slovenian" },
  { code: "so", name: "Somali" },
  { code: "es", name: "Spanish" },
  { code: "su", name: "Sundanese" },
  { code: "sw", name: "Swahili" },
  { code: "sv", name: "Swedish" },
  { code: "tl", name: "Tagalog" },
  { code: "tg", name: "Tajik" },
  { code: "ta", name: "Tamil" },
  { code: "tt", name: "Tatar" },
  { code: "te", name: "Telugu" },
  { code: "th", name: "Thai" },
  { code: "bo", name: "Tibetan" },
  { code: "tr", name: "Turkish" },
  { code: "tk", name: "Turkmen" },
  { code: "uk", name: "Ukrainian" },
  { code: "ur", name: "Urdu" },
  { code: "uz", name: "Uzbek" },
  { code: "vi", name: "Vietnamese" },
  { code: "cy", name: "Welsh" },
  { code: "yi", name: "Yiddish" },
  { code: "yo", name: "Yoruba" }
];
function getWhisperLanguage(code) {
  return WHISPER_LANGUAGES.find((language) => language.code === code);
}
function isWhisperLanguage(code) {
  return getWhisperLanguage(code) !== void 0;
}
const SETTINGS_VERSION = 2;
const DEFAULT_SETTINGS = {
  moonshine: {
    language: DEFAULT_LANGUAGE,
    modelArch: defaultArchFor(DEFAULT_LANGUAGE)
  },
  whisper: {
    language: DEFAULT_LANGUAGE
  },
  translation: {
    enabled: false,
    provider: "chrome",
    targetLanguage: "en"
  },
  overlay: {
    fontSize: 24,
    maxLines: 2,
    offset: 96,
    opacity: 0.85,
    showInterim: true,
    hideDelayMs: 4500
  }
};
function isRecord(value) {
  return typeof value === "object" && value !== null;
}
function pickNumber(value, fallback, min, max) {
  if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
  return Math.min(max, Math.max(min, value));
}
function pickString(value, fallback) {
  return typeof value === "string" ? value : fallback;
}
function pickBoolean(value, fallback) {
  return typeof value === "boolean" ? value : fallback;
}
function pickEngine(rawEngine, rawVersion) {
  if (rawEngine === "whisper") return "whisper";
  if (rawEngine === "parakeet") return "parakeet";
  if (rawEngine === "moonshine") {
    const version = typeof rawVersion === "number" ? rawVersion : 0;
    return version >= SETTINGS_VERSION ? "moonshine" : "auto";
  }
  return "auto";
}
function normalizeSettings(input) {
  const raw = isRecord(input) ? input : {};
  const rawMoonshine = isRecord(raw.moonshine) ? raw.moonshine : {};
  const rawWhisper = isRecord(raw.whisper) ? raw.whisper : {};
  const rawTranslation = isRecord(raw.translation) ? raw.translation : {};
  const rawOverlay = isRecord(raw.overlay) ? raw.overlay : {};
  const language = getMoonshineLanguage(
    pickString(rawMoonshine.language, DEFAULT_SETTINGS.moonshine.language)
  ).code;
  const whisperLanguage = pickString(rawWhisper.language, DEFAULT_SETTINGS.whisper.language);
  const engine = pickEngine(raw.engine, raw.version);
  const position = rawOverlay.position === "top" ? "top" : "bottom";
  const translationProvider = rawTranslation.provider === "hunyuan" ? "hunyuan" : DEFAULT_SETTINGS.translation.provider;
  const translationDisplay = rawTranslation.display === "both" ? "both" : rawTranslation.display === "source" ? "source" : "translation";
  return {
    version: SETTINGS_VERSION,
    engine,
    moonshine: {
      language,
      modelArch: resolveArch(language, pickString(rawMoonshine.modelArch, ""))
    },
    whisper: {
      language: isWhisperLanguage(whisperLanguage) ? whisperLanguage : DEFAULT_SETTINGS.whisper.language
    },
    translation: {
      enabled: pickBoolean(rawTranslation.enabled, DEFAULT_SETTINGS.translation.enabled),
      provider: translationProvider,
      targetLanguage: pickString(
        rawTranslation.targetLanguage,
        DEFAULT_SETTINGS.translation.targetLanguage
      ),
      display: translationDisplay
    },
    overlay: {
      fontSize: pickNumber(rawOverlay.fontSize, DEFAULT_SETTINGS.overlay.fontSize, 12, 72),
      maxLines: Math.round(
        pickNumber(rawOverlay.maxLines, DEFAULT_SETTINGS.overlay.maxLines, 1, 6)
      ),
      position,
      offset: pickNumber(rawOverlay.offset, DEFAULT_SETTINGS.overlay.offset, 0, 2e3),
      opacity: pickNumber(rawOverlay.opacity, DEFAULT_SETTINGS.overlay.opacity, 0.2, 1),
      showInterim: pickBoolean(rawOverlay.showInterim, DEFAULT_SETTINGS.overlay.showInterim),
      hideDelayMs: pickNumber(
        rawOverlay.hideDelayMs,
        DEFAULT_SETTINGS.overlay.hideDelayMs,
        0,
        6e4
      )
    }
  };
}
function engineSignature(settings) {
  return JSON.stringify({
    engine: settings.engine,
    language: settings.moonshine.language,
    modelArch: settings.moonshine.modelArch,
    whisperLanguage: settings.whisper.language
  });
}
function spokenLanguage(settings) {
  if (settings.engine === "moonshine") return settings.moonshine.language;
  if (settings.engine === "parakeet") return PARAKEET_LANGUAGE;
  return settings.whisper.language;
}
function translationSignature(settings) {
  return JSON.stringify({
    enabled: settings.translation.enabled,
    provider: settings.translation.provider,
    targetLanguage: settings.translation.targetLanguage,
    sourceLanguage: spokenLanguage(settings)
  });
}
const RESTRICTED_REGION_CODES = /* @__PURE__ */ new Set([
  // European Union
  "AT",
  "BE",
  "BG",
  "HR",
  "CY",
  "CZ",
  "DK",
  "EE",
  "FI",
  "FR",
  "DE",
  "GR",
  "HU",
  "IE",
  "IT",
  "LV",
  "LT",
  "LU",
  "MT",
  "NL",
  "PL",
  "PT",
  "RO",
  "SK",
  "SI",
  "ES",
  "SE",
  // United Kingdom
  "GB",
  // South Korea
  "KR"
]);
const RESTRICTED_TIMEZONES = /* @__PURE__ */ new Set([
  // EU member states
  "Europe/Amsterdam",
  "Europe/Athens",
  "Europe/Berlin",
  "Europe/Bratislava",
  "Europe/Brussels",
  "Europe/Bucharest",
  "Europe/Budapest",
  "Europe/Busingen",
  "Europe/Copenhagen",
  "Europe/Dublin",
  "Europe/Helsinki",
  "Europe/Lisbon",
  "Europe/Ljubljana",
  "Europe/Luxembourg",
  "Europe/Madrid",
  "Europe/Malta",
  "Europe/Paris",
  "Europe/Prague",
  "Europe/Riga",
  "Europe/Rome",
  "Europe/Sofia",
  "Europe/Stockholm",
  "Europe/Tallinn",
  "Europe/Vienna",
  "Europe/Vilnius",
  "Europe/Warsaw",
  "Europe/Zagreb",
  "Asia/Nicosia",
  "Europe/Nicosia",
  // EU territories outside the mainland
  "Africa/Ceuta",
  "Atlantic/Azores",
  "Atlantic/Canary",
  "Atlantic/Madeira",
  "America/Cayenne",
  "America/Guadeloupe",
  "America/Marigot",
  "America/Martinique",
  "America/St_Barthelemy",
  "Indian/Mayotte",
  "Indian/Reunion",
  // United Kingdom and Crown Dependencies
  "Europe/London",
  "Europe/Belfast",
  "Europe/Guernsey",
  "Europe/Isle_of_Man",
  "Europe/Jersey",
  // South Korea
  "Asia/Seoul"
]);
function regionFromLocale(locale) {
  if (typeof locale !== "string" || locale.length === 0) return null;
  try {
    const parsed = new Intl.Locale(locale);
    if (parsed.region) return parsed.region.toUpperCase();
    return parsed.maximize().region?.toUpperCase() ?? null;
  } catch {
    return null;
  }
}
function isRestrictedRegion(signals) {
  const timeZone = signals.timeZone;
  if (typeof timeZone === "string" && RESTRICTED_TIMEZONES.has(timeZone)) return true;
  return signals.locales.some((locale) => {
    const region = regionFromLocale(locale);
    return region !== null && RESTRICTED_REGION_CODES.has(region);
  });
}
function readRegionSignals() {
  const locales = [];
  try {
    if (typeof chrome !== "undefined" && chrome.i18n) {
      locales.push(chrome.i18n.getUILanguage());
    }
  } catch {
  }
  if (typeof navigator !== "undefined") {
    if (typeof navigator.language === "string") locales.push(navigator.language);
    if (Array.isArray(navigator.languages)) locales.push(...navigator.languages);
  }
  let timeZone = null;
  try {
    timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone ?? null;
  } catch {
    timeZone = null;
  }
  return { timeZone, locales };
}
let cachedRestricted = null;
function detectHunyuanRestricted() {
  cachedRestricted ??= isRestrictedRegion(readRegionSignals());
  return cachedRestricted;
}
export {
  ARCH_META as A,
  KOTOBA_MODEL_SIZE_MB as K,
  MOONSHINE_LANGUAGES as M,
  PARAKEET_MODEL as P,
  WHISPER_LANGUAGES as W,
  PARAKEET_TDT_LANGUAGE_CODES as a,
  PARAKEET_TDT_MODEL as b,
  KOTOBA_MODEL as c,
  detectHunyuanRestricted as d,
  engineSignature as e,
  WHISPER_MODEL_SIZE_MB as f,
  WHISPER_MODEL as g,
  getMoonshineLanguage as h,
  getModelChoice as i,
  getWhisperLanguage as j,
  KOTOBA_MODEL_DTYPE as k,
  supportsMoonshineLanguage as l,
  isWhisperLanguage as m,
  defaultArchFor as n,
  PARAKEET_LANGUAGES as o,
  normalizeSettings as p,
  resolveArch as r,
  spokenLanguage as s,
  translationSignature as t
};
