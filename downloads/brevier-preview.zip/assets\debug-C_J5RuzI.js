import { b as bestModelFor, c as createEngine, H as HunyuanTranslationProvider } from "./provider-DRyXc1qw.js";
import { s as spokenLanguage, d as detectHunyuanRestricted } from "./region-C_na-waw.js";
import { l as loadSettings } from "./storage-BlCx6vQE.js";
import { c as chromeTranslatorApi, p as probeChromeTranslation } from "./translation-languages-BWIVOYyr.js";
function element(id) {
  const found = document.getElementById(id);
  if (!found) throw new Error(`Missing element #${id}`);
  return found;
}
const ui = {
  env: element("env"),
  licenseBox: element("licenseBox"),
  licensePro: element("licensePro"),
  licenseFree: element("licenseFree"),
  licenseState: element("licenseState"),
  usageBox: element("usageBox"),
  usageReset: element("usageReset"),
  usageDrain: element("usageDrain"),
  usageState: element("usageState"),
  load: element("load"),
  stop: element("stop"),
  clear: element("clear"),
  trProbe: element("trProbe"),
  trInput: element("trInput"),
  trTest: element("trTest"),
  trHunyuan: element("trHunyuan"),
  trClear: element("trClear"),
  log: element("log")
};
function log(message) {
  const line = `[${(/* @__PURE__ */ new Date()).toLocaleTimeString()}] ${message}`;
  ui.log.textContent += `${line}
`;
  console.log("[diagnostics]", line);
}
const manifest = chrome.runtime.getManifest();
ui.env.textContent = [
  `extension ${manifest.version}`,
  `crossOriginIsolated=${self.crossOriginIsolated}`,
  `hardwareConcurrency=${navigator.hardwareConcurrency}`,
  `SharedArrayBuffer=${typeof SharedArrayBuffer !== "undefined" ? "yes" : "no"}`,
  navigator.userAgent
].join(" · ");
let engine = null;
let lastProgressAt = 0;
ui.load.addEventListener("click", () => {
  void (async () => {
    const settings = await loadSettings();
    const language = spokenLanguage(settings);
    const model = settings.engine === "moonshine" ? settings.moonshine.modelArch : bestModelFor(language)?.model ?? settings.engine;
    log(`loading engine=${settings.engine} language=${language} model=${model}`);
    engine = createEngine(settings.engine);
    ui.load.disabled = true;
    ui.stop.disabled = false;
    try {
      await engine.initialize({
        settings,
        events: {
          onStatus: (status, detail) => log(`status: ${status}${detail ? ` — ${detail}` : ""}`),
          onProgress: (progress) => {
            if (!progress) {
              log("download progress: complete");
              return;
            }
            const now = Date.now();
            const percent = progress.total ? Math.round(progress.loaded / progress.total * 100) : null;
            if (now - lastProgressAt > 1e3 || percent === 100) {
              lastProgressAt = now;
              log(`download: ${percent === null ? "…" : `${percent}%`} ${progress.file}`);
            }
          },
          onCaption: (event) => log(`caption (${event.kind}): ${event.text}`),
          onError: (error) => log(`ENGINE ERROR: ${error.message}`),
          onLog: (message) => log(`engine: ${message}`)
        }
      });
      await engine.start();
      log("engine ready");
      const sampleRate = 48e3;
      const chunk = new Float32Array(sampleRate / 10);
      for (let i = 0; i < chunk.length; i++) {
        chunk[i] = 0.02 * Math.sin(2 * Math.PI * 440 * i / sampleRate);
      }
      for (let n = 0; n < 30; n++) {
        engine.pushAudio(chunk.slice(), sampleRate);
        await new Promise((resolve) => setTimeout(resolve, 50));
      }
      log("fed 3s of test audio");
      await engine.stop();
      log("stopped");
    } catch (error) {
      log(`FAILED: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      ui.load.disabled = false;
    }
  })();
});
ui.stop.addEventListener("click", () => {
  void (async () => {
    await engine?.dispose();
    engine = null;
    ui.stop.disabled = true;
    log("engine disposed");
  })();
});
ui.clear.addEventListener("click", () => {
  void (async () => {
    const deleted = await caches.delete("moonshine-models-v1");
    log(`clear cached models: ${deleted ? "deleted" : "nothing cached"}`);
  })();
});
ui.trProbe.addEventListener("click", () => {
  void (async () => {
    const settings = await loadSettings();
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    log(`Translator API present: ${chromeTranslatorApi() ? "yes" : "no"}`);
    log(`translation availability ${source} → ${target}: ${await probeChromeTranslation(source, target)}`);
  })();
});
ui.trTest.addEventListener("click", () => {
  void (async () => {
    const settings = await loadSettings();
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    const api = chromeTranslatorApi();
    if (!api) {
      log("Translator API not available in this browser.");
      return;
    }
    ui.trTest.disabled = true;
    try {
      log(`creating translator ${source} → ${target}…`);
      const translator = await api.create({
        sourceLanguage: source,
        targetLanguage: target,
        monitor: (monitor) => {
          monitor.addEventListener("downloadprogress", (event) => {
            const loaded = event.loaded ?? 0;
            log(`translation model download: ${Math.round(loaded * 100)}%`);
          });
        }
      });
      const text = ui.trInput.value.trim() || "It was the best of times.";
      log(`translating: ${text}`);
      log(`result: ${await translator.translate(text)}`);
      translator.destroy();
    } catch (error) {
      log(`TRANSLATION ERROR: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      ui.trTest.disabled = false;
    }
  })();
});
ui.trClear.addEventListener("click", () => {
  void (async () => {
    const deleted = await caches.delete("transformers-cache");
    log(`clear cached translation models: ${deleted ? "deleted" : "nothing cached"}`);
  })();
});
if (detectHunyuanRestricted()) {
  ui.trHunyuan.disabled = true;
  ui.trHunyuan.title = "Hunyuan-MT is not available in your region";
}
ui.trHunyuan.addEventListener("click", () => {
  void (async () => {
    if (detectHunyuanRestricted()) {
      log("Hunyuan-MT is not available in your region");
      return;
    }
    const settings = await loadSettings();
    const text = ui.trInput.value.trim() || "It was the best of times.";
    const provider = new HunyuanTranslationProvider();
    ui.trHunyuan.disabled = true;
    let lastProgressAt2 = 0;
    const startedAt = Date.now();
    try {
      log(
        `Hunyuan-MT ${spokenLanguage(settings)} → ${settings.translation.targetLanguage}: preparing…`
      );
      await provider.initialize({
        sourceLanguage: spokenLanguage(settings),
        targetLanguage: settings.translation.targetLanguage,
        settings: settings.translation,
        onProgress: (progress) => {
          if (!progress) {
            log("Hunyuan-MT model ready");
            return;
          }
          const now = Date.now();
          if (now - lastProgressAt2 < 1e3) return;
          lastProgressAt2 = now;
          const percent = progress.fraction === null ? "…" : `${Math.round(progress.fraction * 100)}%`;
          log(`Hunyuan-MT download: ${percent} ${progress.detail}`);
        }
      });
      log(`Hunyuan-MT ready in ${((Date.now() - startedAt) / 1e3).toFixed(1)}s`);
      log(`translating: ${text}`);
      const result = await provider.translate(text);
      log(`result (${Date.now() - startedAt}ms total): ${result}`);
    } catch (error) {
      log(`Hunyuan-MT ERROR: ${error instanceof Error ? error.message : String(error)}`);
    } finally {
      provider.dispose();
      ui.trHunyuan.disabled = false;
    }
  })();
});
log("diagnostics page ready");
