(function() {
  "use strict";
  function isBackgroundToContent(message) {
    if (typeof message !== "object" || message === null) return false;
    const type = message.type;
    return type === "content:bind" || type === "content:unbind" || type === "content:caption" || type === "content:settings" || type === "content:status";
  }
  const DEFAULT_LANGUAGE = "en";
  const LANGUAGE_NAMES = {
    ar: "Arabic",
    bg: "Bulgarian",
    cs: "Czech",
    da: "Danish",
    de: "German",
    el: "Greek",
    en: "English",
    es: "Spanish",
    et: "Estonian",
    fa: "Persian",
    fi: "Finnish",
    fil: "Filipino",
    fr: "French",
    hi: "Hindi",
    hr: "Croatian",
    hu: "Hungarian",
    id: "Indonesian",
    it: "Italian",
    ja: "Japanese",
    ko: "Korean",
    lt: "Lithuanian",
    lv: "Latvian",
    mk: "Macedonian",
    ms: "Malay",
    mt: "Maltese",
    nl: "Dutch",
    pl: "Polish",
    pt: "Portuguese",
    ro: "Romanian",
    ru: "Russian",
    sk: "Slovak",
    sl: "Slovenian",
    sv: "Swedish",
    th: "Thai",
    tr: "Turkish",
    uk: "Ukrainian",
    vi: "Vietnamese",
    yue: "Cantonese",
    zh: "Chinese (Mandarin)"
  };
  function options(codes) {
    return codes.map((code) => ({ code, name: LANGUAGE_NAMES[code] })).sort((a, b) => a.name.localeCompare(b.name));
  }
  const QWEN_LANGUAGE_CODES = [
    "ar",
    "cs",
    "da",
    "de",
    "el",
    "en",
    "es",
    "fa",
    "fi",
    "fil",
    "fr",
    "hi",
    "hu",
    "id",
    "it",
    "ja",
    "ko",
    "mk",
    "ms",
    "nl",
    "pl",
    "pt",
    "ro",
    "ru",
    "sv",
    "th",
    "tr",
    "vi",
    "yue",
    "zh"
  ];
  options(QWEN_LANGUAGE_CODES);
  const PARAKEET_TDT_LANGUAGE_CODES = [
    "bg",
    "hr",
    "cs",
    "da",
    "nl",
    "en",
    "et",
    "fi",
    "fr",
    "de",
    "el",
    "hu",
    "it",
    "lv",
    "lt",
    "mt",
    "pl",
    "pt",
    "ro",
    "sk",
    "sl",
    "es",
    "sv",
    "ru",
    "uk"
  ];
  options(PARAKEET_TDT_LANGUAGE_CODES);
  options(["ja"]);
  const PARAKEET_LANGUAGE = "ja";
  const SUPPORTED_LANGUAGE_CODES = Array.from(
    /* @__PURE__ */ new Set([...QWEN_LANGUAGE_CODES, ...PARAKEET_TDT_LANGUAGE_CODES, PARAKEET_LANGUAGE])
  );
  options(SUPPORTED_LANGUAGE_CODES);
  const QWEN_SET = new Set(QWEN_LANGUAGE_CODES);
  const TDT_SET = new Set(PARAKEET_TDT_LANGUAGE_CODES);
  const SUPPORTED_SET = new Set(SUPPORTED_LANGUAGE_CODES);
  function supportsQwenLanguage(code) {
    return QWEN_SET.has(code);
  }
  function supportsParakeetTdtLanguage(code) {
    return TDT_SET.has(code);
  }
  function isSupportedLanguage(code) {
    return SUPPORTED_SET.has(code);
  }
  const DEFAULT_QWEN_MODEL = "0.6b";
  function isQwenModelSize(value) {
    return value === "0.6b" || value === "1.7b";
  }
  const SETTINGS_VERSION = 3;
  const PARAKEET_JAPANESE_VERSION = 3;
  const DEFAULT_SETTINGS = {
    translation: {
      enabled: false,
      provider: "chrome",
      targetLanguage: "en",
      display: "translation"
    },
    overlay: {
      fontSize: 24,
      maxLines: 2,
      position: "bottom",
      offset: 96,
      opacity: 0.85,
      showInterim: true,
      hideDelayMs: 4500
    }
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function pickNumber(value, fallback, min, max) {
    if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
    return Math.min(max, Math.max(min, value));
  }
  function pickString(value, fallback) {
    return typeof value === "string" ? value : fallback;
  }
  function pickBoolean(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function pickEngine(rawEngine) {
    if (rawEngine === "qwen") return "qwen";
    if (rawEngine === "parakeet") return "parakeet";
    if (rawEngine === "parakeet-tdt") return "parakeet-tdt";
    return "auto";
  }
  function resolveLanguage(engine, code) {
    if (!isSupportedLanguage(code)) return DEFAULT_LANGUAGE;
    if (engine === "parakeet") return PARAKEET_LANGUAGE;
    if (engine === "parakeet-tdt" && !supportsParakeetTdtLanguage(code)) return DEFAULT_LANGUAGE;
    if (engine === "qwen" && !supportsQwenLanguage(code)) return DEFAULT_LANGUAGE;
    return code;
  }
  function normalizeSettings(input) {
    const raw = isRecord(input) ? input : {};
    const rawWhisper = isRecord(raw.whisper) ? raw.whisper : {};
    const rawMoonshine = isRecord(raw.moonshine) ? raw.moonshine : {};
    const rawTranslation = isRecord(raw.translation) ? raw.translation : {};
    const rawOverlay = isRecord(raw.overlay) ? raw.overlay : {};
    const rawVersion = typeof raw.version === "number" ? raw.version : 0;
    const legacyParakeet = raw.engine === "parakeet" && rawVersion < PARAKEET_JAPANESE_VERSION;
    const legacyLanguage = raw.engine === "moonshine" ? pickString(rawMoonshine.language, "") : raw.engine === "whisper" ? pickString(rawWhisper.language, "") : "";
    const storedLanguage = legacyParakeet ? DEFAULT_LANGUAGE : pickString(
      raw.language,
      legacyLanguage || pickString(rawWhisper.language, pickString(rawMoonshine.language, DEFAULT_LANGUAGE))
    );
    const engine = legacyParakeet ? "auto" : pickEngine(raw.engine);
    const language = resolveLanguage(engine, storedLanguage);
    const position = rawOverlay.position === "top" ? "top" : "bottom";
    const qwenModel = isQwenModelSize(raw.qwenModel) ? raw.qwenModel : DEFAULT_QWEN_MODEL;
    const translationProvider = rawTranslation.provider === "hymt2" || rawTranslation.provider === "hunyuan" ? "hymt2" : DEFAULT_SETTINGS.translation.provider;
    const translationDisplay = rawTranslation.display === "both" ? "both" : rawTranslation.display === "source" ? "source" : "translation";
    return {
      version: SETTINGS_VERSION,
      engine,
      language,
      qwenModel,
      translation: {
        enabled: pickBoolean(rawTranslation.enabled, DEFAULT_SETTINGS.translation.enabled),
        provider: translationProvider,
        targetLanguage: pickString(
          rawTranslation.targetLanguage,
          DEFAULT_SETTINGS.translation.targetLanguage
        ),
        display: translationDisplay
      },
      overlay: {
        fontSize: pickNumber(rawOverlay.fontSize, DEFAULT_SETTINGS.overlay.fontSize, 12, 72),
        maxLines: Math.round(
          pickNumber(rawOverlay.maxLines, DEFAULT_SETTINGS.overlay.maxLines, 1, 6)
        ),
        position,
        offset: pickNumber(rawOverlay.offset, DEFAULT_SETTINGS.overlay.offset, 0, 2e3),
        opacity: pickNumber(rawOverlay.opacity, DEFAULT_SETTINGS.overlay.opacity, 0.2, 1),
        showInterim: pickBoolean(rawOverlay.showInterim, DEFAULT_SETTINGS.overlay.showInterim),
        hideDelayMs: pickNumber(
          rawOverlay.hideDelayMs,
          DEFAULT_SETTINGS.overlay.hideDelayMs,
          0,
          6e4
        )
      }
    };
  }
  function normalizeOverlayPosition(input) {
    if (!isRecord(input)) return null;
    const left = input.left;
    const top = input.top;
    if (typeof left !== "number" || typeof top !== "number") return null;
    if (!Number.isFinite(left) || !Number.isFinite(top)) return null;
    return { left, top };
  }
  const SETTINGS_KEY = "settings";
  const POSITION_KEY = "overlayPosition";
  Promise.resolve();
  function watchSettings(callback) {
    const listener = (changes, areaName) => {
      if (!(SETTINGS_KEY in changes)) return;
      callback(normalizeSettings(changes[SETTINGS_KEY].newValue), areaName);
    };
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }
  async function loadOverlayPosition() {
    const stored = await chrome.storage.local.get(POSITION_KEY);
    return normalizeOverlayPosition(stored[POSITION_KEY]);
  }
  async function saveOverlayPosition(position) {
    if (position === null) {
      await chrome.storage.local.remove(POSITION_KEY);
      return;
    }
    await chrome.storage.local.set({ [POSITION_KEY]: position });
  }
  const WIDE_CHAR = /[\u1100-\u115f\u2e80-\ua4cf\ua960-\ua97f\uac00-\ud7ff\uf900-\ufaff\ufe10-\ufe19\ufe30-\ufe6f\uff00-\uff60\uffe0-\uffe6\u3000-\u303f\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/u;
  const JAPANESE_BREAK = /[、。！？!?，,.・…ー）」』】]/u;
  const JAPANESE_LINE_UNITS = 15;
  const LATIN_LINE_UNITS = 21;
  function charUnits(char) {
    return WIDE_CHAR.test(char) ? 1 : 0.5;
  }
  function textUnits(text) {
    let units = 0;
    for (const char of text) units += charUnits(char);
    return units;
  }
  function isJapanese(text) {
    let wide = 0;
    let visible = 0;
    for (const char of text) {
      if (/\s/u.test(char)) continue;
      visible += 1;
      if (WIDE_CHAR.test(char)) wide += 1;
    }
    return visible > 0 && wide / visible >= 0.25;
  }
  function wrapSubtitleText(text, maxLines) {
    const normalized = text.replace(/\s+/gu, " ").trim();
    if (!normalized) return [];
    const rows = Math.max(1, Math.round(maxLines));
    const japanese = isJapanese(normalized);
    const width = japanese ? JAPANESE_LINE_UNITS : LATIN_LINE_UNITS;
    const breaks = japanese ? JAPANESE_BREAK : / /u;
    const lines = [];
    let current = "";
    let units = 0;
    let lastBreak = -1;
    const append = (char) => {
      current += char;
      units += charUnits(char);
      if (breaks.test(char)) lastBreak = current.length;
    };
    const reindex = () => {
      units = textUnits(current);
      lastBreak = -1;
      for (let index = 0; index < current.length; index++) {
        if (breaks.test(current[index])) lastBreak = index + 1;
      }
    };
    for (const char of normalized) {
      if (current && units + charUnits(char) > width) {
        if (lastBreak > 0 && lastBreak < current.length) {
          lines.push(current.slice(0, lastBreak).trim());
          current = current.slice(lastBreak);
          reindex();
        } else {
          lines.push(current.trim());
          current = "";
          units = 0;
          lastBreak = -1;
        }
      }
      append(char);
    }
    if (current.trim()) lines.push(current.trim());
    return lines.length > rows ? lines.slice(-rows) : lines;
  }
  const HOST_ID = "brevier-host";
  const DRAG_THRESHOLD_PX = 3;
  const STYLES = `
  :host {
    all: initial;

    --lc-overlay-surface-rgb: 15 23 42;
    --lc-overlay-text: #f8fafc;
    --lc-overlay-interim: #cbd5e1;
    --lc-overlay-translation: #7dd3fc;
    --lc-overlay-placeholder: #94a3b8;
    --lc-overlay-grip: rgba(248, 250, 252, 0.28);
    --lc-overlay-grip-hover: rgba(248, 250, 252, 0.5);
    --lc-overlay-shadow: rgba(2, 6, 23, 0.45);
    --lc-overlay-live: #f87171;
  }

  .bar {
    position: fixed;
    z-index: 2147483647;
    left: 50%;
    transform: translateX(-50%);
    box-sizing: border-box;
    max-width: min(84vw, 1100px);
    min-width: 180px;
    padding: 17px 18px 10px;
    border-radius: 12px;
    background: rgb(var(--lc-overlay-surface-rgb) / var(--lc-opacity, 0.85));
    color: var(--lc-overlay-text);
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
    font-size: var(--lc-font-size, 24px);
    line-height: 1.35;
    text-align: center;
    text-wrap: pretty;
    box-shadow: 0 8px 28px var(--lc-overlay-shadow);
    pointer-events: none;
    user-select: none;
    transition: opacity 200ms ease;
  }

  .bar.hidden {
    opacity: 0;
    visibility: hidden;
    transition: opacity 200ms ease, visibility 0s linear 200ms;
  }

  .grip {
    position: absolute;
    top: 5px;
    left: 50%;
    transform: translateX(-50%);
    width: 40px;
    height: 8px;
    border-radius: 999px;
    background: var(--lc-overlay-grip);
    cursor: grab;
    pointer-events: auto;
    touch-action: none;
  }

  .grip:hover {
    background: var(--lc-overlay-grip-hover);
  }

  .bar.hidden .grip {
    pointer-events: none;
  }

  .bar.dragging .grip {
    cursor: grabbing;
  }

  .bar.preset-bottom {
    bottom: var(--lc-offset, 96px);
  }

  .bar.preset-top {
    top: var(--lc-offset, 96px);
  }

  .bar.custom {
    bottom: auto;
    top: auto;
    transform: none;
  }

  .lines {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .line {
    margin: 0;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }

  .line.interim {
    color: var(--lc-overlay-interim);
    opacity: 0.92;
  }

  .line.translation {
    color: var(--lc-overlay-translation);
    font-size: 0.92em;
  }

  .line.placeholder {
    color: var(--lc-overlay-placeholder);
    font-style: italic;
  }

  .dot {
    position: fixed;
    z-index: 2147483647;
    left: 50%;
    transform: translateX(-50%);
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: var(--lc-overlay-live);
    box-shadow: 0 0 0 3px rgb(248 113 113 / 0.18);
    opacity: 0;
    pointer-events: none;
    transition: opacity 200ms ease;
  }

  .dot.visible {
    opacity: 0.7;
  }

  .dot.preset-bottom {
    bottom: var(--lc-offset, 96px);
  }

  .dot.preset-top {
    top: var(--lc-offset, 96px);
  }

  .dot.custom {
    bottom: auto;
    top: auto;
    transform: none;
  }
`;
  class CaptionOverlay {
    host;
    bar;
    grip;
    linesEl;
    dot;
    settings = DEFAULT_SETTINGS.overlay;
    display = DEFAULT_SETTINGS.translation.display;
    finals = [];
    interim = null;
    status = null;
    active = false;
    /** True while active but no caption has arrived yet. */
    listening = false;
    hideTimer = null;
    position = null;
    drag = null;
    constructor() {
      this.host = document.createElement("div");
      this.host.id = HOST_ID;
      this.host.style.display = "none";
      this.host.setAttribute("popover", "manual");
      const root = this.host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = STYLES;
      this.bar = document.createElement("div");
      this.bar.className = "bar preset-bottom hidden";
      this.grip = document.createElement("div");
      this.grip.className = "grip";
      this.grip.title = "Drag to move — double-click to reset";
      this.linesEl = document.createElement("div");
      this.linesEl.className = "lines";
      this.bar.append(this.grip, this.linesEl);
      this.dot = document.createElement("div");
      this.dot.className = "dot preset-bottom";
      root.append(style, this.bar, this.dot);
      this.syncFullscreen();
      this.grip.addEventListener("pointerdown", this.onPointerDown);
      this.grip.addEventListener("pointermove", this.onPointerMove);
      this.grip.addEventListener("pointerup", this.onPointerUp);
      this.grip.addEventListener("pointercancel", this.onPointerUp);
      this.grip.addEventListener("dblclick", this.onDoubleClick);
      window.addEventListener("resize", this.onResize);
      document.addEventListener("fullscreenchange", this.onFullscreenChange);
      document.addEventListener("webkitfullscreenchange", this.onFullscreenChange);
    }
    /**
     * Keeps the overlay visible across fullscreen changes (see
     * scripts/probe-overlay.mjs):
     *
     *  - Engines with the Popover API keep the host on <html>, out of the
     *    player's fullscreen subtree, and show it in the top layer — the only
     *    way to render over a fullscreen <video> and the only way to survive
     *    sites that rebuild their fullscreen container (YouTube and friends);
     *  - Engines without popovers fall back to being re-parented into a
     *    non-video fullscreen container.
     *
     * Chrome keeps routing input to the fullscreen element, so the overlay
     * cannot swallow clicks there.
     */
    syncFullscreen() {
      const fullscreen = this.fullscreenElement();
      const popover = typeof this.host.showPopover === "function";
      const target = !popover && fullscreen && !(fullscreen instanceof HTMLVideoElement) ? fullscreen : document.documentElement;
      this.hideTopLayer();
      if (this.host.parentNode !== target) {
        target.append(this.host);
        this.applyPosition();
      }
      if (this.active && fullscreen && !this.bar.classList.contains("hidden")) {
        this.showTopLayer();
      }
    }
    fullscreenElement() {
      const prefixed = document.webkitFullscreenElement;
      return document.fullscreenElement ?? prefixed ?? null;
    }
    showTopLayer() {
      if (typeof this.host.showPopover !== "function") return;
      try {
        if (!this.host.matches(":popover-open")) this.host.showPopover();
      } catch {
      }
    }
    hideTopLayer() {
      if (typeof this.host.hidePopover !== "function") return;
      try {
        if (this.host.matches(":popover-open")) this.host.hidePopover();
      } catch {
      }
    }
    restorePosition(position) {
      this.position = position;
      this.applyPosition();
    }
    bind(active, settings, history, status) {
      this.applySettings(settings);
      this.active = active;
      this.status = status;
      if (!active) {
        this.hide();
        this.clear();
        this.host.style.display = "none";
        this.hideTopLayer();
        this.syncDot();
        return;
      }
      this.host.style.display = "block";
      this.syncFullscreen();
      this.finals = history.filter((event) => event.kind === "final").slice(-this.settings.maxLines);
      this.interim = null;
      this.listening = this.finals.length === 0;
      this.render();
      this.show();
      const busy = this.status !== null && (this.status.pipeline !== "ready" || this.status.translation === "loading");
      if (!this.listening && !busy) {
        this.scheduleHide();
      }
    }
    unbind() {
      this.active = false;
      this.host.style.display = "none";
      this.hideTopLayer();
      this.clear();
      this.syncDot();
    }
    /** Keeps the overlay honest while a model loads or translation catches up. */
    setStatus(status) {
      this.status = status;
      if (!this.active) return;
      this.render();
      const busy = status.pipeline !== "ready" || status.translation === "loading";
      if (busy) {
        if (this.hideTimer !== null) {
          window.clearTimeout(this.hideTimer);
          this.hideTimer = null;
        }
        this.show();
      } else if (this.active && !this.bar.classList.contains("hidden")) {
        this.scheduleHide();
      }
    }
    applySettings(settings) {
      this.settings = settings.overlay;
      this.display = settings.translation.display;
      this.bar.style.setProperty("--lc-font-size", `${settings.overlay.fontSize}px`);
      this.bar.style.setProperty("--lc-offset", `${settings.overlay.offset}px`);
      this.dot.style.setProperty("--lc-offset", `${settings.overlay.offset}px`);
      this.bar.style.setProperty("--lc-opacity", `${settings.overlay.opacity}`);
      this.finals = this.finals.slice(-settings.overlay.maxLines);
      this.applyPosition();
      this.render();
    }
    pushCaption(event) {
      if (!this.active) return;
      this.listening = false;
      if (event.kind === "interim") {
        this.interim = event;
      } else {
        const index = event.lineId ? this.finals.findIndex((item) => item.kind === "final" && item.lineId === event.lineId) : -1;
        if (index >= 0) {
          const next = this.finals.slice();
          next[index] = event;
          this.finals = next;
        } else {
          this.finals = [...this.finals, event].slice(-Math.max(1, this.settings.maxLines));
        }
        if (this.interim && (!event.lineId || event.lineId === this.interim.lineId)) {
          this.interim = null;
        }
      }
      this.render();
      this.show();
      this.scheduleHide();
    }
    clear() {
      this.finals = [];
      this.interim = null;
      this.listening = false;
      if (this.hideTimer !== null) {
        window.clearTimeout(this.hideTimer);
        this.hideTimer = null;
      }
      this.render();
    }
    render() {
      this.linesEl.replaceChildren();
      for (const event of this.finals) {
        if (this.display === "source") {
          this.linesEl.append(this.lineElement(event.text, event.kind));
          continue;
        }
        if (this.display === "translation") {
          if (event.translation) {
            this.linesEl.append(this.lineElement(event.translation, "translation"));
          } else {
            this.linesEl.append(this.lineElement(event.text, "interim"));
          }
          continue;
        }
        this.linesEl.append(this.lineElement(event.text, event.kind));
        if (event.translation) {
          this.linesEl.append(this.lineElement(event.translation, "translation"));
        }
      }
      if (this.settings.showInterim && this.interim?.text) {
        this.linesEl.append(this.lineElement(this.interim.text, "interim"));
      }
      const note = this.statusNote();
      if (note) {
        this.linesEl.append(this.lineElement(note, "placeholder"));
      } else if (this.listening && this.linesEl.childElementCount === 0) {
        this.linesEl.append(this.lineElement("Captions on — listening…", "placeholder"));
      }
    }
    /**
     * One line that explains why captions are late: model loading, translation
     * preparing, or a translation failure. Null when there is nothing to say.
     */
    statusNote() {
      const status = this.status;
      if (!status) return null;
      if (status.pipeline === "loading" || status.pipeline === "starting") {
        return status.detail || "Loading model…";
      }
      if (status.translation === "loading") {
        return status.translationDetail || "Translating…";
      }
      if (status.translation === "error") {
        return status.translationDetail || "Translation is unavailable.";
      }
      return null;
    }
    lineElement(text, kind) {
      const line = document.createElement("div");
      line.className = `line ${kind}`;
      line.textContent = wrapSubtitleText(text, this.settings.maxLines).join("\n");
      return line;
    }
    show() {
      this.bar.classList.remove("hidden");
      this.syncDot();
      if (this.active && this.fullscreenElement()) this.showTopLayer();
    }
    hide() {
      this.bar.classList.add("hidden");
      this.syncDot();
      this.hideTopLayer();
    }
    /** The dot stands in for the bar once the bar has faded out. */
    syncDot() {
      this.dot.classList.toggle("visible", this.active && this.bar.classList.contains("hidden"));
    }
    scheduleHide() {
      if (this.hideTimer !== null) window.clearTimeout(this.hideTimer);
      if (this.settings.hideDelayMs <= 0) return;
      this.hideTimer = window.setTimeout(() => {
        this.hideTimer = null;
        this.hide();
      }, this.settings.hideDelayMs);
    }
    applyPosition() {
      const presetBottom = this.position === null && this.settings.position === "bottom";
      const presetTop = this.position === null && this.settings.position === "top";
      const custom = this.position !== null;
      this.bar.classList.toggle("preset-bottom", presetBottom);
      this.bar.classList.toggle("preset-top", presetTop);
      this.bar.classList.toggle("custom", custom);
      this.dot.classList.toggle("preset-bottom", presetBottom);
      this.dot.classList.toggle("preset-top", presetTop);
      this.dot.classList.toggle("custom", custom);
      if (this.position === null) {
        this.bar.style.left = "";
        this.bar.style.top = "";
        this.dot.style.left = "";
        this.dot.style.top = "";
        return;
      }
      const rect = this.bar.getBoundingClientRect();
      const maxLeft = Math.max(8, window.innerWidth - rect.width - 8);
      const maxTop = Math.max(8, window.innerHeight - rect.height - 8);
      const left = Math.min(Math.max(8, this.position.left), maxLeft);
      const top = Math.min(Math.max(8, this.position.top), maxTop);
      this.bar.style.left = `${Math.round(left)}px`;
      this.bar.style.top = `${Math.round(top)}px`;
      this.dot.style.left = `${Math.round(left + rect.width / 2 - 5)}px`;
      this.dot.style.top = `${Math.round(top + rect.height / 2 - 5)}px`;
    }
    onPointerDown = (event) => {
      if (event.button !== 0) return;
      const rect = this.bar.getBoundingClientRect();
      this.drag = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        originLeft: rect.left,
        originTop: rect.top,
        moved: false
      };
      this.grip.setPointerCapture(event.pointerId);
    };
    onPointerMove = (event) => {
      if (!this.drag || event.pointerId !== this.drag.pointerId) return;
      const dx = event.clientX - this.drag.startX;
      const dy = event.clientY - this.drag.startY;
      if (!this.drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD_PX) return;
      this.drag.moved = true;
      this.bar.classList.add("dragging");
      this.position = {
        left: this.drag.originLeft + dx,
        top: this.drag.originTop + dy
      };
      this.applyPosition();
    };
    onPointerUp = (event) => {
      if (!this.drag || event.pointerId !== this.drag.pointerId) return;
      const moved = this.drag.moved;
      this.drag = null;
      this.bar.classList.remove("dragging");
      try {
        this.grip.releasePointerCapture(event.pointerId);
      } catch {
      }
      if (moved && this.position) {
        void saveOverlayPosition(this.position);
      }
    };
    onDoubleClick = () => {
      this.position = null;
      void saveOverlayPosition(null);
      this.applyPosition();
    };
    onFullscreenChange = () => {
      this.syncFullscreen();
    };
    onResize = () => {
      this.applyPosition();
    };
  }
  const overlay = new CaptionOverlay();
  void loadOverlayPosition().then((position) => overlay.restorePosition(position));
  watchSettings((settings) => overlay.applySettings(settings));
  chrome.runtime.onMessage.addListener((message) => {
    if (!isBackgroundToContent(message)) return;
    switch (message.type) {
      case "content:bind":
        overlay.bind(message.active, message.settings, message.history, message.status);
        break;
      case "content:unbind":
        overlay.unbind();
        break;
      case "content:caption":
        overlay.pushCaption(message.event);
        break;
      case "content:settings":
        overlay.applySettings(message.settings);
        break;
      case "content:status":
        overlay.setStatus(message.status);
        break;
    }
  });
  void chrome.runtime.sendMessage({ type: "content:ready" }).catch(() => {
  });
})();
