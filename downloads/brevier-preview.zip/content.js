(function() {
  "use strict";
  function isBackgroundToContent(message) {
    if (typeof message !== "object" || message === null) return false;
    const type = message.type;
    return type === "content:bind" || type === "content:unbind" || type === "content:caption" || type === "content:settings";
  }
  const MOONSHINE_LANGUAGES = [
    {
      code: "en",
      name: "English",
      license: "MIT",
      models: [
        { arch: "medium_streaming", sizeMB: 305 },
        { arch: "small_streaming", sizeMB: 166 },
        { arch: "tiny_streaming", sizeMB: 51, default: true },
        { arch: "base", sizeMB: 141 },
        { arch: "tiny", sizeMB: 44 }
      ]
    },
    { code: "es", name: "Spanish", license: "MIT", models: [{ arch: "base", sizeMB: 65 }] },
    { code: "ar", name: "Arabic", license: "MIT", models: [{ arch: "base", sizeMB: 141 }] },
    { code: "ja", name: "Japanese", license: "MIT", models: [
      { arch: "base", sizeMB: 141 },
      { arch: "tiny", sizeMB: 72, default: true }
    ] },
    { code: "zh", name: "Mandarin Chinese", license: "MIT", models: [{ arch: "base", sizeMB: 141 }] },
    { code: "vi", name: "Vietnamese", license: "MIT", models: [{ arch: "base", sizeMB: 141 }] }
  ];
  const DEFAULT_LANGUAGE = "en";
  function getMoonshineLanguage(code) {
    return MOONSHINE_LANGUAGES.find((language) => language.code === code) ?? MOONSHINE_LANGUAGES[0];
  }
  function defaultArchFor(languageCode) {
    const language = getMoonshineLanguage(languageCode);
    return language.models.find((model) => model.default)?.arch ?? language.models[0].arch;
  }
  function resolveArch(languageCode, arch) {
    const language = getMoonshineLanguage(languageCode);
    const found = language.models.find((model) => model.arch === arch);
    return found?.arch ?? defaultArchFor(languageCode);
  }
  const WHISPER_LANGUAGES = [
    { code: "af", name: "Afrikaans" },
    { code: "sq", name: "Albanian" },
    { code: "am", name: "Amharic" },
    { code: "ar", name: "Arabic" },
    { code: "hy", name: "Armenian" },
    { code: "as", name: "Assamese" },
    { code: "az", name: "Azerbaijani" },
    { code: "ba", name: "Bashkir" },
    { code: "eu", name: "Basque" },
    { code: "be", name: "Belarusian" },
    { code: "bn", name: "Bengali" },
    { code: "bs", name: "Bosnian" },
    { code: "br", name: "Breton" },
    { code: "bg", name: "Bulgarian" },
    { code: "ca", name: "Catalan" },
    { code: "zh", name: "Chinese" },
    { code: "hr", name: "Croatian" },
    { code: "cs", name: "Czech" },
    { code: "da", name: "Danish" },
    { code: "nl", name: "Dutch" },
    { code: "en", name: "English" },
    { code: "et", name: "Estonian" },
    { code: "fo", name: "Faroese" },
    { code: "fi", name: "Finnish" },
    { code: "fr", name: "French" },
    { code: "gl", name: "Galician" },
    { code: "ka", name: "Georgian" },
    { code: "de", name: "German" },
    { code: "el", name: "Greek" },
    { code: "gu", name: "Gujarati" },
    { code: "ht", name: "Haitian creole" },
    { code: "ha", name: "Hausa" },
    { code: "haw", name: "Hawaiian" },
    { code: "he", name: "Hebrew" },
    { code: "hi", name: "Hindi" },
    { code: "hu", name: "Hungarian" },
    { code: "is", name: "Icelandic" },
    { code: "id", name: "Indonesian" },
    { code: "it", name: "Italian" },
    { code: "ja", name: "Japanese" },
    { code: "jw", name: "Javanese" },
    { code: "kn", name: "Kannada" },
    { code: "kk", name: "Kazakh" },
    { code: "km", name: "Khmer" },
    { code: "ko", name: "Korean" },
    { code: "lo", name: "Lao" },
    { code: "la", name: "Latin" },
    { code: "lv", name: "Latvian" },
    { code: "ln", name: "Lingala" },
    { code: "lt", name: "Lithuanian" },
    { code: "lb", name: "Luxembourgish" },
    { code: "mk", name: "Macedonian" },
    { code: "mg", name: "Malagasy" },
    { code: "ms", name: "Malay" },
    { code: "ml", name: "Malayalam" },
    { code: "mt", name: "Maltese" },
    { code: "mi", name: "Maori" },
    { code: "mr", name: "Marathi" },
    { code: "mn", name: "Mongolian" },
    { code: "my", name: "Myanmar" },
    { code: "ne", name: "Nepali" },
    { code: "no", name: "Norwegian" },
    { code: "nn", name: "Nynorsk" },
    { code: "oc", name: "Occitan" },
    { code: "ps", name: "Pashto" },
    { code: "fa", name: "Persian" },
    { code: "pl", name: "Polish" },
    { code: "pt", name: "Portuguese" },
    { code: "pa", name: "Punjabi" },
    { code: "ro", name: "Romanian" },
    { code: "ru", name: "Russian" },
    { code: "sa", name: "Sanskrit" },
    { code: "sr", name: "Serbian" },
    { code: "sn", name: "Shona" },
    { code: "sd", name: "Sindhi" },
    { code: "si", name: "Sinhala" },
    { code: "sk", name: "Slovak" },
    { code: "sl", name: "Slovenian" },
    { code: "so", name: "Somali" },
    { code: "es", name: "Spanish" },
    { code: "su", name: "Sundanese" },
    { code: "sw", name: "Swahili" },
    { code: "sv", name: "Swedish" },
    { code: "tl", name: "Tagalog" },
    { code: "tg", name: "Tajik" },
    { code: "ta", name: "Tamil" },
    { code: "tt", name: "Tatar" },
    { code: "te", name: "Telugu" },
    { code: "th", name: "Thai" },
    { code: "bo", name: "Tibetan" },
    { code: "tr", name: "Turkish" },
    { code: "tk", name: "Turkmen" },
    { code: "uk", name: "Ukrainian" },
    { code: "ur", name: "Urdu" },
    { code: "uz", name: "Uzbek" },
    { code: "vi", name: "Vietnamese" },
    { code: "cy", name: "Welsh" },
    { code: "yi", name: "Yiddish" },
    { code: "yo", name: "Yoruba" }
  ];
  function getWhisperLanguage(code) {
    return WHISPER_LANGUAGES.find((language) => language.code === code);
  }
  function isWhisperLanguage(code) {
    return getWhisperLanguage(code) !== void 0;
  }
  const SETTINGS_VERSION = 2;
  const DEFAULT_SETTINGS = {
    moonshine: {
      language: DEFAULT_LANGUAGE,
      modelArch: defaultArchFor(DEFAULT_LANGUAGE)
    },
    whisper: {
      language: DEFAULT_LANGUAGE
    },
    translation: {
      enabled: false,
      provider: "chrome",
      targetLanguage: "en",
      display: "translation"
    },
    overlay: {
      fontSize: 24,
      maxLines: 2,
      position: "bottom",
      offset: 96,
      opacity: 0.85,
      showInterim: true,
      hideDelayMs: 4500
    }
  };
  function isRecord(value) {
    return typeof value === "object" && value !== null;
  }
  function pickNumber(value, fallback, min, max) {
    if (typeof value !== "number" || !Number.isFinite(value)) return fallback;
    return Math.min(max, Math.max(min, value));
  }
  function pickString(value, fallback) {
    return typeof value === "string" ? value : fallback;
  }
  function pickBoolean(value, fallback) {
    return typeof value === "boolean" ? value : fallback;
  }
  function pickEngine(rawEngine, rawVersion) {
    if (rawEngine === "whisper") return "whisper";
    if (rawEngine === "parakeet") return "parakeet";
    if (rawEngine === "moonshine") {
      const version = typeof rawVersion === "number" ? rawVersion : 0;
      return version >= SETTINGS_VERSION ? "moonshine" : "auto";
    }
    return "auto";
  }
  function normalizeSettings(input) {
    const raw = isRecord(input) ? input : {};
    const rawMoonshine = isRecord(raw.moonshine) ? raw.moonshine : {};
    const rawWhisper = isRecord(raw.whisper) ? raw.whisper : {};
    const rawTranslation = isRecord(raw.translation) ? raw.translation : {};
    const rawOverlay = isRecord(raw.overlay) ? raw.overlay : {};
    const language = getMoonshineLanguage(
      pickString(rawMoonshine.language, DEFAULT_SETTINGS.moonshine.language)
    ).code;
    const whisperLanguage = pickString(rawWhisper.language, DEFAULT_SETTINGS.whisper.language);
    const engine = pickEngine(raw.engine, raw.version);
    const position = rawOverlay.position === "top" ? "top" : "bottom";
    const translationProvider = rawTranslation.provider === "hunyuan" ? "hunyuan" : DEFAULT_SETTINGS.translation.provider;
    const translationDisplay = rawTranslation.display === "both" ? "both" : rawTranslation.display === "source" ? "source" : "translation";
    return {
      version: SETTINGS_VERSION,
      engine,
      moonshine: {
        language,
        modelArch: resolveArch(language, pickString(rawMoonshine.modelArch, ""))
      },
      whisper: {
        language: isWhisperLanguage(whisperLanguage) ? whisperLanguage : DEFAULT_SETTINGS.whisper.language
      },
      translation: {
        enabled: pickBoolean(rawTranslation.enabled, DEFAULT_SETTINGS.translation.enabled),
        provider: translationProvider,
        targetLanguage: pickString(
          rawTranslation.targetLanguage,
          DEFAULT_SETTINGS.translation.targetLanguage
        ),
        display: translationDisplay
      },
      overlay: {
        fontSize: pickNumber(rawOverlay.fontSize, DEFAULT_SETTINGS.overlay.fontSize, 12, 72),
        maxLines: Math.round(
          pickNumber(rawOverlay.maxLines, DEFAULT_SETTINGS.overlay.maxLines, 1, 6)
        ),
        position,
        offset: pickNumber(rawOverlay.offset, DEFAULT_SETTINGS.overlay.offset, 0, 2e3),
        opacity: pickNumber(rawOverlay.opacity, DEFAULT_SETTINGS.overlay.opacity, 0.2, 1),
        showInterim: pickBoolean(rawOverlay.showInterim, DEFAULT_SETTINGS.overlay.showInterim),
        hideDelayMs: pickNumber(
          rawOverlay.hideDelayMs,
          DEFAULT_SETTINGS.overlay.hideDelayMs,
          0,
          6e4
        )
      }
    };
  }
  function normalizeOverlayPosition(input) {
    if (!isRecord(input)) return null;
    const left = input.left;
    const top = input.top;
    if (typeof left !== "number" || typeof top !== "number") return null;
    if (!Number.isFinite(left) || !Number.isFinite(top)) return null;
    return { left, top };
  }
  const SETTINGS_KEY = "settings";
  const POSITION_KEY = "overlayPosition";
  function watchSettings(callback) {
    const listener = (changes, areaName) => {
      if (!(SETTINGS_KEY in changes)) return;
      callback(normalizeSettings(changes[SETTINGS_KEY].newValue), areaName);
    };
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }
  async function loadOverlayPosition() {
    const stored = await chrome.storage.local.get(POSITION_KEY);
    return normalizeOverlayPosition(stored[POSITION_KEY]);
  }
  async function saveOverlayPosition(position) {
    if (position === null) {
      await chrome.storage.local.remove(POSITION_KEY);
      return;
    }
    await chrome.storage.local.set({ [POSITION_KEY]: position });
  }
  const WIDE_CHAR = /[\u1100-\u115f\u2e80-\ua4cf\ua960-\ua97f\uac00-\ud7ff\uf900-\ufaff\ufe10-\ufe19\ufe30-\ufe6f\uff00-\uff60\uffe0-\uffe6\u3000-\u303f\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff]/u;
  const JAPANESE_BREAK = /[、。！？!?，,.・…ー）」』】]/u;
  const JAPANESE_LINE_UNITS = 15;
  const LATIN_LINE_UNITS = 21;
  function charUnits(char) {
    return WIDE_CHAR.test(char) ? 1 : 0.5;
  }
  function textUnits(text) {
    let units = 0;
    for (const char of text) units += charUnits(char);
    return units;
  }
  function isJapanese(text) {
    let wide = 0;
    let visible = 0;
    for (const char of text) {
      if (/\s/u.test(char)) continue;
      visible += 1;
      if (WIDE_CHAR.test(char)) wide += 1;
    }
    return visible > 0 && wide / visible >= 0.25;
  }
  function wrapSubtitleText(text, maxLines) {
    const normalized = text.replace(/\s+/gu, " ").trim();
    if (!normalized) return [];
    const rows = Math.max(1, Math.round(maxLines));
    const japanese = isJapanese(normalized);
    const width = japanese ? JAPANESE_LINE_UNITS : LATIN_LINE_UNITS;
    const breaks = japanese ? JAPANESE_BREAK : / /u;
    const lines = [];
    let current = "";
    let units = 0;
    let lastBreak = -1;
    const append = (char) => {
      current += char;
      units += charUnits(char);
      if (breaks.test(char)) lastBreak = current.length;
    };
    const reindex = () => {
      units = textUnits(current);
      lastBreak = -1;
      for (let index = 0; index < current.length; index++) {
        if (breaks.test(current[index])) lastBreak = index + 1;
      }
    };
    for (const char of normalized) {
      if (current && units + charUnits(char) > width) {
        if (lastBreak > 0 && lastBreak < current.length) {
          lines.push(current.slice(0, lastBreak).trim());
          current = current.slice(lastBreak);
          reindex();
        } else {
          lines.push(current.trim());
          current = "";
          units = 0;
          lastBreak = -1;
        }
      }
      append(char);
    }
    if (current.trim()) lines.push(current.trim());
    return lines.length > rows ? lines.slice(-rows) : lines;
  }
  const HOST_ID = "brevier-host";
  const DRAG_THRESHOLD_PX = 3;
  const STYLES = `
  :host {
    all: initial;

    --lc-overlay-surface-rgb: 15 23 42;
    --lc-overlay-text: #f8fafc;
    --lc-overlay-interim: #cbd5e1;
    --lc-overlay-translation: #7dd3fc;
    --lc-overlay-placeholder: #94a3b8;
    --lc-overlay-grip: rgba(248, 250, 252, 0.28);
    --lc-overlay-grip-hover: rgba(248, 250, 252, 0.5);
    --lc-overlay-shadow: rgba(2, 6, 23, 0.45);
    --lc-overlay-live: #f87171;
  }

  .bar {
    position: fixed;
    z-index: 2147483647;
    left: 50%;
    transform: translateX(-50%);
    box-sizing: border-box;
    max-width: min(84vw, 1100px);
    min-width: 180px;
    padding: 17px 18px 10px;
    border-radius: 12px;
    background: rgb(var(--lc-overlay-surface-rgb) / var(--lc-opacity, 0.85));
    color: var(--lc-overlay-text);
    font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
    font-size: var(--lc-font-size, 24px);
    line-height: 1.35;
    text-align: center;
    text-wrap: pretty;
    box-shadow: 0 8px 28px var(--lc-overlay-shadow);
    backdrop-filter: blur(3px);
    pointer-events: none;
    user-select: none;
    transition: opacity 200ms ease;
  }

  .bar.hidden {
    opacity: 0;
  }

  .grip {
    position: absolute;
    top: 5px;
    left: 50%;
    transform: translateX(-50%);
    width: 40px;
    height: 8px;
    border-radius: 999px;
    background: var(--lc-overlay-grip);
    cursor: grab;
    pointer-events: auto;
    touch-action: none;
  }

  .grip:hover {
    background: var(--lc-overlay-grip-hover);
  }

  .bar.hidden .grip {
    pointer-events: none;
  }

  .bar.dragging .grip {
    cursor: grabbing;
  }

  .bar.preset-bottom {
    bottom: var(--lc-offset, 96px);
  }

  .bar.preset-top {
    top: var(--lc-offset, 96px);
  }

  .bar.custom {
    bottom: auto;
    top: auto;
    transform: none;
  }

  .lines {
    display: flex;
    flex-direction: column;
    gap: 2px;
  }

  .line {
    margin: 0;
    white-space: pre-wrap;
    overflow-wrap: anywhere;
  }

  .line.interim {
    color: var(--lc-overlay-interim);
    opacity: 0.92;
  }

  .line.translation {
    color: var(--lc-overlay-translation);
    font-size: 0.92em;
  }

  .line.placeholder {
    color: var(--lc-overlay-placeholder);
    font-style: italic;
  }

  .dot {
    position: fixed;
    z-index: 2147483647;
    left: 50%;
    transform: translateX(-50%);
    width: 10px;
    height: 10px;
    border-radius: 50%;
    background: var(--lc-overlay-live);
    box-shadow: 0 0 0 3px rgb(248 113 113 / 0.18);
    opacity: 0;
    pointer-events: none;
    transition: opacity 200ms ease;
  }

  .dot.visible {
    opacity: 0.7;
  }

  .dot.preset-bottom {
    bottom: var(--lc-offset, 96px);
  }

  .dot.preset-top {
    top: var(--lc-offset, 96px);
  }

  .dot.custom {
    bottom: auto;
    top: auto;
    transform: none;
  }
`;
  class CaptionOverlay {
    host;
    bar;
    grip;
    linesEl;
    dot;
    settings = DEFAULT_SETTINGS.overlay;
    display = DEFAULT_SETTINGS.translation.display;
    finals = [];
    interim = null;
    active = false;
    /** True while active but no caption has arrived yet. */
    listening = false;
    hideTimer = null;
    position = null;
    drag = null;
    constructor() {
      this.host = document.createElement("div");
      this.host.id = HOST_ID;
      this.host.style.display = "none";
      this.host.setAttribute("popover", "manual");
      const root = this.host.attachShadow({ mode: "open" });
      const style = document.createElement("style");
      style.textContent = STYLES;
      this.bar = document.createElement("div");
      this.bar.className = "bar preset-bottom hidden";
      this.grip = document.createElement("div");
      this.grip.className = "grip";
      this.grip.title = "Drag to move — double-click to reset";
      this.linesEl = document.createElement("div");
      this.linesEl.className = "lines";
      this.bar.append(this.grip, this.linesEl);
      this.dot = document.createElement("div");
      this.dot.className = "dot preset-bottom";
      root.append(style, this.bar, this.dot);
      this.syncFullscreen();
      this.grip.addEventListener("pointerdown", this.onPointerDown);
      this.grip.addEventListener("pointermove", this.onPointerMove);
      this.grip.addEventListener("pointerup", this.onPointerUp);
      this.grip.addEventListener("pointercancel", this.onPointerUp);
      this.grip.addEventListener("dblclick", this.onDoubleClick);
      window.addEventListener("resize", this.onResize);
      document.addEventListener("fullscreenchange", this.onFullscreenChange);
      document.addEventListener("webkitfullscreenchange", this.onFullscreenChange);
    }
    /**
     * Keeps the overlay visible across fullscreen changes (see
     * scripts/probe-overlay.mjs):
     *
     *  - Engines with the Popover API keep the host on <html>, out of the
     *    player's fullscreen subtree, and show it in the top layer — the only
     *    way to render over a fullscreen <video> and the only way to survive
     *    sites that rebuild their fullscreen container (YouTube and friends);
     *  - Engines without popovers fall back to being re-parented into a
     *    non-video fullscreen container.
     *
     * Chrome keeps routing input to the fullscreen element, so the overlay
     * cannot swallow clicks there.
     */
    syncFullscreen() {
      const fullscreen = this.fullscreenElement();
      const popover = typeof this.host.showPopover === "function";
      const target = !popover && fullscreen && !(fullscreen instanceof HTMLVideoElement) ? fullscreen : document.documentElement;
      this.hideTopLayer();
      if (this.host.parentNode !== target) {
        target.append(this.host);
        this.applyPosition();
      }
      if (this.active && fullscreen) this.showTopLayer();
    }
    fullscreenElement() {
      const prefixed = document.webkitFullscreenElement;
      return document.fullscreenElement ?? prefixed ?? null;
    }
    showTopLayer() {
      if (typeof this.host.showPopover !== "function") return;
      try {
        if (this.host.matches(":popover-open")) this.host.hidePopover();
        this.host.showPopover();
      } catch {
      }
    }
    hideTopLayer() {
      if (typeof this.host.hidePopover !== "function") return;
      try {
        if (this.host.matches(":popover-open")) this.host.hidePopover();
      } catch {
      }
    }
    restorePosition(position) {
      this.position = position;
      this.applyPosition();
    }
    bind(active, settings, history) {
      this.applySettings(settings);
      this.active = active;
      if (!active) {
        this.hide();
        this.clear();
        this.host.style.display = "none";
        this.hideTopLayer();
        this.syncDot();
        return;
      }
      this.host.style.display = "block";
      this.syncFullscreen();
      this.finals = history.filter((event) => event.kind === "final").slice(-this.settings.maxLines);
      this.interim = null;
      this.listening = this.finals.length === 0;
      this.render();
      this.show();
      if (!this.listening) {
        this.scheduleHide();
      }
    }
    unbind() {
      this.active = false;
      this.host.style.display = "none";
      this.hideTopLayer();
      this.clear();
      this.syncDot();
    }
    applySettings(settings) {
      this.settings = settings.overlay;
      this.display = settings.translation.display;
      this.bar.style.setProperty("--lc-font-size", `${settings.overlay.fontSize}px`);
      this.bar.style.setProperty("--lc-offset", `${settings.overlay.offset}px`);
      this.dot.style.setProperty("--lc-offset", `${settings.overlay.offset}px`);
      this.bar.style.setProperty("--lc-opacity", `${settings.overlay.opacity}`);
      this.finals = this.finals.slice(-settings.overlay.maxLines);
      this.applyPosition();
      this.render();
    }
    pushCaption(event) {
      if (!this.active) return;
      this.listening = false;
      if (event.kind === "interim") {
        this.interim = event;
      } else {
        const index = event.lineId ? this.finals.findIndex((item) => item.kind === "final" && item.lineId === event.lineId) : -1;
        if (index >= 0) {
          const next = this.finals.slice();
          next[index] = event;
          this.finals = next;
        } else {
          this.finals = [...this.finals, event].slice(-Math.max(1, this.settings.maxLines));
        }
        if (this.interim && (!event.lineId || event.lineId === this.interim.lineId)) {
          this.interim = null;
        }
      }
      this.render();
      this.show();
      this.scheduleHide();
    }
    clear() {
      this.finals = [];
      this.interim = null;
      this.listening = false;
      if (this.hideTimer !== null) {
        window.clearTimeout(this.hideTimer);
        this.hideTimer = null;
      }
      this.render();
    }
    render() {
      this.linesEl.replaceChildren();
      for (const event of this.finals) {
        if (this.display === "source") {
          this.linesEl.append(this.lineElement(event.text, event.kind));
          continue;
        }
        if (this.display === "translation") {
          if (event.translation) {
            this.linesEl.append(this.lineElement(event.translation, "translation"));
          } else {
            this.linesEl.append(this.lineElement(event.text, "interim"));
          }
          continue;
        }
        this.linesEl.append(this.lineElement(event.text, event.kind));
        if (event.translation) {
          this.linesEl.append(this.lineElement(event.translation, "translation"));
        }
      }
      if (this.settings.showInterim && this.interim?.text) {
        this.linesEl.append(this.lineElement(this.interim.text, "interim"));
      }
      if (this.listening && this.linesEl.childElementCount === 0) {
        this.linesEl.append(this.lineElement("Captions on — listening…", "placeholder"));
      }
    }
    lineElement(text, kind) {
      const line = document.createElement("div");
      line.className = `line ${kind}`;
      line.textContent = wrapSubtitleText(text, this.settings.maxLines).join("\n");
      return line;
    }
    show() {
      this.bar.classList.remove("hidden");
      this.syncDot();
    }
    hide() {
      this.bar.classList.add("hidden");
      this.syncDot();
    }
    /** The dot stands in for the bar once the bar has faded out. */
    syncDot() {
      this.dot.classList.toggle("visible", this.active && this.bar.classList.contains("hidden"));
    }
    scheduleHide() {
      if (this.hideTimer !== null) window.clearTimeout(this.hideTimer);
      if (this.settings.hideDelayMs <= 0) return;
      this.hideTimer = window.setTimeout(() => {
        this.hideTimer = null;
        this.hide();
      }, this.settings.hideDelayMs);
    }
    applyPosition() {
      const presetBottom = this.position === null && this.settings.position === "bottom";
      const presetTop = this.position === null && this.settings.position === "top";
      const custom = this.position !== null;
      this.bar.classList.toggle("preset-bottom", presetBottom);
      this.bar.classList.toggle("preset-top", presetTop);
      this.bar.classList.toggle("custom", custom);
      this.dot.classList.toggle("preset-bottom", presetBottom);
      this.dot.classList.toggle("preset-top", presetTop);
      this.dot.classList.toggle("custom", custom);
      if (this.position === null) {
        this.bar.style.left = "";
        this.bar.style.top = "";
        this.dot.style.left = "";
        this.dot.style.top = "";
        return;
      }
      const rect = this.bar.getBoundingClientRect();
      const maxLeft = Math.max(8, window.innerWidth - rect.width - 8);
      const maxTop = Math.max(8, window.innerHeight - rect.height - 8);
      const left = Math.min(Math.max(8, this.position.left), maxLeft);
      const top = Math.min(Math.max(8, this.position.top), maxTop);
      this.bar.style.left = `${Math.round(left)}px`;
      this.bar.style.top = `${Math.round(top)}px`;
      this.dot.style.left = `${Math.round(left + rect.width / 2 - 5)}px`;
      this.dot.style.top = `${Math.round(top + rect.height / 2 - 5)}px`;
    }
    onPointerDown = (event) => {
      if (event.button !== 0) return;
      const rect = this.bar.getBoundingClientRect();
      this.drag = {
        pointerId: event.pointerId,
        startX: event.clientX,
        startY: event.clientY,
        originLeft: rect.left,
        originTop: rect.top,
        moved: false
      };
      this.grip.setPointerCapture(event.pointerId);
    };
    onPointerMove = (event) => {
      if (!this.drag || event.pointerId !== this.drag.pointerId) return;
      const dx = event.clientX - this.drag.startX;
      const dy = event.clientY - this.drag.startY;
      if (!this.drag.moved && Math.hypot(dx, dy) < DRAG_THRESHOLD_PX) return;
      this.drag.moved = true;
      this.bar.classList.add("dragging");
      this.position = {
        left: this.drag.originLeft + dx,
        top: this.drag.originTop + dy
      };
      this.applyPosition();
    };
    onPointerUp = (event) => {
      if (!this.drag || event.pointerId !== this.drag.pointerId) return;
      const moved = this.drag.moved;
      this.drag = null;
      this.bar.classList.remove("dragging");
      try {
        this.grip.releasePointerCapture(event.pointerId);
      } catch {
      }
      if (moved && this.position) {
        void saveOverlayPosition(this.position);
      }
    };
    onDoubleClick = () => {
      this.position = null;
      void saveOverlayPosition(null);
      this.applyPosition();
    };
    onFullscreenChange = () => {
      this.syncFullscreen();
    };
    onResize = () => {
      this.applyPosition();
    };
  }
  const overlay = new CaptionOverlay();
  void loadOverlayPosition().then((position) => overlay.restorePosition(position));
  watchSettings((settings) => overlay.applySettings(settings));
  chrome.runtime.onMessage.addListener((message) => {
    if (!isBackgroundToContent(message)) return;
    switch (message.type) {
      case "content:bind":
        overlay.bind(message.active, message.settings, message.history);
        break;
      case "content:unbind":
        overlay.unbind();
        break;
      case "content:caption":
        overlay.pushCaption(message.event);
        break;
      case "content:settings":
        overlay.applySettings(message.settings);
        break;
    }
  });
  void chrome.runtime.sendMessage({ type: "content:ready" }).catch(() => {
  });
})();
