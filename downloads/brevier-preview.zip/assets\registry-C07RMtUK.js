import { G as GpuAsrEngine, e as engineConfig, a as autoEngineOrder } from "./provider-DCStykE9.js";
import { s as spokenLanguage, e as errorMessage, D as DEFAULT_QWEN_MODEL } from "./settings-DWyWJaRh.js";
class DelegatingEngine {
  inner = null;
  start() {
    return this.inner?.start() ?? Promise.resolve();
  }
  pushAudio(samples, sampleRate) {
    this.inner?.pushAudio(samples, sampleRate);
  }
  stop() {
    return this.inner?.stop() ?? Promise.resolve();
  }
  dispose() {
    return this.inner?.dispose() ?? Promise.resolve();
  }
}
class ParakeetEngine extends GpuAsrEngine {
  constructor() {
    super("parakeet", (context) => engineConfig("parakeet", context.settings));
  }
}
class QwenEngine extends GpuAsrEngine {
  constructor() {
    super("qwen", (context) => engineConfig("qwen", context.settings));
  }
}
class ParakeetTdtEngine extends GpuAsrEngine {
  constructor() {
    super("parakeet-tdt", (context) => engineConfig("parakeet-tdt", context.settings));
  }
}
const ENGINE_FACTORIES = {
  parakeet: () => new ParakeetEngine(),
  "parakeet-tdt": () => new ParakeetTdtEngine(),
  qwen: () => new QwenEngine()
};
function autoSettings(settings) {
  return settings.qwenModel === DEFAULT_QWEN_MODEL ? settings : { ...settings, qwenModel: DEFAULT_QWEN_MODEL };
}
class AutoEngine extends DelegatingEngine {
  id = "auto";
  /** Inner engine still initializing; dispose must be able to cancel it. */
  pending = null;
  disposed = false;
  async initialize(context) {
    this.disposed = false;
    const language = spokenLanguage(context.settings);
    const order = autoEngineOrder(language);
    const settings = autoSettings(context.settings);
    for (const id of order) {
      if (this.disposed) return;
      const engine = ENGINE_FACTORIES[id]();
      this.pending = engine;
      try {
        await engine.initialize({ ...context, settings });
        this.pending = null;
        if (this.disposed) {
          await engine.dispose();
          return;
        }
        this.inner = engine;
        return;
      } catch (error) {
        this.pending = null;
        await engine.dispose();
        if (this.disposed) return;
        const name = id === "qwen" ? "Qwen3-ASR" : id;
        context.events.onLog?.(
          `The ${name} engine is unavailable on this machine; trying the next one: ${errorMessage(error)}`
        );
      }
    }
    if (this.disposed) return;
    throw new Error(
      order.length === 0 ? `No on-device engine supports ${language}. Pick another language.` : "No speech engine could start on this machine."
    );
  }
  dispose() {
    this.disposed = true;
    const pending = this.pending;
    const inner = this.inner;
    this.pending = null;
    this.inner = null;
    return Promise.all([
      pending ? pending.dispose() : Promise.resolve(),
      inner ? inner.dispose() : Promise.resolve()
    ]).then(() => void 0);
  }
}
const registry = new Map([
  ["auto", () => new AutoEngine()],
  ...Object.entries(ENGINE_FACTORIES)
]);
function createEngine(id) {
  const factory = registry.get(id);
  if (!factory) {
    throw new Error(`Unknown transcription engine: ${id}`);
  }
  return factory();
}
export {
  createEngine as c
};
