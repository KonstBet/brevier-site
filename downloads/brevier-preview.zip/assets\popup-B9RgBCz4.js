import { s as spokenLanguage, e as errorMessage, m as QWEN_MODELS, D as DEFAULT_QWEN_MODEL, n as PARAKEET_LANGUAGE, o as DEFAULT_LANGUAGE, k as supportsParakeetTdtLanguage, j as supportsQwenLanguage, p as PARAKEET_LANGUAGES, r as PARAKEET_TDT_LANGUAGES, u as QWEN_LANGUAGES, S as SUPPORTED_LANGUAGES, g as isLocalTranslationProvider } from "./settings-HWqrYUVe.js";
import { e as element, s as setHidden } from "./dom-qkm_bq4-.js";
import { p as passLabel, i as isProEntitlement, a as isOneOffPass, c as comparePlans, b as planRoles, d as planLabel, f as formatPlanPrice, g as formatPlanTerm } from "./entitlements-nWpvccq6.js";
import { u as updateSettings, l as loadSettings } from "./storage-Beku4kBR.js";
import { h as hasWebGpu } from "./webgpu-D1jNrLJ3.js";
import { p as probeChromeTranslation, a as prepareChromeTranslation, T as TRANSLATION_LANGUAGES } from "./translation-languages-rIHGiGRb.js";
class ChromeTranslationPanel {
  constructor(getSettings, notifySettingsChanged2) {
    this.getSettings = getSettings;
    this.notifySettingsChanged = notifySettingsChanged2;
    this.prepareButton.addEventListener("click", () => void this.prepare());
  }
  status = element("trChromeStatus");
  prepareButton = element("trPrepare");
  /** True when a local model is selected but runs through Chrome for lack of WebGPU. */
  cpuFallback = false;
  refresh() {
    void this.refreshAsync();
  }
  /** Called after the WebGPU probe when a local model falls back to Chrome. */
  setCpuFallback(value) {
    if (this.cpuFallback === value) return;
    this.cpuFallback = value;
    this.refresh();
  }
  async refreshAsync() {
    const settings = this.getSettings();
    if (!settings || !settings.translation.enabled || settings.translation.provider !== "chrome" && !this.cpuFallback) {
      return;
    }
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    if (source === target) {
      this.setStatus("Target language is the same as the spoken language.", false);
      return;
    }
    const availability = await probeChromeTranslation(source, target);
    switch (availability) {
      case "unsupported":
        this.setStatus(
          "Built-in translation is not available in this browser (needs desktop Chrome 138+).",
          false
        );
        break;
      case "unavailable":
        this.setStatus(`This device does not support translation ${source} → ${target}.`, false);
        break;
      case "available":
        this.setStatus(`On-device translation ready (${source} → ${target}).`, false);
        break;
      default:
        this.setStatus(`One-time model download needed (${source} → ${target}).`, true);
        break;
    }
  }
  async prepare() {
    const settings = this.getSettings();
    if (!settings) return;
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    this.prepareButton.disabled = true;
    this.setStatus("Downloading translation model…", true);
    try {
      await prepareChromeTranslation(source, target, (fraction) => {
        this.status.textContent = `Downloading translation model… ${Math.round(fraction * 100)}%`;
      });
      await this.notifySettingsChanged();
      await this.refreshAsync();
    } catch (error) {
      this.status.textContent = errorMessage(error);
    } finally {
      this.prepareButton.disabled = false;
    }
  }
  setStatus(text, showPrepare) {
    this.status.textContent = text;
    setHidden(this.prepareButton, !showPrepare);
  }
}
function qwenInfo(size) {
  const model = QWEN_MODELS[size];
  const small = size === "0.6b";
  return {
    summary: small ? "30 languages in a fast 0.6B model, including Chinese, Korean and Arabic." : "30 languages in the larger 1.7B model — slower, but more accurate.",
    facts: [
      { label: "Model", value: `${model.label} (int4 ONNX)` },
      {
        label: "Languages",
        value: "30 — Chinese, Korean, Arabic, Hindi, Japanese and more"
      },
      {
        label: "Download",
        value: `about ${(model.sizeMB / 1e3).toFixed(1)} GB once, then cached`
      },
      {
        label: "Speed",
        value: small ? "live text within a couple of seconds on WebGPU; CPU is slower" : "a few seconds per line on a discrete GPU; CPU is slower"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  };
}
const ENGINE_INFO = {
  auto: {
    summary: "Picks the best engine for the language — nothing to configure.",
    facts: [
      {
        label: "25 European languages",
        value: "Parakeet TDT — best accuracy, live text almost instantly"
      },
      { label: "Japanese", value: "Parakeet Japanese — fastest live text" },
      {
        label: "Other languages",
        value: "Qwen3-ASR 0.6B — Chinese, Korean, Arabic, Hindi and more"
      },
      { label: "Fallback", value: "switches engines automatically if one cannot load" },
      { label: "Privacy", value: "audio never leaves this machine" }
    ]
  },
  qwen: qwenInfo(DEFAULT_QWEN_MODEL),
  parakeet: {
    summary: "Fastest Japanese captions, with top-tier accuracy.",
    facts: [
      { label: "Language", value: "Japanese" },
      { label: "Download", value: "about 620 MB once, then cached" },
      {
        label: "Speed",
        value: "live text while you speak — a partial caption takes tens of milliseconds, and the final line lands as soon as the sentence ends"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  },
  "parakeet-tdt": {
    summary: "English and 24 European languages in a single 400 MB model.",
    facts: [
      {
        label: "Languages",
        value: "25 European languages including English — pick the spoken one above"
      },
      { label: "Download", value: "about 400 MB once, then cached" },
      {
        label: "Speed",
        value: "live text about a second after speech starts, with frequent partials"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  }
};
const TRANSLATION_INFO = {
  hymt3: {
    summary: "Best on-device translation — fast when WebGPU is available.",
    facts: [
      { label: "Runs on", value: "WebGPU; Chrome translation is the CPU fallback" },
      { label: "Model", value: "Hy-MT3 (1.8B, q4f16)" },
      { label: "Languages", value: "102 in the model card; the list above is what Brevier offers" },
      { label: "Download", value: "about 1.1 GB once, then cached" },
      {
        label: "Speed",
        value: "fast — about 0.2–0.6 s per line on a discrete GPU; integrated GPUs may lag"
      },
      {
        label: "Best for",
        value: "longer text — terminology, placeholders and format preservation"
      },
      { label: "Tip", value: "without WebGPU, Chrome translation is used automatically" },
      {
        label: "License",
        value: "Apache-2.0 — no regional restrictions"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  },
  chrome: {
    summary: "Instant translation on your CPU — no GPU needed.",
    facts: [
      { label: "GPU", value: "not needed" },
      { label: "Download", value: "small language pack per language pair, once" },
      { label: "Speed", value: "instant; the lightest option for slower machines" },
      { label: "Requires", value: "desktop Chrome 138 or newer" }
    ]
  }
};
function renderFacts(container, block, options = {}) {
  const summary = document.createElement(options.collapsible ? "span" : "p");
  summary.className = "info-summary";
  summary.textContent = block.summary;
  const list = document.createElement("ul");
  list.className = "info-list";
  for (const fact of block.facts) {
    const item = document.createElement("li");
    const label = document.createElement("strong");
    label.textContent = `${fact.label}:`;
    item.append(label, document.createTextNode(` ${fact.value}`));
    list.append(item);
  }
  if (!options.collapsible) {
    container.replaceChildren(summary, list);
    return;
  }
  const details = document.createElement("details");
  details.className = "info-more";
  const toggle2 = document.createElement("summary");
  const chevron = document.createElement("span");
  chevron.className = "info-chevron";
  chevron.setAttribute("aria-hidden", "true");
  toggle2.append(summary, chevron);
  details.append(toggle2, list);
  container.replaceChildren(details);
}
function otherTarget(language) {
  return TRANSLATION_LANGUAGES.find((option) => option.code !== language)?.code ?? null;
}
class SettingsForm {
  constructor(host) {
    this.host = host;
    this.engine.addEventListener("change", () => {
      const engine = this.engine.value;
      const current = this.current;
      const patch = { engine };
      if (!current) {
        void this.host.applyPatch(patch);
        return;
      }
      const source = spokenLanguage(current);
      if (engine === "parakeet") {
        patch.language = PARAKEET_LANGUAGE;
      } else if (engine === "parakeet-tdt") {
        patch.language = supportsParakeetTdtLanguage(source) ? source : DEFAULT_LANGUAGE;
      } else if (engine === "qwen") {
        patch.language = supportsQwenLanguage(source) ? source : DEFAULT_LANGUAGE;
      } else {
        patch.language = source;
      }
      const nextLanguage = patch.language ?? source;
      if (current.translation.enabled && current.translation.targetLanguage === nextLanguage) {
        const target = otherTarget(nextLanguage);
        if (target) patch.translation = { targetLanguage: target };
      }
      void this.host.applyPatch(patch);
    });
    this.language.addEventListener("change", () => {
      const next = this.language.value;
      const current = this.current;
      const patch = { language: next };
      if (current?.translation.enabled && current.translation.targetLanguage === next) {
        const target = otherTarget(next);
        if (target) patch.translation = { targetLanguage: target };
      }
      void this.host.applyPatch(patch);
    });
    this.qwenModel.addEventListener("change", () => {
      void this.host.applyPatch({
        qwenModel: this.qwenModel.value
      });
    });
    this.trEnabled.addEventListener("change", () => {
      const enabled = this.trEnabled.checked;
      const translation = { enabled };
      const current = this.current;
      if (enabled && current) {
        const spoken = spokenLanguage(current);
        if (current.translation.targetLanguage === spoken) {
          const target = otherTarget(spoken);
          if (target) translation.targetLanguage = target;
        }
      }
      void this.host.applyPatch({ translation });
    });
    this.trProvider.addEventListener("change", () => {
      void this.host.applyPatch({
        translation: { provider: this.trProvider.value }
      });
    });
    this.trTarget.addEventListener("change", () => {
      void this.host.applyPatch({ translation: { targetLanguage: this.trTarget.value } });
    });
    this.trDisplay.addEventListener("change", () => {
      void this.host.applyPatch({
        translation: { display: this.trDisplay.value }
      });
    });
    this.fontSize.addEventListener("input", () => {
      this.fontSizeOut.textContent = `${this.fontSize.value}px`;
      this.queueOverlayPatch({ overlay: { fontSize: Number(this.fontSize.value) } });
    });
    this.fontSize.addEventListener("change", () => this.flushOverlayPatch());
    this.maxLines.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { maxLines: Number(this.maxLines.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.position.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { position: this.position.value } },
        { skipLanguageRefresh: true }
      );
    });
    this.offset.addEventListener("input", () => {
      this.offsetOut.textContent = `${this.offset.value}px`;
      this.queueOverlayPatch({ overlay: { offset: Number(this.offset.value) } });
    });
    this.offset.addEventListener("change", () => this.flushOverlayPatch());
    this.opacity.addEventListener("input", () => {
      this.opacityOut.textContent = `${Math.round(Number(this.opacity.value) * 100)}%`;
      this.queueOverlayPatch({ overlay: { opacity: Number(this.opacity.value) } });
    });
    this.opacity.addEventListener("change", () => this.flushOverlayPatch());
    this.showInterim.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { showInterim: this.showInterim.checked } },
        { skipLanguageRefresh: true }
      );
    });
    renderFacts(this.trLocalInfo, TRANSLATION_INFO.hymt3, { collapsible: true });
    renderFacts(this.trChromeInfo, TRANSLATION_INFO.chrome, { collapsible: true });
  }
  engine = element("engine");
  language = element("language");
  qwenModelRow = element("qwenModelRow");
  qwenModel = element("qwenModel");
  engineNote = element("engineNote");
  translationBody = element("translationBody");
  trEnabled = element("trEnabled");
  trProvider = element("trProvider");
  trTarget = element("trTarget");
  trDisplay = element("trDisplay");
  trLocalBox = element("trLocalBox");
  trLocalInfo = element("trLocalInfo");
  trChromeBox = element("trChromeBox");
  trChromeInfo = element("trChromeInfo");
  fontSize = element("fontSize");
  fontSizeOut = element("fontSizeOut");
  maxLines = element("maxLines");
  position = element("position");
  offset = element("offset");
  offsetOut = element("offsetOut");
  opacity = element("opacity");
  opacityOut = element("opacityOut");
  showInterim = element("showInterim");
  current = null;
  /** True when no WebGPU adapter exists and local translation falls back to Chrome. */
  cpuOnly = false;
  /** Coalesces continuous slider edits into a few storage writes per drag. */
  overlayTimer = null;
  pendingOverlayPatch = null;
  /** Last settings snapshot handed to `render`; null before the first render. */
  get settings() {
    return this.current;
  }
  /** Updates the translation controls after the WebGPU probe finishes. */
  setCpuOnly(cpu) {
    if (this.cpuOnly === cpu) return;
    this.cpuOnly = cpu;
    if (this.current) this.render(this.current);
  }
  /** Coalesces continuous slider edits into a few storage writes per drag. */
  queueOverlayPatch(patch) {
    this.pendingOverlayPatch = patch;
    if (this.overlayTimer !== null) return;
    this.overlayTimer = window.setTimeout(() => this.flushOverlayPatch(), 120);
  }
  flushOverlayPatch() {
    if (this.overlayTimer !== null) {
      window.clearTimeout(this.overlayTimer);
      this.overlayTimer = null;
    }
    const patch = this.pendingOverlayPatch;
    this.pendingOverlayPatch = null;
    if (patch) {
      void this.host.applyPatch(patch, { skipLanguageRefresh: true });
    }
  }
  render(settings) {
    this.current = settings;
    this.engine.value = settings.engine;
    const info = settings.engine === "qwen" ? qwenInfo(settings.qwenModel) : ENGINE_INFO[settings.engine];
    renderFacts(this.engineNote, info, { collapsible: true });
    this.renderLanguageOptions(settings);
    this.qwenModelRow.hidden = settings.engine !== "qwen";
    this.qwenModel.value = settings.qwenModel;
    this.renderTranslation(settings);
    this.renderOverlay(settings);
    this.host.onRendered(settings);
  }
  renderLanguageOptions(settings) {
    const selected = spokenLanguage(settings);
    this.language.replaceChildren();
    let options;
    if (settings.engine === "parakeet") {
      options = PARAKEET_LANGUAGES;
    } else if (settings.engine === "parakeet-tdt") {
      options = PARAKEET_TDT_LANGUAGES;
    } else if (settings.engine === "qwen") {
      options = QWEN_LANGUAGES;
    } else {
      options = SUPPORTED_LANGUAGES;
    }
    for (const option of options) {
      const item = document.createElement("option");
      item.value = option.code;
      item.textContent = option.name;
      item.selected = option.code === selected;
      this.language.append(item);
    }
  }
  renderTranslation(settings) {
    this.trEnabled.checked = settings.translation.enabled;
    setHidden(this.translationBody, !settings.translation.enabled);
    this.trProvider.value = settings.translation.provider;
    this.renderTranslationLanguages(settings);
    this.trDisplay.value = settings.translation.display;
    const provider = settings.translation.provider;
    const localModel = isLocalTranslationProvider(provider);
    const chromeFallback = localModel && this.cpuOnly;
    setHidden(this.trLocalBox, !localModel);
    setHidden(this.trLocalInfo, chromeFallback);
    setHidden(this.trChromeBox, provider !== "chrome" && !chromeFallback);
  }
  renderTranslationLanguages(settings) {
    const selected = settings.translation.targetLanguage;
    const spoken = spokenLanguage(settings);
    this.trTarget.replaceChildren();
    const languages = [...TRANSLATION_LANGUAGES];
    if (!languages.some((language) => language.code === selected)) {
      languages.unshift({ code: selected, name: selected });
    }
    for (const language of languages) {
      const option = document.createElement("option");
      option.value = language.code;
      option.textContent = language.name;
      option.selected = language.code === selected;
      option.disabled = language.code === spoken;
      this.trTarget.append(option);
    }
  }
  renderOverlay(settings) {
    this.fontSize.value = String(settings.overlay.fontSize);
    this.fontSizeOut.textContent = `${settings.overlay.fontSize}px`;
    this.maxLines.value = String(settings.overlay.maxLines);
    this.position.value = settings.overlay.position;
    this.offset.value = String(settings.overlay.offset);
    this.offsetOut.textContent = `${settings.overlay.offset}px`;
    this.opacity.value = String(settings.overlay.opacity);
    this.opacityOut.textContent = `${Math.round(settings.overlay.opacity * 100)}%`;
    this.showInterim.checked = settings.overlay.showInterim;
  }
}
const TICK_MS = 1e3;
const STALE_AFTER_MS = 2e4;
class StatusView {
  dot = element("statusDot");
  statusText = element("statusText");
  staleWarning = element("staleWarning");
  activity = element("activity");
  progressWrap = element("progressWrap");
  progressName = element("progressName");
  progressPercent = element("progressPercent");
  progressBar = element("progressBar");
  progressText = element("progressText");
  toggle = element("toggle");
  translationRuntime = element("trRuntime");
  state = null;
  lastStateAt = 0;
  constructor() {
    window.setInterval(() => this.tick(), TICK_MS);
  }
  get capturing() {
    return this.state?.capturing ?? false;
  }
  /** Surfaces a transport-level failure (e.g. messaging the service worker). */
  showError(message) {
    this.statusText.textContent = message;
  }
  render(incoming) {
    const state = {
      ...incoming,
      audioLevel: typeof incoming.audioLevel === "number" ? incoming.audioLevel : 0,
      captionCount: typeof incoming.captionCount === "number" ? incoming.captionCount : 0,
      lastCaptionAt: typeof incoming.lastCaptionAt === "number" ? incoming.lastCaptionAt : null,
      translationStatus: incoming.translationStatus ?? "off",
      translationDetail: typeof incoming.translationDetail === "string" ? incoming.translationDetail : "",
      translationFraction: typeof incoming.translationFraction === "number" ? incoming.translationFraction : null
    };
    this.state = state;
    this.lastStateAt = Date.now();
    setHidden(this.staleWarning, true);
    this.renderActivity();
    this.renderTranslationRuntime(state);
    this.statusText.textContent = state.error ?? state.detail;
    this.dot.className = `dot ${state.status}`;
    this.toggle.textContent = state.capturing ? "Stop captions" : "Start captions";
    this.toggle.classList.toggle("stop", state.capturing);
    this.renderProgress(state);
  }
  /**
   * The offscreen pipeline sends a heartbeat every few seconds while loading,
   * so a long silence means the document was torn down or the engine wedged.
   */
  tick() {
    const state = this.state;
    if (!state) return;
    const stale = state.capturing && Date.now() - this.lastStateAt > STALE_AFTER_MS;
    setHidden(this.staleWarning, !stale);
    this.renderActivity();
  }
  renderActivity() {
    const state = this.state;
    if (!state?.capturing) {
      setHidden(this.activity, true);
      return;
    }
    setHidden(this.activity, false);
    const level = typeof state.audioLevel === "number" ? state.audioLevel : 0;
    const audio = level < 3e-3 ? "no audio" : "audio";
    const last = state.lastCaptionAt ? `${Math.max(0, Math.round((Date.now() - state.lastCaptionAt) / 1e3))}s ago` : "—";
    this.activity.textContent = `${audio} ${level.toFixed(3)} · captions ${state.captionCount ?? 0} · last ${last}`;
    this.activity.classList.toggle(
      "warn",
      level < 3e-3 && state.captionCount === 0 && state.status === "ready"
    );
  }
  renderTranslationRuntime(state) {
    if (!state.capturing || state.translationStatus === "off" || state.translationStatus === "loading") {
      setHidden(this.translationRuntime, true);
      return;
    }
    setHidden(this.translationRuntime, false);
    this.translationRuntime.classList.toggle("warn", state.translationStatus === "error");
    this.translationRuntime.textContent = state.translationDetail || "Translation";
  }
  renderProgress(state) {
    const asrLoading = Boolean(state.progress) || state.status === "loading" || state.status === "starting";
    const showTranslation = state.capturing && !asrLoading && state.translationStatus === "loading";
    const show = asrLoading || showTranslation;
    setHidden(this.progressWrap, !show);
    if (!show) {
      setHidden(this.progressText, true);
      return;
    }
    if (showTranslation) {
      this.progressName.textContent = "Translation model";
      this.setProgress(state.translationFraction);
      this.progressText.textContent = state.translationDetail || "Preparing translation…";
      setHidden(this.progressText, false);
      return;
    }
    if (state.progress) {
      const { loaded, total, file, model, sizeMB } = state.progress;
      this.progressName.textContent = model ?? "Speech model";
      this.setProgress(total && total > 0 ? loaded / total : null);
      const detail = [];
      if (sizeMB) detail.push(`${sizeMB} MB first download`);
      if (file) detail.push(file);
      this.progressText.textContent = detail.join(" · ");
      setHidden(this.progressText, detail.length === 0);
      return;
    }
    this.progressName.textContent = "Speech model";
    this.setProgress(null);
    this.progressText.textContent = "Preparing…";
    setHidden(this.progressText, false);
  }
  setProgress(fraction) {
    if (fraction === null) {
      this.progressWrap.classList.add("indeterminate");
      this.progressBar.style.width = "";
      this.progressPercent.textContent = "";
      return;
    }
    const percent = Math.round(Math.min(1, Math.max(0, fraction)) * 100);
    this.progressWrap.classList.remove("indeterminate");
    this.progressBar.style.width = `${percent}%`;
    this.progressPercent.textContent = `${percent}%`;
  }
}
const status = new StatusView();
const toggle = element("toggle");
const tabNote = element("tabNote");
const captureNote = element("captureNote");
const diagnostics = element("diagnostics");
const notices = element("notices");
const reviewPrompt = element("reviewPrompt");
const reviewNow = element("reviewNow");
const reviewDismiss = element("reviewDismiss");
const shareButton = element("share");
const reviewButton = element("review");
const proCard = element("proCard");
const proHeading = element("proHeading");
const proState = element("proState");
const proInfo = element("proInfo");
const proPlans = element("proPlans");
const proBuy = element("proBuy");
const proLogin = element("proLogin");
const proManage = element("proManage");
const proSupport = element("proSupport");
const deviceNote = element("deviceNote");
const trLocalCpu = element("trLocalCpu");
let entitlement = null;
let plans = [];
const SITE_URL = "https://konstbet.github.io/brevier-site/";
const REVIEW_URL = "https://chromewebstore.google.com/detail/jfljjchlfbijcnbkagkiolngfebljapa/reviews";
const SHARE_TEXT = "Private, on-device live captions and translation for any Chrome tab — free.";
const CAPTION_STARTS_KEY = "captionStarts";
const REVIEW_PROMPT_SEEN_KEY = "reviewPromptSeen";
const REVIEW_AFTER_STARTS = 3;
function isPro() {
  return entitlement !== null && isProEntitlement(entitlement);
}
function isSubscriber() {
  return entitlement?.subscriber === true;
}
async function loadEntitlement() {
  try {
    const response = await chrome.runtime.sendMessage({
      type: "popup:get-entitlement"
    });
    if (response?.entitlement) entitlement = response.entitlement;
    if (response) {
      plans = Array.isArray(response.plans) ? response.plans : [];
    }
  } catch {
  }
  renderProCard();
}
const SUPPORTER_SINCE = new Intl.DateTimeFormat(void 0, { month: "short", year: "numeric" });
function paidLine(state) {
  if (state.paidAt <= 0) return "Thank you 👍";
  const when = SUPPORTER_SINCE.format(new Date(state.paidAt));
  return isOneOffPass(state) ? `Thank you · ${when}` : `Since ${when}`;
}
function renderPlans() {
  proPlans.replaceChildren();
  const ordered = [...plans].sort(comparePlans);
  const roles = planRoles(ordered);
  ordered.forEach((plan, index) => {
    const button = document.createElement("button");
    button.type = "button";
    button.className = roles[index] === "standard" ? "pro-plan" : `pro-plan is-${roles[index]}`;
    const name = planLabel(plan);
    if (name !== null) {
      const nameElement = document.createElement("span");
      nameElement.className = "pro-plan-name";
      nameElement.textContent = name;
      button.append(nameElement);
    }
    const price = document.createElement("strong");
    price.className = "pro-plan-price";
    price.textContent = formatPlanPrice(plan);
    const term = document.createElement("span");
    term.className = "pro-plan-term";
    term.textContent = formatPlanTerm(plan);
    button.append(price, term);
    button.addEventListener(
      "click",
      () => openPurchasePage({ type: "popup:open-upgrade", plan: plan.nickname ?? void 0 })
    );
    proPlans.append(button);
  });
  setHidden(proPlans, plans.length === 0);
}
function renderProCard() {
  const pro = isPro();
  setHidden(proCard, false);
  proCard.classList.toggle("is-pro", pro);
  if (pro) {
    const paid = entitlement;
    proHeading.textContent = paid ? passLabel(paid) : "Supporter";
    proState.textContent = paid ? paidLine(paid) : "Thank you 👍";
    setHidden(proInfo, true);
    setHidden(proPlans, true);
    setHidden(proBuy, true);
    setHidden(proLogin, true);
    setHidden(proManage, !isSubscriber());
    setHidden(proSupport, true);
    return;
  }
  proHeading.textContent = "Support Brevier";
  proState.textContent = "";
  proInfo.textContent = "All 39 languages and engines are free for everyone. A tip is a one-off thanks; a yearly Patron pass is what keeps the work going.";
  setHidden(proInfo, false);
  renderPlans();
  setHidden(proBuy, plans.length > 0);
  setHidden(proLogin, false);
  setHidden(proManage, true);
  setHidden(proSupport, false);
}
function openPurchasePage(request) {
  void chrome.runtime.sendMessage(request).then((response) => {
    const result = response;
    if (result && result.ok === false && result.error) {
      proInfo.textContent = result.error;
      setHidden(proInfo, false);
      proCard.scrollIntoView({ block: "nearest" });
    }
  }).catch((error) => {
    console.error("[brevier] purchase message failed", error);
    proInfo.textContent = "Could not reach the extension service worker. Reload the extension on chrome://extensions and try again.";
    setHidden(proInfo, false);
    proCard.scrollIntoView({ block: "nearest" });
  });
}
function openExternal(url) {
  void chrome.tabs.create({ url });
}
let lastAppState = null;
let captureNoteKey = "";
let captureNoteToken = 0;
async function updateCaptureNote(state) {
  if (!state.capturing) {
    captureNoteToken += 1;
    captureNoteKey = "";
    setHidden(captureNote, true);
    return;
  }
  if (state.overlayWarning) {
    captureNoteToken += 1;
    captureNoteKey = "";
    captureNote.textContent = state.overlayWarning;
    captureNote.classList.add("warn");
    setHidden(captureNote, false);
    return;
  }
  if (state.tabId === null) {
    captureNoteToken += 1;
    captureNoteKey = "";
    setHidden(captureNote, true);
    return;
  }
  const key = String(state.tabId);
  if (key === captureNoteKey) return;
  captureNoteKey = key;
  const token = ++captureNoteToken;
  try {
    const [active] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const tab = await chrome.tabs.get(state.tabId);
    if (token !== captureNoteToken) return;
    const elsewhere = active?.id !== state.tabId;
    captureNote.textContent = elsewhere ? `Capturing “${tab.title ?? "another tab"}” — switch to that tab to see captions.` : "Capturing this tab.";
    captureNote.classList.toggle("warn", elsewhere);
    setHidden(captureNote, false);
  } catch {
    if (token === captureNoteToken) setHidden(captureNote, true);
  }
}
function renderState(state) {
  lastAppState = state;
  status.render(state);
  void updateCaptureNote(state);
}
function bumpCaptionStarts() {
  void chrome.storage.local.get(CAPTION_STARTS_KEY).then((stored) => {
    const starts = Number(stored[CAPTION_STARTS_KEY] ?? 0) + 1;
    return chrome.storage.local.set({ [CAPTION_STARTS_KEY]: starts });
  }).catch(() => {
  });
}
function markReviewPromptSeen() {
  void chrome.storage.local.set({ [REVIEW_PROMPT_SEEN_KEY]: true }).catch(() => {
  });
}
async function maybeShowReviewPrompt() {
  if (status.capturing) return;
  try {
    const stored = await chrome.storage.local.get([CAPTION_STARTS_KEY, REVIEW_PROMPT_SEEN_KEY]);
    if (stored[REVIEW_PROMPT_SEEN_KEY] === true) return;
    if (Number(stored[CAPTION_STARTS_KEY] ?? 0) < REVIEW_AFTER_STARTS) return;
    markReviewPromptSeen();
    setHidden(reviewPrompt, false);
  } catch {
  }
}
function closeReviewPrompt() {
  markReviewPromptSeen();
  setHidden(reviewPrompt, true);
}
function openReviewPage() {
  closeReviewPrompt();
  openExternal(REVIEW_URL);
}
async function shareBrevier() {
  if (typeof navigator.share === "function") {
    try {
      await navigator.share({ title: "Brevier", text: SHARE_TEXT, url: SITE_URL });
      return;
    } catch (error) {
      if (error instanceof DOMException && error.name === "AbortError") return;
    }
  }
  try {
    await navigator.clipboard.writeText(`${SHARE_TEXT} ${SITE_URL}`);
    shareButton.textContent = "Copied";
    window.setTimeout(() => {
      shareButton.textContent = "Share";
    }, 1500);
  } catch {
    openExternal(SITE_URL);
  }
}
async function notifySettingsChanged() {
  try {
    await chrome.runtime.sendMessage({ type: "popup:settings-changed" });
  } catch {
  }
}
const form = new SettingsForm({
  applyPatch: async (patch, options) => {
    const settings = await updateSettings(patch);
    if (!options?.skipLanguageRefresh) {
      form.render(settings);
    }
    if (patch.engine !== void 0 || patch.language !== void 0 || patch.qwenModel !== void 0 || patch.translation !== void 0) {
      await notifySettingsChanged();
    }
  },
  onRendered: () => chromeTranslation.refresh()
});
const chromeTranslation = new ChromeTranslationPanel(
  () => form.settings,
  notifySettingsChanged
);
toggle.addEventListener("click", () => {
  const capturing = status.capturing;
  if (!capturing) bumpCaptionStarts();
  toggle.disabled = true;
  void chrome.runtime.sendMessage({ type: capturing ? "popup:stop" : "popup:start" }).then((response) => {
    const state = response?.state;
    if (state) renderState(state);
  }).catch((error) => {
    status.showError(errorMessage(error));
  }).finally(() => {
    toggle.disabled = false;
  });
});
diagnostics.addEventListener("click", () => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("debug/debug.html") });
});
notices.addEventListener("click", () => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("notices.html") });
});
shareButton.addEventListener("click", () => void shareBrevier());
reviewButton.addEventListener("click", openReviewPage);
reviewNow.addEventListener("click", openReviewPage);
reviewDismiss.addEventListener("click", closeReviewPrompt);
proBuy.addEventListener("click", () => openPurchasePage({ type: "popup:open-upgrade" }));
proLogin.addEventListener("click", () => openPurchasePage({ type: "popup:open-login" }));
proManage.addEventListener("click", () => openPurchasePage({ type: "popup:open-upgrade" }));
chrome.runtime.onMessage.addListener((message) => {
  if (typeof message === "object" && message !== null && message.type === "bg:state") {
    renderState(message.state);
  }
});
chrome.tabs.onActivated.addListener(() => {
  captureNoteKey = "";
  if (lastAppState) void updateCaptureNote(lastAppState);
});
const INTERNAL_TAB = /^(chrome|chrome-extension|chrome-untrusted|devtools|edge|about|view-source):/i;
async function updateDeviceNote() {
  const gpu = await hasWebGpu();
  deviceNote.classList.toggle("warn", !gpu);
  deviceNote.textContent = gpu ? "WebGPU is active — captions keep up with speech." : "WebGPU is not available, so engines run on the CPU. Captions may lag on long sentences.";
  setHidden(trLocalCpu, gpu);
  form.setCpuOnly(!gpu);
  chromeTranslation.setCpuFallback(!gpu);
}
async function checkCapturableTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const url = tab?.url ?? tab?.pendingUrl ?? "";
    const internal = url !== "" && INTERNAL_TAB.test(url);
    setHidden(tabNote, !internal);
  } catch {
    setHidden(tabNote, true);
  }
}
async function init() {
  const settings = await loadSettings();
  form.render(settings);
  void updateDeviceNote();
  void checkCapturableTab();
  void loadEntitlement();
  try {
    const response = await chrome.runtime.sendMessage({
      type: "popup:get-state"
    });
    if (response?.state) renderState(response.state);
  } catch {
  }
  void maybeShowReviewPrompt();
}
void init();
