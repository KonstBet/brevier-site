function formatPlanPrice(plan) {
  const amount = plan.unitAmountCents / 100;
  try {
    return new Intl.NumberFormat(void 0, {
      style: "currency",
      currency: plan.currency
    }).format(amount);
  } catch {
    return `${plan.currency.toUpperCase()} ${amount.toFixed(2)}`;
  }
}
function comparePlans(a, b) {
  const group = (plan) => plan.interval === "once" || plan.interval === null ? 0 : 1;
  return group(a) - group(b) || a.unitAmountCents - b.unitAmountCents;
}
const PURCHASABLE_PLAN_IDS = /* @__PURE__ */ new Set(["tip", "pro-monthly", "pro-yearly"]);
const FRIENDLY_PLAN_NAMES = {
  patron: "Patron",
  pro: "Studio Pro",
  "pro-monthly": "Studio Pro monthly",
  "pro-yearly": "Studio Pro yearly",
  supporter: "Supporter",
  tip: "Tip"
};
function isPurchasablePlan(plan) {
  return PURCHASABLE_PLAN_IDS.has(plan.nickname?.trim().toLowerCase() ?? "");
}
function planLabel(plan) {
  const nickname = plan.nickname?.trim();
  if (!nickname) return null;
  const key = nickname.toLowerCase();
  return FRIENDLY_PLAN_NAMES[key] ?? nickname.charAt(0).toUpperCase() + nickname.slice(1);
}
function isRecurring(plan) {
  return plan.interval !== null && plan.interval !== "once";
}
function priciest(plans) {
  return plans.reduce((a, b) => b.unitAmountCents > a.unitAmountCents ? b : a);
}
function planRoles(plans) {
  if (plans.length < 2) return plans.map(() => "standard");
  const recurring = plans.filter(isRecurring);
  const oneOffs = plans.filter((plan) => !isRecurring(plan));
  const featured = priciest(recurring.length > 0 ? recurring : plans);
  const quiet = oneOffs.length > 0 ? oneOffs.reduce((a, b) => b.unitAmountCents < a.unitAmountCents ? b : a) : null;
  return plans.map((plan) => {
    if (plan === featured) return "featured";
    if (plan === quiet) return "quiet";
    return "standard";
  });
}
function formatPlanTerm(plan) {
  const unit = plan.interval === "year" ? "year" : plan.interval === "month" ? "month" : plan.interval === "week" ? "week" : plan.interval === "day" ? "day" : null;
  if (unit === null) return "one-time";
  const count = plan.intervalCount ?? 1;
  return count === 1 ? `per ${unit}` : `every ${count} ${unit}s`;
}
const ENTITLEMENT_MAX_AGE_MS = 12 * 60 * 60 * 1e3;
const FREE_ENTITLEMENT = {
  status: "free",
  subscriber: false,
  plan: null,
  paidAt: 0,
  checkedAt: 0
};
function pickTime(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function pickPlan(value) {
  if (typeof value !== "object" || value === null) return null;
  const raw = value;
  const nickname = typeof raw.nickname === "string" ? raw.nickname.trim() || null : null;
  const interval = typeof raw.interval === "string" ? raw.interval : null;
  if (nickname === null && interval === null) return null;
  return { nickname, interval };
}
function normalizeEntitlement(input) {
  if (typeof input !== "object" || input === null) return { ...FREE_ENTITLEMENT };
  const raw = input;
  return {
    status: raw.status === "pro" ? "pro" : "free",
    subscriber: raw.subscriber === true,
    plan: pickPlan(raw.plan),
    paidAt: pickTime(raw.paidAt) ?? 0,
    checkedAt: pickTime(raw.checkedAt) ?? 0
  };
}
function isProEntitlement(state) {
  return state.status === "pro";
}
const PRO_PLAN_IDS = /* @__PURE__ */ new Set(["pro", "pro-monthly", "pro-yearly", "patron"]);
function isProPlan(state) {
  if (state.plan?.interval === "once") return false;
  if (state.subscriber) return true;
  const nickname = state.plan?.nickname?.trim().toLowerCase();
  return nickname !== void 0 && PRO_PLAN_IDS.has(nickname);
}
function hasProAccess(state) {
  return state.status === "pro" && isProPlan(state);
}
function passLabel(state) {
  return state.plan ? planLabel(state.plan) ?? "Supporter" : "Supporter";
}
function isOneOffPass(state) {
  if (state.status !== "pro") return false;
  if (state.plan?.interval === "once") return true;
  return state.plan === null && !state.subscriber;
}
function entitlementIsStale(state, now = Date.now()) {
  return now - state.checkedAt > ENTITLEMENT_MAX_AGE_MS;
}
export {
  FREE_ENTITLEMENT as F,
  isProEntitlement as a,
  isOneOffPass as b,
  comparePlans as c,
  planRoles as d,
  entitlementIsStale as e,
  planLabel as f,
  formatPlanPrice as g,
  hasProAccess as h,
  isPurchasablePlan as i,
  formatPlanTerm as j,
  normalizeEntitlement as n,
  passLabel as p
};
