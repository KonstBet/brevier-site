import { H as HunyuanTranslationProvider, c as createEngine } from "./provider-DRyXc1qw.js";
import { c as isOffscreenMessage, e as errorMessage } from "./messages-DlSg0HH_.js";
import { d as detectHunyuanRestricted, t as translationSignature, e as engineSignature, s as spokenLanguage } from "./region-C_na-waw.js";
import { C as ChromeTranslationProvider } from "./translation-languages-BWIVOYyr.js";
const CACHE_LIMIT = 300;
class CaptionTranslator {
  options;
  cache = /* @__PURE__ */ new Map();
  inflight = /* @__PURE__ */ new Map();
  sequence = 0;
  generation = 0;
  constructor(options) {
    this.options = options;
  }
  /** Forward immediately; any translation arrives later via onUpdate. */
  handle(event) {
    if (event.kind !== "final") return event;
    const forwarded = event.lineId ? event : { ...event, lineId: `line-${++this.sequence}` };
    if (forwarded.text.trim() !== "") {
      void this.translateLine(forwarded);
    }
    return forwarded;
  }
  /** Drops updates from the previous provider/session. */
  reset() {
    this.generation++;
  }
  async translateLine(event) {
    const generation = this.generation;
    try {
      const translation = await this.translateText(event.text.trim());
      if (generation !== this.generation) return;
      this.options.onUpdate({ ...event, translation, at: Date.now() });
    } catch (error) {
      if (generation !== this.generation) return;
      this.options.onError(error instanceof Error ? error : new Error(String(error)));
    }
  }
  translateText(text) {
    const cached = this.cache.get(text);
    if (cached !== void 0) return Promise.resolve(cached);
    const existing = this.inflight.get(text);
    if (existing) return existing;
    const request = this.options.provider.translate(text).then((translation) => {
      this.inflight.delete(text);
      this.cache.set(text, translation);
      while (this.cache.size > CACHE_LIMIT) {
        const oldest = this.cache.keys().next().value;
        if (oldest === void 0) break;
        this.cache.delete(oldest);
      }
      return translation;
    }).catch((error) => {
      this.inflight.delete(text);
      throw error;
    });
    this.inflight.set(text, request);
    return request;
  }
}
function createTranslationProvider(id) {
  if (id === "hunyuan" && detectHunyuanRestricted()) {
    console.warn(
      "[brevier] Hunyuan-MT is not available in this region; using Chrome translation."
    );
    return new ChromeTranslationProvider();
  }
  switch (id) {
    case "hunyuan":
      return new HunyuanTranslationProvider();
    case "chrome":
    default:
      return new ChromeTranslationProvider();
  }
}
const CHUNK_SIZE = 2048;
function tabAudioConstraints(streamId) {
  return {
    audio: {
      // Tab capture only accepts the legacy `mandatory` form; adding standard
      // constraints such as echoCancellation alongside it makes Chrome throw
      // "Malformed constraint". WebRTC processing is bypassed for tab capture
      // anyway, so there is nothing else to disable.
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId
      }
    },
    video: false
  };
}
function describeCaptureError(error) {
  const message = error instanceof Error ? error.message : String(error);
  if (/error starting tab capture/i.test(message)) {
    return "Chrome refused to start tab capture for this tab. This happens on chrome:// or extension pages, or when the tab is already being captured. Open the website that is playing audio and try again.";
  }
  return message;
}
class TabAudioCapture {
  context = null;
  stream = null;
  source = null;
  worklet = null;
  async start(streamId, onFrame) {
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia(tabAudioConstraints(streamId));
    } catch (error) {
      throw new Error(describeCaptureError(error));
    }
    this.stream = stream;
    const context = new AudioContext({ latencyHint: "interactive" });
    this.context = context;
    await context.audioWorklet.addModule(chrome.runtime.getURL("pcm-worklet.js"));
    context.addEventListener("statechange", () => {
      if (context.state === "suspended") {
        void context.resume().catch(() => {
        });
      }
    });
    const source = context.createMediaStreamSource(stream);
    this.source = source;
    const worklet = new AudioWorkletNode(context, "pcm-capture", {
      numberOfInputs: 1,
      // A zero-output worklet is not guaranteed to be pulled by the render
      // graph, so it gets a silent output that we connect to the destination.
      // (The processor never writes to it; tab audio passthrough is the direct
      // source -> destination connection below.)
      numberOfOutputs: 1,
      outputChannelCount: [1],
      processorOptions: { chunkSize: CHUNK_SIZE }
    });
    this.worklet = worklet;
    worklet.port.onmessage = (event) => {
      onFrame(event.data, context.sampleRate);
    };
    source.connect(worklet);
    worklet.connect(context.destination);
    source.connect(context.destination);
    if (context.state === "suspended") {
      await context.resume();
    }
  }
  async stop() {
    try {
      this.worklet?.port.close();
      this.worklet?.disconnect();
      this.source?.disconnect();
    } catch {
    }
    this.worklet = null;
    this.source = null;
    this.stream?.getTracks().forEach((track) => track.stop());
    this.stream = null;
    const context = this.context;
    this.context = null;
    if (context && context.state !== "closed") {
      await context.close();
    }
  }
  get active() {
    return this.context !== null;
  }
}
function send(message) {
  void chrome.runtime.sendMessage(message).catch(() => {
  });
}
class OffscreenHost {
  capture = new TabAudioCapture();
  engine = null;
  settings = null;
  /** Settings signature the live engine was built from. */
  engineSignatureValue = "";
  /** Translation layer (null when translation is disabled or failed). */
  translator = null;
  translationProvider = null;
  translationSignatureValue = "";
  translationGeneration = 0;
  translationStatus = "off";
  translationDetail = "";
  status = "idle";
  detail = "Idle";
  progress = null;
  lastError = null;
  /** Status heartbeat timer used while starting/loading. */
  ticker = null;
  loadingStartedAt = null;
  /** Audio activity reporting (peak RMS since the last report). */
  audioPeak = 0;
  audioReportedAt = 0;
  /**
   * Bumped whenever a new start/stop/rebuild begins. Async continuations from
   * older generations bail out so stale model loads cannot take over a newer
   * session.
   */
  generation = 0;
  get capturing() {
    return this.capture.active;
  }
  async start(streamId, settings) {
    const generation = ++this.generation;
    this.settings = settings;
    this.lastError = null;
    this.progress = null;
    this.audioPeak = 0;
    this.audioReportedAt = Date.now();
    send({ type: "offscreen:audio", level: 0 });
    this.setStatus("starting", "Starting…");
    try {
      await this.capture.start(streamId, (samples, sampleRate) => {
        this.reportAudio(samples);
        this.engine?.pushAudio(samples, sampleRate);
      });
      if (generation !== this.generation) return;
      const engine = await this.buildEngine(settings, generation);
      if (!engine || generation !== this.generation) return;
      this.setStatus("ready", "Captions on");
      void this.applyTranslation(settings);
    } catch (error) {
      if (generation !== this.generation) return;
      await this.teardown();
      this.fail(error);
    }
  }
  async stop() {
    this.generation++;
    await this.teardown();
    this.progress = null;
    this.setStatus("idle", "Idle");
  }
  /**
   * Applies settings while running. Overlay-only changes are ignored here
   * (the content script handles them); engine-relevant changes rebuild the
   * engine but leave the audio capture untouched — the tab stream cannot be
   * re-acquired from the same stream id.
   */
  async updateSettings(settings) {
    this.settings = settings;
    if (!this.capturing) return;
    const translationChanged = translationSignature(settings) !== this.translationSignatureValue;
    const translationRetry = settings.translation.enabled && this.translationStatus === "error";
    if (translationChanged || translationRetry) {
      void this.applyTranslation(settings);
    }
    if (engineSignature(settings) === this.engineSignatureValue) return;
    const generation = ++this.generation;
    this.progress = null;
    this.setStatus("loading", "Applying new engine settings…");
    try {
      const engine = await this.buildEngine(settings, generation);
      if (!engine || generation !== this.generation) return;
      this.setStatus("ready", "Captions on");
    } catch (error) {
      if (generation !== this.generation) return;
      await this.teardown();
      this.fail(error);
    }
  }
  getState() {
    return {
      capturing: this.capturing,
      status: this.status,
      detail: this.detail,
      progress: this.progress,
      error: this.lastError,
      translationStatus: this.translationStatus,
      translationDetail: this.translationDetail
    };
  }
  async buildEngine(settings, generation) {
    await this.disposeEngine();
    if (generation !== this.generation) return null;
    const engine = createEngine(settings.engine);
    this.engine = engine;
    this.engineSignatureValue = engineSignature(settings);
    const isCurrent = () => generation === this.generation;
    await engine.initialize({
      settings,
      events: {
        onStatus: (status, detail) => {
          if (!isCurrent()) return;
          this.setStatus(status, detail ?? defaultDetail(status));
        },
        onProgress: (progress) => {
          if (!isCurrent()) return;
          this.progress = progress;
          send({ type: "offscreen:progress", progress });
        },
        onCaption: (event) => {
          if (!isCurrent()) return;
          const forwarded = this.translator ? this.translator.handle(event) : event;
          send({ type: "offscreen:caption", event: forwarded });
        },
        onError: (error) => {
          if (!isCurrent()) return;
          this.fail(error);
        }
      }
    });
    if (!isCurrent()) return null;
    await engine.start();
    if (!isCurrent()) return null;
    this.progress = null;
    return engine;
  }
  async disposeEngine() {
    const engine = this.engine;
    this.engine = null;
    this.engineSignatureValue = "";
    if (!engine) return;
    try {
      await engine.dispose();
    } catch {
    }
  }
  /**
   * Builds (or tears down) the translation layer for the given settings.
   * Failures are surfaced to the popup but never stop the captions.
   */
  async applyTranslation(settings) {
    this.disposeTranslation();
    const generation = this.translationGeneration;
    this.translationSignatureValue = translationSignature(settings);
    if (!settings.translation.enabled) {
      this.reportTranslation("off", "");
      return;
    }
    const provider = createTranslationProvider(settings.translation.provider);
    this.translationProvider = provider;
    this.translator = new CaptionTranslator({
      provider,
      onUpdate: (event) => {
        if (generation !== this.translationGeneration) return;
        send({ type: "offscreen:caption", event });
      },
      onError: (error) => {
        if (generation !== this.translationGeneration) return;
        this.reportTranslation("error", error.message);
      }
    });
    this.reportTranslation("loading", "Preparing translation…");
    try {
      await provider.initialize({
        sourceLanguage: spokenLanguage(settings),
        targetLanguage: settings.translation.targetLanguage,
        settings: settings.translation,
        onProgress: (progress) => {
          if (generation !== this.translationGeneration) return;
          if (!progress) {
            this.reportTranslation("loading", "Preparing translation…");
            return;
          }
          const percent = progress.fraction === null ? "" : ` ${Math.round(progress.fraction * 100)}%`;
          this.reportTranslation("loading", `${progress.detail}${percent}`);
        }
      });
      if (generation !== this.translationGeneration) return;
      this.reportTranslation("ready", `Translating to ${settings.translation.targetLanguage}`);
    } catch (error) {
      if (generation !== this.translationGeneration) return;
      this.disposeTranslation();
      this.reportTranslation("error", errorMessage(error));
    }
  }
  disposeTranslation() {
    this.translationGeneration++;
    this.translator?.reset();
    this.translator = null;
    const provider = this.translationProvider;
    this.translationProvider = null;
    try {
      provider?.dispose();
    } catch {
    }
  }
  reportTranslation(status, detail) {
    this.translationStatus = status;
    this.translationDetail = detail;
    send({ type: "offscreen:translation", status, detail });
  }
  async teardown() {
    this.disposeTranslation();
    this.translationSignatureValue = "";
    this.reportTranslation("off", "");
    const engine = this.engine;
    this.engine = null;
    this.engineSignatureValue = "";
    if (engine) {
      try {
        await engine.stop();
      } catch {
      }
    }
    await this.capture.stop();
    if (engine) {
      try {
        await engine.dispose();
      } catch {
      }
    }
  }
  /**
   * While the pipeline is starting or loading, resend the status every few
   * seconds with the elapsed time. This gives the popup visible movement and
   * doubles as a heartbeat: if these stop arriving while capture is running,
   * the offscreen document has been torn down by the browser.
   */
  startLoadingTicker() {
    if (this.ticker !== null) return;
    this.loadingStartedAt = Date.now();
    const baseDetail = this.detail;
    this.ticker = window.setInterval(() => {
      if (this.status !== "loading" && this.status !== "starting") {
        this.stopLoadingTicker();
        return;
      }
      const seconds = Math.round((Date.now() - (this.loadingStartedAt ?? Date.now())) / 1e3);
      this.detail = `${baseDetail} (${seconds}s)`;
      send({ type: "offscreen:status", status: this.status, detail: this.detail });
    }, 5e3);
  }
  stopLoadingTicker() {
    if (this.ticker !== null) {
      window.clearInterval(this.ticker);
      this.ticker = null;
    }
    this.loadingStartedAt = null;
  }
  /**
   * Reports the captured audio level twice a second so the popup can show
   * whether sound is actually flowing (and distinguish "no audio" from
   * "no speech recognized").
   */
  reportAudio(samples) {
    let sum = 0;
    for (let i = 0; i < samples.length; i++) {
      sum += samples[i] * samples[i];
    }
    const rms = Math.sqrt(sum / samples.length);
    if (rms > this.audioPeak) this.audioPeak = rms;
    const now = Date.now();
    if (now - this.audioReportedAt >= 500) {
      this.audioReportedAt = now;
      send({ type: "offscreen:audio", level: this.audioPeak });
      this.audioPeak = 0;
    }
  }
  setStatus(status, detail) {
    this.status = status;
    this.detail = detail;
    if (status !== "error") this.lastError = null;
    if (status === "loading" || status === "starting") {
      if (this.ticker === null) this.startLoadingTicker();
    } else {
      this.stopLoadingTicker();
    }
    send({ type: "offscreen:status", status, detail });
  }
  fail(error) {
    this.stopLoadingTicker();
    this.lastError = errorMessage(error);
    this.status = "error";
    this.detail = this.lastError;
    this.progress = null;
    send({
      type: "offscreen:status",
      status: "error",
      detail: this.lastError,
      error: this.lastError
    });
  }
}
function defaultDetail(status) {
  switch (status) {
    case "idle":
      return "Idle";
    case "starting":
      return "Starting…";
    case "loading":
      return "Loading model…";
    case "ready":
      return "Captions on";
    case "error":
      return "Error";
  }
}
const host = new OffscreenHost();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!isOffscreenMessage(message)) return false;
  const request = message;
  switch (request.type) {
    case "offscreen:start":
      void host.start(request.streamId, request.settings);
      sendResponse({ ok: true });
      return false;
    case "offscreen:stop":
      void host.stop().finally(() => sendResponse({ ok: true }));
      return true;
    case "offscreen:update-settings":
      void host.updateSettings(request.settings);
      sendResponse({ ok: true });
      return false;
    case "offscreen:get-state":
      sendResponse({ ok: true, state: host.getState() });
      return false;
    default:
      return false;
  }
});
send({ type: "offscreen:status", status: "idle", detail: "Idle" });
