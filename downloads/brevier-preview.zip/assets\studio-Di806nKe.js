import { s as studioEngineOrder, e as engineConfig, G as GpuAsrEngine } from "./provider-DCStykE9.js";
import { s as setHidden, e as element } from "./dom-qkm_bq4-.js";
import { h as hasProAccess } from "./entitlements-Cd5_pDR4.js";
import { e as errorMessage, v as STUDIO_LEASE_HEARTBEAT_MS, w as DEFAULT_SETTINGS, u as SUPPORTED_LANGUAGES } from "./settings-DWyWJaRh.js";
import { l as loadSettings } from "./storage-CLAsZ_Ro.js";
import { t as translationLanguageName, T as TRANSLATION_LANGUAGES } from "./translation-languages-DuT0gDGk.js";
import { h as hasWebGpu } from "./webgpu-D1jNrLJ3.js";
import { c as createTranslationProvider } from "./registry-B73q7RfT.js";
const SAMPLE_RATE$1 = 16e3;
function hasSubtitleTimestamps(text) {
  return /\d{1,2}:\d{2}(?::\d{2})?[,.]\d{1,3}\s*-->\s*/u.test(text);
}
const MAX_LINE_CHARS = 42;
const CJK_LINE_CHARS = 20;
const THAI_LINE_CHARS = 30;
const MAX_CUE_SECONDS = 7;
const MIN_CUE_SECONDS = 0.8;
const MIN_GAP_SECONDS = 0.08;
const TAIL_PAD_SECONDS = 0.4;
const MAX_CHARS_PER_SECOND = 20;
const PAUSE_SNAP_SECONDS = 1;
const MIN_SNAPPED_CUE_SECONDS = 0.4;
const CJK_LANGUAGES = /* @__PURE__ */ new Set(["zh", "ja", "ko", "yue"]);
function isUnspaced(language) {
  return CJK_LANGUAGES.has(language) || language === "th";
}
function lineLimit(language) {
  if (CJK_LANGUAGES.has(language)) return CJK_LINE_CHARS;
  if (language === "th") return THAI_LINE_CHARS;
  return MAX_LINE_CHARS;
}
function cleanText(text) {
  return text.replace(/\s+/gu, " ").trim();
}
function segment(text, language, granularity) {
  try {
    if (typeof Intl.Segmenter === "function") {
      const segmenter = new Intl.Segmenter(language, { granularity });
      return Array.from(segmenter.segment(text), (part) => part.segment);
    }
  } catch {
  }
  if (granularity === "sentence") {
    return text.match(/[^.!?。！？…]+[.!?。！？…]+|[^.!?。！？…]+$/gu) ?? [text];
  }
  return isUnspaced(language) ? Array.from(text) : text.split(/\s+/u);
}
function isPunctuation(text) {
  return /^[\p{P}\p{S}]+$/u.test(text);
}
function joinUnits(units2, language) {
  return units2.join(isUnspaced(language) ? "" : " ");
}
function units(text, language) {
  if (!isUnspaced(language)) {
    return text.split(/\s+/u).filter((part) => part !== "");
  }
  const output = [];
  for (const part of segment(text, language, "word")) {
    if (part === "") continue;
    if (/^\s+$/u.test(part)) {
      if (output.length > 0 && output[output.length - 1] !== " ") output.push(" ");
      continue;
    }
    if (isPunctuation(part) && output.length > 0 && output[output.length - 1] !== " ") {
      output[output.length - 1] += part;
      continue;
    }
    output.push(part);
  }
  while (output.length > 0 && output[output.length - 1] === " ") output.pop();
  return output;
}
function sentences(text, language) {
  return segment(text, language, "sentence").map((part) => part.trim()).filter((part) => part !== "");
}
function splitLongUnit(unit, maxChars) {
  if (unit.length <= maxChars) return [unit];
  const parts = [];
  for (let start = 0; start < unit.length; start += maxChars) {
    parts.push(unit.slice(start, start + maxChars));
  }
  return parts;
}
function packText(text, language, maxChars) {
  const output = [];
  const limit = lineLimit(language);
  let current = "";
  const fits = (value) => value.length <= maxChars && (value.length <= limit || splitIndex(value, language, limit) >= 0);
  const append = (piece) => {
    const separator = current !== "" && !isUnspaced(language) ? " " : "";
    const candidate = current + separator + piece;
    if (fits(candidate)) {
      current = candidate;
      return;
    }
    if (current !== "") {
      output.push(current.trim());
      current = "";
    }
    if (fits(piece)) {
      current = piece;
      return;
    }
    for (const part of splitLongUnit(piece, limit)) {
      if (part.length === limit) output.push(part);
      else current = part;
    }
  };
  for (const sentence of sentences(text, language)) {
    if (sentence.length <= maxChars) {
      append(sentence);
      continue;
    }
    for (const unit of units(sentence, language)) {
      append(unit);
    }
  }
  if (current.trim() !== "") output.push(current.trim());
  return output;
}
function splitIndex(text, language, limit) {
  if (text.length <= limit) return -1;
  const list = units(text, language);
  if (list.length <= 1) return -1;
  let bestIndex = -1;
  let bestScore = Number.POSITIVE_INFINITY;
  for (let i = 0; i < list.length - 1; i++) {
    const first = joinUnits(list.slice(0, i + 1), language).trim();
    const second = joinUnits(list.slice(i + 1), language).trim();
    if (first.length > limit || second.length > limit) continue;
    const punctuationBonus = /[.!?。！？,;:，、；：—–-]$/u.test(first) ? limit : 0;
    const score = Math.abs(first.length - second.length) - punctuationBonus;
    if (score < bestScore) {
      bestScore = score;
      bestIndex = i;
    }
  }
  return bestIndex;
}
function wrapText(text, language, limit) {
  if (text.length <= limit) return [text];
  const list = units(text, language);
  const index = splitIndex(text, language, limit);
  if (index >= 0) {
    return [
      joinUnits(list.slice(0, index + 1), language).trim(),
      joinUnits(list.slice(index + 1), language).trim()
    ];
  }
  return [text.slice(0, limit), text.slice(limit).trim()];
}
function snapBoundaries(boundaries, pauses, startSample, endSample) {
  if (boundaries.length === 0 || pauses.length === 0) return boundaries;
  const window2 = Math.round(PAUSE_SNAP_SECONDS * SAMPLE_RATE$1);
  const minCue = Math.round(MIN_SNAPPED_CUE_SECONDS * SAMPLE_RATE$1);
  const maxCue = Math.round(MAX_CUE_SECONDS * SAMPLE_RATE$1);
  const output = [];
  let previous = startSample;
  let first = 0;
  for (let index = 0; index < boundaries.length; index++) {
    const boundary = boundaries[index];
    const next = index + 1 < boundaries.length ? boundaries[index + 1] : endSample;
    let best = -1;
    let bestDistance = window2 + 1;
    for (let i = first; i < pauses.length; i++) {
      const pause = pauses[i];
      if (pause > boundary + window2) break;
      if (pause - previous < minCue || pause - previous > maxCue) continue;
      if (next - pause < minCue || next - pause > maxCue) continue;
      const distance = Math.abs(pause - boundary);
      if (distance < bestDistance) {
        bestDistance = distance;
        best = i;
      }
    }
    const value = best >= 0 ? pauses[best] : boundary;
    const safe = Math.max(value, previous + 1);
    output.push(safe);
    previous = safe;
    if (best >= 0) first = best + 1;
  }
  return output;
}
function finalize(cues, durationSamples) {
  const ordered = cues.slice().sort((a, b) => a.startSample - b.startSample);
  const limit = durationSamples !== void 0 && durationSamples > 0 ? durationSamples : Number.POSITIVE_INFINITY;
  const minGap = Math.round(MIN_GAP_SECONDS * SAMPLE_RATE$1);
  const minCue = Math.round(MIN_CUE_SECONDS * SAMPLE_RATE$1);
  const maxCue = Math.round(MAX_CUE_SECONDS * SAMPLE_RATE$1);
  const tailPad = Math.round(TAIL_PAD_SECONDS * SAMPLE_RATE$1);
  const output = [];
  for (let i = 0; i < ordered.length; i++) {
    const cue = ordered[i];
    if (cue.startSample >= limit) continue;
    const next = ordered[i + 1];
    const start = Math.max(0, Math.min(cue.startSample, limit - 1));
    const nextStart = Math.min(next ? next.startSample : limit, limit);
    const gap = nextStart - cue.endSample >= minGap ? minGap : Math.max(1, Math.round(1e-3 * SAMPLE_RATE$1));
    const maxEnd = Math.max(start + 1, nextStart - gap);
    const ceiling = Math.max(cue.endSample, start + maxCue);
    let end = Math.max(start + 1, Math.min(cue.endSample, maxEnd));
    end = Math.min(maxEnd, Math.min(end + tailPad, ceiling));
    end = Math.min(maxEnd, Math.max(end, Math.min(start + minCue, ceiling)));
    const chars = cue.lines.join(" ").length;
    const readEnd = start + Math.ceil(chars / MAX_CHARS_PER_SECOND * SAMPLE_RATE$1);
    end = Math.min(maxEnd, Math.max(end, Math.min(readEnd, ceiling)));
    end = Math.max(start + 1, Math.min(end, nextStart));
    const lines = cue.lines.filter((line) => line !== "");
    if (lines.length > 0 && end > start) {
      output.push({ startSample: start, endSample: end, lines });
    }
  }
  return output;
}
function buildSubtitleCues(segments2, language, durationSamples) {
  const limit = lineLimit(language);
  const cues = [];
  for (const segment2 of segments2) {
    const text = cleanText(segment2.text);
    if (text === "") continue;
    const start = Math.max(0, Math.min(segment2.startSample, segment2.endSample));
    const end = Math.max(start + 1, segment2.endSample);
    const seconds = (end - start) / SAMPLE_RATE$1;
    const durationChars = Math.max(
      1,
      Math.floor(text.length * MAX_CUE_SECONDS / Math.max(seconds, 1e-3))
    );
    const longestUnit = units(text, language).reduce(
      (longest, unit) => Math.max(longest, unit.length),
      0
    );
    const maxChars = Math.max(
      1,
      Math.min(limit * 2, Math.max(durationChars, longestUnit))
    );
    const chunks = packText(text, language, maxChars);
    if (chunks.length === 0) continue;
    const totalChars = chunks.reduce((sum, chunk) => sum + chunk.length, 0) || 1;
    const boundaries = [];
    let consumed = 0;
    for (const chunk of chunks) {
      consumed += chunk.length;
      boundaries.push(start + Math.round(consumed / totalChars * (end - start)));
    }
    boundaries[boundaries.length - 1] = end;
    const pauses = (segment2.pauseSamples ?? []).filter((sample) => sample > start && sample < end).sort((a, b) => a - b);
    const snapped = snapBoundaries(boundaries.slice(0, -1), pauses, start, end);
    let cueStart = start;
    for (let i = 0; i < chunks.length; i++) {
      const cueEnd = i < snapped.length ? snapped[i] : end;
      cues.push({
        startSample: cueStart,
        endSample: Math.max(cueStart + 1, cueEnd),
        lines: wrapText(chunks[i], language, limit)
      });
      cueStart = Math.max(cueStart + 1, cueEnd);
    }
  }
  return finalize(cues, durationSamples);
}
const TRANSCRIPT_SAMPLE_RATE = 16e3;
const STUDIO_FREE_RUNS = 2;
const STUDIO_FREE_TRANSLATIONS = 2;
const STUDIO_FREE_MAX_SECONDS = 30 * 60;
const STUDIO_PRO_MAX_SECONDS = 90 * 60;
function segmentHasTranslation(segment2) {
  return (segment2.translation ?? "").trim() !== "";
}
function translatedSegmentCount(segments2) {
  let count = 0;
  for (const segment2 of segments2) {
    if (segmentHasTranslation(segment2)) count += 1;
  }
  return count;
}
function hasTranslatedSegments(segments2) {
  return segments2.some(segmentHasTranslation);
}
function samplesToSeconds(samples) {
  return Math.max(0, samples) / TRANSCRIPT_SAMPLE_RATE;
}
function formatClock(samples) {
  const total = Math.floor(samplesToSeconds(samples));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor(total % 3600 / 60);
  const seconds = total % 60;
  return hours > 0 ? `${hours}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}` : `${minutes}:${String(seconds).padStart(2, "0")}`;
}
function timecode(samples, comma) {
  const totalMs = Math.max(0, Math.round(samplesToSeconds(samples) * 1e3));
  const hours = Math.floor(totalMs / 36e5);
  const minutes = Math.floor(totalMs % 36e5 / 6e4);
  const seconds = Math.floor(totalMs % 6e4 / 1e3);
  const ms = totalMs % 1e3;
  const separator = comma ? "," : ".";
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(
    seconds
  ).padStart(2, "0")}${separator}${String(ms).padStart(3, "0")}`;
}
function cleanLine(text) {
  return text.replace(/\s+/g, " ").trim();
}
function baseFilename(title) {
  const cleaned = title.replace(/\.[^.]+$/, "").replace(/[<>:"/\\|?*\u0000-\u001f]/g, "-").replace(/\s+/g, " ").trim();
  return cleaned.slice(0, 120) || "transcript";
}
function exportTranscript(document2, format, mode = "source") {
  const translated = mode === "translation" && document2.translationLanguage !== void 0 && hasTranslatedSegments(document2.segments);
  const language = translated ? document2.translationLanguage ?? document2.language : document2.language;
  const textFor = (segment2) => {
    const translation = segment2.translation ?? "";
    return cleanLine(
      translated && translation.trim() !== "" ? translation : segment2.text
    );
  };
  const segments2 = document2.segments.filter((segment2) => textFor(segment2) !== "").slice().sort((a, b) => a.startSample - b.startSample);
  const title = baseFilename(document2.title);
  const suffix = translated ? `.${document2.translationLanguage}` : "";
  if (format === "srt") {
    const cues = buildSubtitleCues(
      segments2.map((segment2) => ({ ...segment2, text: textFor(segment2) })),
      language,
      document2.durationSamples
    );
    const text = cues.map((cue, index) => {
      return `${index + 1}
${timecode(cue.startSample, true)} --> ${timecode(
        cue.endSample,
        true
      )}
${cue.lines.join("\n")}`;
    }).join("\n\n");
    return {
      text: text ? `${text}
` : "",
      filename: `${title}${suffix}.srt`,
      mime: "application/x-subrip;charset=utf-8"
    };
  }
  if (format === "vtt") {
    const cues = buildSubtitleCues(
      segments2.map((segment2) => ({ ...segment2, text: textFor(segment2) })),
      language,
      document2.durationSamples
    );
    const body = cues.map((cue) => {
      return `${timecode(cue.startSample, false)} --> ${timecode(
        cue.endSample,
        false
      )}
${cue.lines.join("\n")}`;
    }).join("\n\n");
    return {
      text: `WEBVTT

${body}${body ? "\n" : ""}`,
      filename: `${title}${suffix}.vtt`,
      mime: "text/vtt;charset=utf-8"
    };
  }
  if (format === "md") {
    const lines = segments2.map(
      (segment2) => `- **${formatClock(segment2.startSample)}** ${textFor(segment2)}`
    );
    return {
      text: `# ${title}

${lines.join("\n")}${lines.length > 0 ? "\n" : ""}`,
      filename: `${title}${suffix}.md`,
      mime: "text/markdown;charset=utf-8"
    };
  }
  return {
    text: `${segments2.map(textFor).join("\n")}${segments2.length > 0 ? "\n" : ""}`,
    filename: `${title}${suffix}.txt`,
    mime: "text/plain;charset=utf-8"
  };
}
function transcriptPlainText(document2, mode = "source") {
  return exportTranscript(document2, "txt", mode).text;
}
const CHUNK_SECONDS = 30;
const SAMPLE_RATE = TRANSCRIPT_SAMPLE_RATE;
class TranscriptionCancelledError extends Error {
  constructor() {
    super("Transcription cancelled.");
    this.name = "TranscriptionCancelledError";
  }
}
function createStudioEngine(candidate, settings2, language) {
  const config = engineConfig(
    candidate.id,
    { ...settings2, language },
    { qwenModel: candidate.qwenModel }
  );
  return {
    engine: new GpuAsrEngine(candidate.id, () => config),
    label: config.label
  };
}
class BatchTranscriber {
  constructor(createEngine = createStudioEngine) {
    this.createEngine = createEngine;
  }
  engine = null;
  cancelled = false;
  async transcribe(samples, settings2, language, callbacks, options = {}) {
    if (this.cancelled) throw new TranscriptionCancelledError();
    const order = studioEngineOrder(
      language,
      options.preferSmallModel,
      options.preferredEngine
    );
    if (order.length === 0) {
      throw new Error(`No on-device engine supports ${language}.`);
    }
    let lastError = null;
    for (const [index, candidate] of order.entries()) {
      if (this.cancelled) throw new TranscriptionCancelledError();
      const { engine, label } = this.createEngine(candidate, settings2, language);
      callbacks.onStatus(`Loading ${label}…`);
      callbacks.onProgress(null);
      this.engine = engine;
      let producedOutput = false;
      let engineError = null;
      try {
        await engine.initializeBatch({
          settings: {
            ...settings2,
            language,
            ...candidate.qwenModel ? { qwenModel: candidate.qwenModel } : {}
          },
          events: {
            onStatus: (status, detail) => {
              if (status === "loading") callbacks.onStatus(detail ?? `Preparing ${label}…`);
            },
            onProgress: (progress) => callbacks.onProgress(progress),
            onCaption: (event) => {
              producedOutput = true;
              callbacks.onCaption(event);
            },
            onError: (error) => {
              engineError = error;
              if (this.engine === engine) {
                this.engine = null;
                void engine.dispose();
              }
            },
            onLog: (message) => callbacks.onLog?.(message)
          }
        });
        if (this.cancelled) throw new TranscriptionCancelledError();
        callbacks.onEngine?.(label);
        callbacks.onStatus("Transcribing…");
        callbacks.onProgress(null);
        callbacks.onChunk?.(0);
        const chunkSamples = CHUNK_SECONDS * SAMPLE_RATE;
        let sent = 0;
        let processedSamples = 0;
        while (sent < samples.length) {
          if (this.cancelled) throw new TranscriptionCancelledError();
          const end = Math.min(samples.length, sent + chunkSamples);
          engine.pushBatchAudio(samples.slice(sent, end), SAMPLE_RATE);
          processedSamples = await engine.flushBatch();
          if (this.cancelled) throw new TranscriptionCancelledError();
          if (engineError !== null) throw engineError;
          const tolerance = 4096;
          if (processedSamples < end - tolerance) {
            throw new Error("The engine did not process all audio in this chunk.");
          }
          sent = end;
          callbacks.onChunk?.(sent / samples.length);
          callbacks.onStatus(`Transcribing… ${Math.round(sent / samples.length * 100)}%`);
        }
        if (this.cancelled) throw new TranscriptionCancelledError();
        callbacks.onStatus("Finishing the last lines…");
        await engine.stop();
        if (this.cancelled) throw new TranscriptionCancelledError();
        if (engineError !== null) throw engineError;
        return { engine: label, processedSamples };
      } catch (error) {
        if (this.cancelled) throw new TranscriptionCancelledError();
        const failure = engineError ?? error;
        if (engineError === null && failure instanceof TranscriptionCancelledError) {
          throw new TranscriptionCancelledError();
        }
        lastError = failure;
        callbacks.onLog?.(
          `${label} could not finish (${errorMessage(failure)}).${index === order.length - 1 || producedOutput ? "" : " Trying the next engine…"}`
        );
        if (producedOutput) throw failure;
      } finally {
        this.engine = null;
        await engine.dispose();
      }
    }
    throw new Error(
      `No file transcription engine could process this file.${lastError ? ` ${errorMessage(lastError)}` : ""}`
    );
  }
  async cancel() {
    this.cancelled = true;
    const engine = this.engine;
    this.engine = null;
    await engine?.dispose();
  }
}
function resampleTo16k(samples, inputRate) {
  if (inputRate === 16e3 || samples.length === 0) return samples;
  const ratio = inputRate / 16e3;
  const length = Math.floor(samples.length / ratio);
  const output = new Float32Array(length);
  if (Number.isInteger(ratio)) {
    for (let i = 0; i < length; i++) {
      let sum = 0;
      const start = i * ratio;
      for (let j = 0; j < ratio; j++) sum += samples[start + j] ?? 0;
      output[i] = sum / ratio;
    }
    return output;
  }
  for (let i = 0; i < length; i++) {
    const position = i * ratio;
    const index = Math.floor(position);
    const fraction = position - index;
    const a = samples[index] ?? 0;
    const b = samples[index + 1] ?? a;
    output[i] = a + (b - a) * fraction;
  }
  return output;
}
const STUDIO_MAX_FILE_BYTES = 1024 * 1024 * 1024;
const MAX_PRO_SAMPLES = STUDIO_PRO_MAX_SECONDS * TRANSCRIPT_SAMPLE_RATE + TRANSCRIPT_SAMPLE_RATE;
const STUDIO_FILE_EXTENSIONS = [
  "mp3",
  "m4a",
  "aac",
  "wav",
  "ogg",
  "oga",
  "opus",
  "flac"
];
const STUDIO_VIDEO_EXTENSIONS = ["mp4", "m4v", "mov", "webm"];
const STUDIO_VIDEO_MIME_TYPES = /* @__PURE__ */ new Set([
  "video/mp4",
  "video/x-m4v",
  "video/quicktime",
  "video/webm"
]);
const STUDIO_FORMAT_LIST = "MP3, M4A, AAC, WAV, OGG, Opus, FLAC, MP4, M4V, MOV or WebM";
const STUDIO_ACCEPT = [...STUDIO_FILE_EXTENSIONS, ...STUDIO_VIDEO_EXTENSIONS].map((extension) => `.${extension}`).join(",");
function abortError() {
  return new DOMException("File decoding was cancelled.", "AbortError");
}
function throwIfAborted(signal) {
  if (signal?.aborted) throw abortError();
}
function abortable(promise, signal) {
  if (!signal) return promise;
  if (signal.aborted) return Promise.reject(abortError());
  return new Promise((resolve, reject) => {
    const onAbort = () => reject(abortError());
    signal.addEventListener("abort", onAbort, { once: true });
    promise.then(
      (value) => {
        signal.removeEventListener("abort", onAbort);
        resolve(value);
      },
      (error) => {
        signal.removeEventListener("abort", onAbort);
        reject(error);
      }
    );
  });
}
function isStudioFile(file) {
  const lower = file.name.toLowerCase();
  return file.type.startsWith("audio/") || STUDIO_VIDEO_MIME_TYPES.has(file.type) || STUDIO_FILE_EXTENSIONS.some((extension) => lower.endsWith(`.${extension}`)) || STUDIO_VIDEO_EXTENSIONS.some((extension) => lower.endsWith(`.${extension}`));
}
function probeDuration(file, signal) {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(file);
    const audio = document.createElement("audio");
    let settled = false;
    const finish = (duration) => {
      if (settled) return;
      settled = true;
      signal?.removeEventListener("abort", onAbort);
      audio.removeAttribute("src");
      URL.revokeObjectURL(url);
      window.clearTimeout(timer);
      resolve(duration);
    };
    const onAbort = () => finish(null);
    const timer = window.setTimeout(() => finish(null), 8e3);
    audio.preload = "metadata";
    audio.addEventListener(
      "loadedmetadata",
      () => finish(Number.isFinite(audio.duration) ? audio.duration : null),
      { once: true }
    );
    audio.addEventListener("error", () => finish(null), { once: true });
    signal?.addEventListener("abort", onAbort, { once: true });
    if (signal?.aborted) {
      finish(null);
      return;
    }
    audio.src = url;
  });
}
function downmix(buffer) {
  const channels = [];
  for (let channel = 0; channel < buffer.numberOfChannels; channel++) {
    channels.push(buffer.getChannelData(channel));
  }
  return mixToMono(channels);
}
function mixToMono(channels) {
  if (channels.length === 0) return new Float32Array(0);
  if (channels.length === 1) return channels[0];
  const length = channels[0].length;
  if (channels.length === 6 || channels.length === 8) {
    const center = channels[2];
    let centerEnergy = 0;
    for (let i = 0; i < length; i++) centerEnergy += center[i] * center[i];
    const centerRms = Math.sqrt(centerEnergy / Math.max(1, length));
    if (centerRms >= 1e-4) {
      const left = channels[0];
      const right = channels[1];
      const output2 = new Float32Array(length);
      for (let i = 0; i < length; i++) {
        output2[i] = center[i] * 0.8 + (left[i] + right[i]) * 0.1;
      }
      return output2;
    }
  }
  const output = new Float32Array(length);
  for (const channel of channels) {
    for (let i = 0; i < length; i++) output[i] += channel[i];
  }
  for (let i = 0; i < length; i++) output[i] /= channels.length;
  return output;
}
async function decodeStudioFile(file, maxDurationSeconds, options = {}) {
  const { signal, durationSeconds } = options;
  throwIfAborted(signal);
  if (!isStudioFile(file)) {
    throw new Error(`Choose an audio or video file: ${STUDIO_FORMAT_LIST}.`);
  }
  if (file.size > STUDIO_MAX_FILE_BYTES) {
    throw new Error("This file is larger than 1 GB. Choose a smaller file or trim the video.");
  }
  const probed = durationSeconds !== void 0 ? durationSeconds : await probeDuration(file, signal);
  throwIfAborted(signal);
  if (probed !== null && probed > maxDurationSeconds + 1) {
    throw new Error(
      `This file is ${Math.ceil(probed / 60)} minutes long. The current limit is ${Math.floor(
        maxDurationSeconds / 60
      )} minutes.`
    );
  }
  const context = new AudioContext({ sampleRate: TRANSCRIPT_SAMPLE_RATE });
  const closeOnAbort = () => {
    void context.close().catch(() => {
    });
  };
  signal?.addEventListener("abort", closeOnAbort, { once: true });
  try {
    let buffer;
    try {
      const bytes = await abortable(file.arrayBuffer(), signal);
      throwIfAborted(signal);
      buffer = await abortable(context.decodeAudioData(bytes), signal);
    } catch {
      if (signal?.aborted) throw abortError();
      throw new Error(
        "Chrome couldn't decode the audio in this file. Try MP4, MOV or WebM video, or MP3, M4A, WAV, OGG, Opus or FLAC audio."
      );
    }
    if (!buffer) {
      throw new Error(
        "Chrome couldn't decode the audio in this file. Try MP4, MOV or WebM video, or MP3, M4A, WAV, OGG, Opus or FLAC audio."
      );
    }
    if (buffer.duration > maxDurationSeconds + 1) {
      throw new Error(
        `This file is ${Math.ceil(buffer.duration / 60)} minutes long. The current limit is ${Math.floor(
          maxDurationSeconds / 60
        )} minutes.`
      );
    }
    const mono = downmix(buffer);
    const resampled = context.sampleRate === TRANSCRIPT_SAMPLE_RATE ? mono : resampleTo16k(mono, context.sampleRate);
    if (resampled.length > MAX_PRO_SAMPLES) {
      throw new Error("This file is longer than the 90-minute Studio limit.");
    }
    throwIfAborted(signal);
    return { samples: resampled };
  } finally {
    signal?.removeEventListener("abort", closeOnAbort);
    await context.close().catch(() => {
    });
  }
}
function createFreeQuota(storageKey, limit) {
  const normalize = (value) => {
    if (typeof value !== "number" || !Number.isFinite(value)) return 0;
    return Math.min(limit, Math.max(0, Math.floor(value)));
  };
  const read = async () => {
    try {
      const stored = await chrome.storage.local.get(storageKey);
      return normalize(stored[storageKey]);
    } catch {
      return 0;
    }
  };
  return {
    normalize,
    left: (used) => limit - normalize(used),
    read,
    consume: async () => {
      const used = Math.min(limit, await read() + 1);
      try {
        await chrome.storage.local.set({ [storageKey]: used });
      } catch {
      }
      return used;
    }
  };
}
const runs = createFreeQuota("studioFreeRunsUsed", STUDIO_FREE_RUNS);
const translations = createFreeQuota(
  "studioFreeTranslationsUsed",
  STUDIO_FREE_TRANSLATIONS
);
const freeRunsLeft = runs.left;
const readUsedFreeRuns = runs.read;
const consumeFreeRun = runs.consume;
const freeTranslationsLeft = translations.left;
const readUsedFreeTranslations = translations.read;
const consumeFreeTranslation = translations.consume;
const DEFAULT_DELAY_MS = 600;
class HistorySaveQueue {
  constructor(options) {
    this.options = options;
  }
  timer = null;
  pending = null;
  failed = null;
  tail = Promise.resolve();
  /** Id of the document whose last write failed, if any. */
  get failedDocumentId() {
    return this.failed?.id ?? null;
  }
  schedule(document2) {
    this.pending = document2;
    this.clearTimer();
    this.timer = setTimeout(() => {
      this.timer = null;
      const pending = this.pending;
      this.pending = null;
      if (pending) void this.enqueue(pending);
    }, this.options.delayMs ?? DEFAULT_DELAY_MS);
  }
  /** Writes any debounced edit now and waits for every earlier save. */
  flush() {
    this.clearTimer();
    const pending = this.pending;
    this.pending = null;
    if (pending) return this.enqueue(pending);
    return this.tail.then(() => this.failed === null);
  }
  /** Writes immediately, used for the first save of a new transcript. */
  saveNow(document2) {
    this.discard(document2);
    return this.enqueue(document2);
  }
  /** Retries the document whose last write failed. */
  retry() {
    const failed = this.failed;
    if (!failed) return Promise.resolve(true);
    return this.enqueue(failed);
  }
  /**
   * Drops pending or failed work for a document, e.g. before deleting it.
   * Documents are compared by id: the sidebar passes a clone, not the object
   * the queue is holding.
   */
  discard(document2) {
    if (this.pending?.id === document2.id) {
      this.pending = null;
      this.clearTimer();
    }
    if (this.failed?.id === document2.id) this.failed = null;
  }
  /** Resolves when every write already handed to IndexedDB has settled. */
  idle() {
    return this.tail;
  }
  enqueue(document2) {
    const task = this.tail.then(async () => {
      try {
        await this.options.save(document2);
        if (this.failed?.id === document2.id) this.failed = null;
        this.options.onResult?.({ ok: true }, document2);
        return true;
      } catch (error) {
        this.failed = document2;
        this.options.onResult?.({ ok: false, error }, document2);
        return false;
      }
    });
    this.tail = task.then(() => {
    });
    return task;
  }
  clearTimer() {
    if (this.timer === null) return;
    clearTimeout(this.timer);
    this.timer = null;
  }
}
const HISTORY_DATE = new Intl.DateTimeFormat(void 0, {
  month: "short",
  day: "numeric"
});
class HistoryView {
  constructor(list, locked, options) {
    this.list = list;
    this.locked = locked;
    this.options = options;
  }
  showLocked() {
    this.list.replaceChildren();
    setHidden(this.list, true);
    setHidden(this.locked, false);
  }
  /** Shows the list before an async load, without a stale previous result. */
  begin() {
    setHidden(this.locked, true);
    setHidden(this.list, false);
    this.list.replaceChildren();
  }
  render(documents) {
    this.begin();
    if (documents.length === 0) {
      const empty = document.createElement("p");
      empty.className = "history-empty";
      empty.textContent = "Finished transcripts will appear here.";
      this.list.append(empty);
      return;
    }
    for (const transcript of documents) {
      this.list.append(this.renderEntry(transcript));
    }
  }
  renderEntry(transcript) {
    const item = document.createElement("div");
    item.className = "history-item";
    const open = document.createElement("button");
    open.type = "button";
    open.className = "history-open";
    const title = document.createElement("strong");
    title.textContent = transcript.title;
    const meta = document.createElement("span");
    const translated = transcript.translationLanguage !== void 0 && hasTranslatedSegments(transcript.segments) ? ` · ${translationLanguageName(transcript.translationLanguage)}` : "";
    meta.textContent = `${HISTORY_DATE.format(new Date(transcript.createdAt))} · ${transcript.segments.length} lines${translated}`;
    open.append(title, meta);
    open.addEventListener("click", () => this.options.onOpen(transcript));
    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "history-delete";
    remove.textContent = "×";
    remove.title = "Delete transcript";
    remove.setAttribute("aria-label", `Delete ${transcript.title}`);
    remove.addEventListener("click", () => this.options.onDelete(transcript));
    item.append(open, remove);
    return item;
  }
}
const LOST_MESSAGE = "Studio lost its session lock. Processing was stopped to avoid overloading the GPU.";
class StudioLease {
  constructor(onLost) {
    this.onLost = onLost;
  }
  ownerValue = crypto.randomUUID();
  timer = null;
  held = false;
  /** Invalidates a heartbeat response that belongs to a finished session. */
  generation = 0;
  get owner() {
    return this.ownerValue;
  }
  /**
   * Use the tab id as the owner so reloading Studio can reclaim its own lease.
   * A second tab (or a duplicated tab) still has a different id.
   */
  adoptTabOwner(tabId) {
    if (this.held) return;
    this.ownerValue = `studio-tab-${tabId}`;
  }
  /** Takes the lease and starts heartbeats. Throws with a user-facing reason. */
  async acquire() {
    const reply = await this.send({ type: "studio:acquire", owner: this.owner });
    if (reply?.ok !== true) {
      throw new Error(
        reply?.error ?? (reply?.reason === "live" ? "Live captions are running. Stop them before opening Studio." : reply?.reason === "studio" ? "Another Studio tab is already processing a file." : "Studio is unavailable right now.")
      );
    }
    this.held = true;
    const generation = ++this.generation;
    this.startHeartbeat(generation);
    return reply.entitlement;
  }
  release() {
    this.held = false;
    this.generation += 1;
    this.stopHeartbeat();
    void this.send({ type: "studio:release", owner: this.owner }).catch(() => {
    });
  }
  startHeartbeat(generation) {
    this.stopHeartbeat();
    this.timer = window.setInterval(() => {
      if (!this.held || generation !== this.generation) return;
      void this.send({ type: "studio:heartbeat", owner: this.owner }).then((reply) => {
        if (!this.held || generation !== this.generation || reply?.ok !== false) return;
        if (reply.reason === "retry") return;
        this.held = false;
        this.generation += 1;
        this.stopHeartbeat();
        this.onLost(LOST_MESSAGE);
      }).catch(() => {
      });
    }, STUDIO_LEASE_HEARTBEAT_MS);
  }
  stopHeartbeat() {
    if (this.timer === null) return;
    window.clearInterval(this.timer);
    this.timer = null;
  }
  send(request) {
    return chrome.runtime.sendMessage(request);
  }
}
const TRANSLATION_CONTEXT_PREVIOUS = 2;
const TRANSLATION_CONTEXT_NEXT = 1;
const TRANSLATION_CONTEXT_MAX_CHARS = 600;
function clean(value) {
  return value?.replace(/\s+/g, " ").trim() ?? "";
}
function rowBlock(row) {
  const source = clean(row.text);
  if (source === "") return null;
  const translation = clean(row.translation);
  return translation === "" ? `Source: ${source}` : `Source: ${source}
Translation: ${translation}`;
}
function buildTranslationContext(rows, index, maxChars = TRANSLATION_CONTEXT_MAX_CHARS) {
  if (index < 0 || index >= rows.length) return "";
  const previous = [];
  for (let i = index - 1; i >= 0 && previous.length < TRANSLATION_CONTEXT_PREVIOUS; i--) {
    const block = rowBlock(rows[i]);
    if (block !== null) previous.unshift(`Previous line:
${block}`);
  }
  const next = [];
  for (let i = index + 1; i < rows.length && next.length < TRANSLATION_CONTEXT_NEXT; i++) {
    const block = rowBlock(rows[i]);
    if (block !== null) next.push(`Next line:
${block}`);
  }
  const blocks = [...previous, ...next];
  let context = blocks.join("\n\n");
  while (context.length > maxChars && blocks.length > 1) {
    blocks.shift();
    context = blocks.join("\n\n");
  }
  if (context.length <= maxChars) return context;
  const clipped = context.slice(0, maxChars);
  const lastSpace = clipped.lastIndexOf(" ");
  return (lastSpace > 0 ? clipped.slice(0, lastSpace) : clipped).trimEnd();
}
class StudioTranslator {
  constructor(createProvider = createTranslationProvider) {
    this.createProvider = createProvider;
  }
  provider = null;
  cancelled = false;
  /** Starts a new pass; call before the async lease/model setup. */
  begin() {
    this.cancelled = false;
  }
  get isCancelled() {
    return this.cancelled;
  }
  cancel() {
    this.cancelled = true;
    this.provider?.dispose();
  }
  async run(options) {
    const targets = options.indices.filter((index) => {
      const row = options.rows[index];
      return row !== void 0 && row.text.trim() !== "";
    });
    if (this.cancelled) {
      return { completed: 0, total: targets.length, cancelled: true };
    }
    if (targets.length === 0) {
      return { completed: 0, total: 0, cancelled: false };
    }
    const provider = this.createProvider(options.providerId);
    this.provider = provider;
    const total = targets.length;
    let completed = 0;
    try {
      try {
        await provider.initialize({
          sourceLanguage: options.sourceLanguage,
          targetLanguage: options.targetLanguage,
          onProgress: (progress) => options.callbacks?.onProviderProgress?.(progress)
        });
      } catch (error) {
        if (this.cancelled) return { completed, total, cancelled: true };
        throw error;
      }
      if (this.cancelled) return { completed, total, cancelled: true };
      for (const index of targets) {
        if (this.cancelled) break;
        const row = options.rows[index];
        options.callbacks?.onStart?.(index);
        const context = buildTranslationContext(options.rows, index);
        let translation;
        try {
          translation = await provider.translate(row.text, void 0, context);
        } catch (error) {
          if (this.cancelled) break;
          throw error;
        }
        if (this.cancelled) break;
        const cleaned = translation.replace(/\s+/g, " ").trim();
        if (cleaned === "") {
          throw new Error("The translation model returned an empty line.");
        }
        row.translation = cleaned;
        options.callbacks?.onLine?.(index, cleaned);
        completed += 1;
        options.callbacks?.onProgress?.(completed, total);
      }
      return { completed, total, cancelled: this.cancelled };
    } finally {
      this.provider = null;
      provider.dispose();
    }
  }
}
class TranscriptView {
  constructor(list, empty, options) {
    this.list = list;
    this.empty = empty;
    this.options = options;
  }
  rows = /* @__PURE__ */ new Map();
  editingEnabled = true;
  clear() {
    this.rows.clear();
    this.list.replaceChildren();
    setHidden(this.empty, true);
  }
  /** Replaces the list; used when opening a saved transcript. */
  render(segments2) {
    this.clear();
    for (const segment2 of segments2) this.upsert(segment2);
    setHidden(this.empty, segments2.length > 0);
  }
  /**
   * Finishes a streamed transcript without rebuilding rows whose order did not
   * change, preserving focus, undo history, and scroll position.
   */
  finish(segments2) {
    const sameOrder = segments2.length === this.rows.size && segments2.every((segment2, index) => {
      const row = this.rows.get(segment2.id);
      return row !== void 0 && this.list.children[index] === row.item;
    });
    if (sameOrder) {
      setHidden(this.empty, segments2.length > 0);
      return;
    }
    this.render(segments2);
  }
  /** Adds or updates one line while transcription streams in. */
  upsert(segment2) {
    const existing = this.rows.get(segment2.id);
    if (existing) {
      existing.segment = segment2;
      existing.time.textContent = formatClock(segment2.startSample);
      existing.time.disabled = !this.options.canSeek();
      if (existing.text.value !== segment2.text) {
        existing.text.value = segment2.text;
        this.autoHeight(existing.text);
      }
      const nextTranslation = segment2.translation ?? "";
      if (document.activeElement !== existing.translation && existing.translation.value !== nextTranslation) {
        existing.translation.value = nextTranslation;
        existing.translation.hidden = nextTranslation.trim() === "";
        if (!existing.translation.hidden) this.autoHeight(existing.translation);
      }
      return;
    }
    this.rows.set(segment2.id, this.createRow(segment2));
    setHidden(this.empty, true);
  }
  selectedIds() {
    const selected = [];
    for (const row of this.rows.values()) {
      if (row.check.checked) selected.push(row.segment.id);
    }
    return selected;
  }
  selectionCount() {
    let count = 0;
    for (const row of this.rows.values()) if (row.check.checked) count += 1;
    return count;
  }
  setAllSelected(selected) {
    for (const row of this.rows.values()) {
      row.check.checked = selected;
      row.item.classList.toggle("is-selected", selected);
    }
    this.options.onSelectionChange();
  }
  setSelectionEnabled(enabled) {
    for (const row of this.rows.values()) row.check.disabled = !enabled;
  }
  /** Freezes text editing while a translation pass owns the document. */
  setEditingEnabled(enabled) {
    this.editingEnabled = enabled;
    for (const row of this.rows.values()) {
      row.text.disabled = !enabled;
      row.translation.disabled = !enabled;
    }
  }
  /** Marks the row currently waiting for the translation model. */
  setTranslating(id, translating) {
    const row = this.rows.get(id);
    if (!row) return;
    row.item.classList.toggle("is-translating", translating);
    row.item.setAttribute("aria-busy", translating ? "true" : "false");
  }
  createRow(segment2) {
    const item = document.createElement("li");
    item.className = "segment";
    const check = document.createElement("input");
    check.type = "checkbox";
    check.className = "segment-select";
    check.setAttribute("aria-label", `Select transcript at ${formatClock(segment2.startSample)}`);
    check.addEventListener("change", () => {
      item.classList.toggle("is-selected", check.checked);
      this.options.onSelectionChange();
    });
    const time = document.createElement("button");
    time.type = "button";
    time.className = "segment-time";
    time.textContent = formatClock(segment2.startSample);
    time.disabled = !this.options.canSeek();
    time.title = this.options.canSeek() ? "Play from this line" : "History keeps text and timings; the original audio is not stored";
    const body = document.createElement("div");
    body.className = "segment-body";
    const text = document.createElement("textarea");
    text.className = "segment-text";
    text.value = segment2.text;
    text.rows = 1;
    text.disabled = !this.editingEnabled;
    text.setAttribute("aria-label", `Transcript at ${formatClock(segment2.startSample)}`);
    text.addEventListener("input", () => {
      segment2.text = text.value;
      this.autoHeight(text);
      this.options.onEdit();
    });
    text.addEventListener("focus", () => this.autoHeight(text));
    text.addEventListener("change", () => this.options.onCommit());
    const translation = document.createElement("textarea");
    translation.className = "segment-translation";
    translation.value = segment2.translation ?? "";
    translation.hidden = translation.value.trim() === "";
    translation.rows = 1;
    translation.dir = "auto";
    translation.disabled = !this.editingEnabled;
    translation.setAttribute(
      "aria-label",
      `Translation at ${formatClock(segment2.startSample)}`
    );
    translation.addEventListener("input", () => {
      segment2.translation = translation.value.trim() === "" ? void 0 : translation.value;
      this.autoHeight(translation);
      this.options.onEdit();
    });
    translation.addEventListener("focus", () => this.autoHeight(translation));
    translation.addEventListener("blur", () => {
      if (translation.value.trim() === "") {
        segment2.translation = void 0;
        translation.hidden = true;
      }
      this.options.onCommit();
    });
    const row = { item, check, time, text, translation, segment: segment2 };
    time.addEventListener("click", () => this.options.onSeek(row.segment.startSample));
    body.append(text, translation);
    item.append(check, time, body);
    this.list.append(item);
    requestAnimationFrame(() => {
      this.autoHeight(text);
      if (!translation.hidden) this.autoHeight(translation);
    });
    return row;
  }
  autoHeight(textarea) {
    textarea.style.height = "auto";
    textarea.style.height = `${textarea.scrollHeight}px`;
  }
}
const DB_NAME = "brevier-studio";
const DB_VERSION = 1;
const STORE = "transcripts";
const HISTORY_LIMIT = 50;
let database = null;
function openDatabase() {
  if (database) return database;
  const opening = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains(STORE)) {
        const store = db.createObjectStore(STORE, { keyPath: "id" });
        store.createIndex("createdAt", "createdAt");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Could not open transcript history."));
  });
  database = opening.catch((error) => {
    database = null;
    throw error;
  });
  return database;
}
function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error ?? new Error("Transcript history request failed."));
  });
}
function transactionDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error ?? new Error("Transcript history write failed."));
    transaction.onabort = () => reject(transaction.error ?? new Error("Transcript history write was cancelled."));
  });
}
async function trimHistory(db) {
  const read = db.transaction(STORE, "readonly");
  const store = read.objectStore(STORE);
  const count = await requestResult(store.count());
  if (count <= HISTORY_LIMIT) return;
  const index = db.transaction(STORE, "readonly").objectStore(STORE).index("createdAt");
  const keys = await requestResult(index.getAllKeys(null, count - HISTORY_LIMIT));
  if (keys.length === 0) return;
  const cleanup = db.transaction(STORE, "readwrite");
  const cleanupStore = cleanup.objectStore(STORE);
  for (const key of keys) cleanupStore.delete(key);
  await transactionDone(cleanup);
}
async function saveTranscript(document2) {
  const db = await openDatabase();
  const transaction = db.transaction(STORE, "readwrite");
  transaction.objectStore(STORE).put(document2);
  await transactionDone(transaction);
  await trimHistory(db).catch((error) => {
    console.warn("[brevier studio] could not trim transcript history", error);
  });
}
async function listTranscripts() {
  const db = await openDatabase();
  const transaction = db.transaction(STORE, "readonly");
  const values = await requestResult(
    transaction.objectStore(STORE).getAll()
  );
  return values.sort((a, b) => b.createdAt - a.createdAt);
}
async function getTranscript(id) {
  const db = await openDatabase();
  const transaction = db.transaction(STORE, "readonly");
  const value = await requestResult(
    transaction.objectStore(STORE).get(id)
  );
  return value ?? null;
}
async function deleteTranscript(id) {
  const db = await openDatabase();
  const transaction = db.transaction(STORE, "readwrite");
  transaction.objectStore(STORE).delete(id);
  await transactionDone(transaction);
}
const ui = {
  accessBadge: element("accessBadge"),
  upgradeButton: element("upgradeButton"),
  dropZone: element("dropZone"),
  pickFile: element("pickFile"),
  pasteTextButton: element("pasteTextButton"),
  fileInput: element("fileInput"),
  textPanel: element("textPanel"),
  textPanelClose: element("textPanelClose"),
  textSource: element("textSource"),
  textTarget: element("textTarget"),
  textProvider: element("textProvider"),
  textInput: element("textInput"),
  textOutput: element("textOutput"),
  textTranslate: element("textTranslate"),
  textCancel: element("textCancel"),
  textCopy: element("textCopy"),
  textDownload: element("textDownload"),
  textStatus: element("textStatus"),
  textHint: element("textHint"),
  textProgress: element("textProgress"),
  textProgressLabel: element("textProgressLabel"),
  textProgressPercent: element("textProgressPercent"),
  textProgressBar: element("textProgressBar"),
  fileCard: element("fileCard"),
  fileName: element("fileName"),
  fileDetails: element("fileDetails"),
  replaceFile: element("replaceFile"),
  player: element("player"),
  language: element("language"),
  studioModel: element("studioModel"),
  deviceHint: element("deviceHint"),
  limitNote: element("limitNote"),
  startButton: element("startButton"),
  cancelButton: element("cancelButton"),
  upgradeInline: element("upgradeInline"),
  progressBox: element("progressBox"),
  progressLabel: element("progressLabel"),
  progressPercent: element("progressPercent"),
  progressBar: element("progressBar"),
  statusText: element("statusText"),
  errorBox: element("errorBox"),
  errorText: element("errorText"),
  paywall: element("paywall"),
  upgradeMonthly: element("upgradeMonthly"),
  upgradeYearly: element("upgradeYearly"),
  paywallNote: element("paywallNote"),
  transcriptSection: element("transcriptSection"),
  transcriptHeading: element("transcriptHeading"),
  transcriptMeta: element("transcriptMeta"),
  newFileButton: element("newFileButton"),
  retrySaveButton: element("retrySaveButton"),
  exportModeWrap: element("exportModeWrap"),
  exportMode: element("exportMode"),
  copyButton: element("copyButton"),
  exportTxt: element("exportTxt"),
  exportMd: element("exportMd"),
  exportSrt: element("exportSrt"),
  exportVtt: element("exportVtt"),
  translationBar: element("translationBar"),
  translateTarget: element("translateTarget"),
  translateProvider: element("translateProvider"),
  translateButton: element("translateButton"),
  translateCancel: element("translateCancel"),
  selectAllSegments: element("selectAllSegments"),
  translateProgress: element("translateProgress"),
  translateProgressLabel: element("translateProgressLabel"),
  translateProgressPercent: element("translateProgressPercent"),
  translateProgressBar: element("translateProgressBar"),
  translateStatus: element("translateStatus"),
  translateHint: element("translateHint"),
  segmentList: element("segments"),
  emptyTranscript: element("emptyTranscript"),
  refreshHistory: element("refreshHistory"),
  historyNote: element("historyNote"),
  historyList: element("historyList"),
  historyLocked: element("historyLocked"),
  historyUpgrade: element("historyUpgrade"),
  noticeButton: element("noticeButton"),
  diagnosticsButton: element("diagnosticsButton")
};
const STUDIO_MODEL_KEY = "studioModelChoice";
const FREE_TRANSLATIONS_EXHAUSTED = "You have used both free transcript translation passes. Studio Pro translates unlimited transcripts and text.";
let settings = DEFAULT_SETTINGS;
let entitlement = null;
let pro = false;
let gpu = false;
let selectedFile = null;
let selectedDuration = null;
let durationProbeDone = false;
let selectedObjectUrl = null;
let segments = [];
let currentDocument = null;
let transcriber = null;
let decodeController = null;
let busy = false;
let cancelRequested = false;
let historyBacked = false;
let historySaveFailed = false;
let historyRequest = 0;
let historyOpenRequest = 0;
let fileSelectionRequest = 0;
let canSeek = false;
let freeRunsUsed = 0;
let freeRunCounted = false;
let freeRunWrite = null;
let freeTranslationsUsed = 0;
let freeTranslationCounted = false;
let freeTranslationWrite = null;
let studioModelChoice = null;
let lastCaptionEnd = 0;
const translator = new StudioTranslator();
let translationBusy = false;
let translationRunKind = null;
let textTranslationResult = "";
class FreeRunsExhaustedError extends Error {
}
const transcriptView = new TranscriptView(ui.segmentList, ui.emptyTranscript, {
  canSeek: () => canSeek,
  onSeek: (samples) => seekTo(samples),
  onEdit: () => {
    scheduleHistorySave();
    updateTranscriptHeading();
  },
  onCommit: () => void flushScheduledSave(),
  onSelectionChange: () => paintTranslationControls()
});
const historyView = new HistoryView(ui.historyList, ui.historyLocked, {
  onOpen: (transcript) => void openHistory(transcript),
  onDelete: (transcript) => void deleteHistoryEntry(transcript)
});
const lease = new StudioLease((message) => {
  if (!busy && !translationBusy) return;
  showError(message);
  cancelActiveWork();
});
const historyQueue = new HistorySaveQueue({
  save: saveTranscript,
  onResult: (result, transcript) => {
    if (currentDocument?.id !== transcript.id) return;
    if (result.ok) {
      historyBacked = true;
      if (historySaveFailed) {
        historySaveFailed = false;
        clearError();
      }
      updateTranscriptHeading();
      return;
    }
    historySaveFailed = true;
    console.warn("[brevier studio] history edit was not saved", result.error);
    updateTranscriptHeading();
    showError("Could not save this transcript. Use Retry save to try again.");
  }
});
function formatBytes(bytes) {
  if (bytes >= 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  return `${Math.max(1, Math.round(bytes / 1024))} KB`;
}
function formatDuration(seconds) {
  return formatClock(seconds * TRANSCRIPT_SAMPLE_RATE);
}
function fileLimitSeconds() {
  return pro ? STUDIO_PRO_MAX_SECONDS : STUDIO_FREE_MAX_SECONDS;
}
function fileTooLong() {
  return selectedDuration !== null && selectedDuration > fileLimitSeconds() + 1;
}
function selectedLanguage() {
  return ui.language.value || settings.language;
}
function hasTranslations() {
  return hasTranslatedSegments(segments);
}
function translatedLineCount() {
  return translatedSegmentCount(segments);
}
function currentTextMode() {
  return ui.exportMode.value === "translation" && hasTranslations() ? "translation" : "source";
}
function defaultTranslationTarget(sourceLanguage) {
  const preferred = settings.translation.targetLanguage;
  if (preferred !== sourceLanguage && TRANSLATION_LANGUAGES.some((language) => language.code === preferred)) {
    return preferred;
  }
  return sourceLanguage === "en" ? "es" : "en";
}
function fillLanguageSelect(select, languages, selected) {
  const fragment = document.createDocumentFragment();
  let found = false;
  for (const language of languages) {
    const option = document.createElement("option");
    option.value = language.code;
    option.textContent = language.name;
    option.selected = language.code === selected;
    if (option.selected) found = true;
    fragment.append(option);
  }
  if (!found && selected !== "") {
    const option = document.createElement("option");
    option.value = selected;
    option.textContent = selected;
    option.selected = true;
    fragment.append(option);
  }
  select.replaceChildren(fragment);
}
function fillTargetSelect(select, sourceLanguage, selected) {
  fillLanguageSelect(select, TRANSLATION_LANGUAGES, selected);
  for (const option of select.options) option.disabled = option.value === sourceLanguage;
  if (select.value === sourceLanguage) {
    select.value = defaultTranslationTarget(sourceLanguage);
  }
}
function refreshTranscriptTarget(preferred) {
  const source = currentDocument?.language ?? selectedLanguage();
  fillTargetSelect(
    ui.translateTarget,
    source,
    preferred ?? ui.translateTarget.value ?? defaultTranslationTarget(source)
  );
}
function refreshTextTarget() {
  const source = ui.textSource.value || selectedLanguage();
  fillTargetSelect(
    ui.textTarget,
    source,
    ui.textTarget.value || defaultTranslationTarget(source)
  );
}
function selectedProvider(select) {
  return gpu && select.value === "hymt3" ? "hymt3" : "chrome";
}
function providerHint(provider) {
  return provider === "hymt3" ? "Hy-MT3 · nearby lines are used as context · first use downloads about 1.1 GB." : "Chrome built-in · one line at a time · first use may download a language pack.";
}
function showError(message) {
  ui.errorText.textContent = message;
  setHidden(ui.errorBox, false);
}
function clearError() {
  setHidden(ui.errorBox, true);
  ui.errorText.textContent = "";
}
function setStatus(message) {
  ui.statusText.textContent = message;
}
function setProgress(fraction, label) {
  setHidden(ui.progressBox, false);
  ui.progressBox.classList.toggle("indeterminate", fraction === null);
  ui.progressLabel.textContent = label;
  if (fraction === null) {
    ui.progressBar.style.width = "";
    ui.progressPercent.textContent = "";
    return;
  }
  const clamped = Math.max(0, Math.min(1, fraction));
  ui.progressBar.style.width = `${Math.round(clamped * 100)}%`;
  ui.progressPercent.textContent = `${Math.round(clamped * 100)}%`;
}
function hideProgress() {
  setHidden(ui.progressBox, true);
  ui.progressBox.classList.remove("indeterminate");
  ui.progressBar.style.width = "";
  ui.progressPercent.textContent = "";
}
function setBarProgress(box, bar, percent, fraction) {
  setHidden(box, false);
  box.classList.toggle("indeterminate", fraction === null);
  if (fraction === null) {
    bar.style.width = "";
    percent.textContent = "";
    return;
  }
  const clamped = Math.max(0, Math.min(1, fraction));
  bar.style.width = `${Math.round(clamped * 100)}%`;
  percent.textContent = `${Math.round(clamped * 100)}%`;
}
function hideBarProgress(box, bar, percent) {
  setHidden(box, true);
  box.classList.remove("indeterminate");
  bar.style.width = "";
  percent.textContent = "";
}
function setTranslationProgress(fraction, label) {
  ui.translateProgressLabel.textContent = label;
  setBarProgress(
    ui.translateProgress,
    ui.translateProgressBar,
    ui.translateProgressPercent,
    fraction
  );
}
function hideTranslationProgress() {
  hideBarProgress(
    ui.translateProgress,
    ui.translateProgressBar,
    ui.translateProgressPercent
  );
}
function setTextTranslationProgress(fraction, label) {
  ui.textProgressLabel.textContent = label;
  setBarProgress(ui.textProgress, ui.textProgressBar, ui.textProgressPercent, fraction);
}
function hideTextTranslationProgress() {
  hideBarProgress(ui.textProgress, ui.textProgressBar, ui.textProgressPercent);
}
function countFreeTranslation() {
  if (pro || freeTranslationCounted) return;
  freeTranslationCounted = true;
  freeTranslationWrite = consumeFreeTranslation().then((used) => {
    freeTranslationsUsed = used;
  }).catch((error) => {
    console.warn("[brevier studio] could not record the free translation", error);
  });
}
function freeTranslationHint(provider) {
  const left = freeTranslationsLeft(freeTranslationsUsed);
  if (pro) return providerHint(provider);
  if (left === 0) {
    return "No translation passes left · Studio Pro translates unlimited transcripts and text.";
  }
  return `${left} translation ${left === 1 ? "pass" : "passes"} left · ${providerHint(
    provider
  )}`;
}
function paintTranslationControls() {
  const hasRows = segments.length > 0;
  const busyWithTranslation = translationBusy || busy;
  const selected = transcriptView.selectionCount();
  const textActive = translationBusy || busy;
  const translationsLeft = freeTranslationsLeft(freeTranslationsUsed);
  const canTranslate = pro || translationsLeft > 0;
  const hymt3Options = [ui.translateProvider, ui.textProvider].map(
    (select) => select.querySelector('option[value="hymt3"]')
  );
  for (const option of hymt3Options) {
    if (option) option.disabled = !gpu;
  }
  if (!gpu) {
    if (ui.translateProvider.value === "hymt3") ui.translateProvider.value = "chrome";
    if (ui.textProvider.value === "hymt3") ui.textProvider.value = "chrome";
  }
  const provider = selectedProvider(ui.translateProvider);
  setHidden(ui.translationBar, !hasRows);
  ui.translateTarget.disabled = busyWithTranslation || !hasRows;
  ui.translateProvider.disabled = busyWithTranslation || !hasRows;
  ui.selectAllSegments.disabled = busyWithTranslation || !hasRows;
  ui.translateButton.disabled = busyWithTranslation || !hasRows;
  const action = selected > 0 ? `Translate ${selected} selected` : "Translate all";
  ui.translateButton.textContent = canTranslate ? action : `${action} · Pro`;
  ui.selectAllSegments.checked = hasRows && selected === segments.length;
  ui.selectAllSegments.indeterminate = selected > 0 && selected < segments.length;
  setHidden(ui.translateCancel, translationRunKind !== "transcript");
  transcriptView.setSelectionEnabled(!busyWithTranslation);
  transcriptView.setEditingEnabled(!busyWithTranslation);
  ui.translateHint.textContent = hasRows ? freeTranslationHint(provider) : "";
  ui.pasteTextButton.disabled = busyWithTranslation;
  ui.pasteTextButton.textContent = "Translate text";
  ui.pickFile.disabled = busyWithTranslation;
  ui.newFileButton.disabled = busyWithTranslation;
  const hasResult = textTranslationResult.trim() !== "";
  ui.textSource.disabled = textActive;
  ui.textTarget.disabled = textActive;
  ui.textProvider.disabled = textActive;
  ui.textInput.disabled = textActive;
  ui.textTranslate.textContent = canTranslate ? "Translate" : "Translate · Pro";
  ui.textTranslate.disabled = textActive || ui.textInput.value.trim() === "";
  ui.textHint.textContent = freeTranslationHint(selectedProvider(ui.textProvider));
  setHidden(ui.textCancel, translationRunKind !== "text");
  ui.textCopy.disabled = textActive || !hasResult;
  ui.textDownload.disabled = textActive || !hasResult;
}
function updateExportMode() {
  const language = currentDocument?.translationLanguage;
  const translated = hasTranslations() && language !== void 0;
  setHidden(ui.exportModeWrap, !translated);
  const option = ui.exportMode.querySelector(
    'option[value="translation"]'
  );
  if (option) {
    option.textContent = translated ? `${translationLanguageName(language)} translation` : "Translation";
  }
  if (!translated) ui.exportMode.value = "source";
}
function clearTranslations() {
  for (const segment2 of segments) delete segment2.translation;
  if (currentDocument) delete currentDocument.translationLanguage;
  transcriptView.render(segments);
  updateExportMode();
  updateTranscriptHeading();
  scheduleHistorySave();
}
function paintQuota() {
  const runsLeft = freeRunsLeft(freeRunsUsed);
  ui.accessBadge.textContent = pro ? "Studio Pro" : `Free · ${runsLeft} ${runsLeft === 1 ? "file" : "files"} left`;
  ui.accessBadge.classList.toggle("is-pro", pro);
  updateLimitNote();
}
function paintAccess() {
  setHidden(ui.upgradeButton, pro);
  setHidden(ui.historyNote, !pro);
  if (pro) setHidden(ui.paywall, true);
  paintQuota();
  for (const button of [ui.exportMd, ui.exportVtt]) {
    button.classList.toggle("is-unlocked", pro);
    button.title = pro ? "Export a timed transcript" : "Included with Studio Pro";
  }
  ui.paywallNote.textContent = "Live captions and translation stay free. Studio Pro is a separate upgrade.";
  updateStartState();
  updateTranscriptHeading();
  if (!pro) {
    historyRequest += 1;
    historyView.showLocked();
  }
}
function applyEntitlement(next) {
  if (next) entitlement = next;
  const nextPro = entitlement !== null && hasProAccess(entitlement);
  if (nextPro === pro) return;
  pro = nextPro;
  paintAccess();
  if (pro) void refreshHistory();
}
async function refreshEntitlement() {
  try {
    const response = await chrome.runtime.sendMessage({
      type: "popup:get-entitlement"
    });
    applyEntitlement(response?.entitlement);
  } catch {
    applyEntitlement(void 0);
  }
}
function updateLimitNote() {
  if (selectedFile === null) {
    setHidden(ui.limitNote, true);
    return;
  }
  setHidden(ui.limitNote, false);
  if (selectedDuration === null) {
    ui.limitNote.textContent = durationProbeDone ? `${formatBytes(selectedFile.size)} · duration unavailable` : `${formatBytes(selectedFile.size)} · Checking duration…`;
    return;
  }
  const length = formatDuration(selectedDuration);
  if (fileTooLong()) {
    ui.limitNote.textContent = pro ? `${length} · This is longer than the 90-minute Studio limit. Choose a shorter file.` : `${length} · Free files are limited to 30 minutes. Studio Pro accepts up to 90 minutes.`;
    return;
  }
  const left = freeRunsLeft(freeRunsUsed);
  const translations2 = freeTranslationsLeft(freeTranslationsUsed);
  if (!pro && left === 0) {
    ui.limitNote.textContent = translations2 > 0 ? `${length} · No free file transcriptions left · ${translations2} translation ${translations2 === 1 ? "pass" : "passes"} left.` : `${length} · No free file transcriptions left.`;
    return;
  }
  ui.limitNote.textContent = pro ? `${length} · Full file will be transcribed.` : `${length} · ${left} free file ${left === 1 ? "transcription" : "transcriptions"} left · ${translations2} translation ${translations2 === 1 ? "pass" : "passes"} left.`;
}
function updateStartState() {
  const tooLong = fileTooLong();
  const noFreeRuns = !pro && freeRunsLeft(freeRunsUsed) === 0;
  const locked = busy || translationBusy;
  ui.startButton.disabled = locked || selectedFile === null || tooLong || noFreeRuns;
  ui.language.disabled = locked;
  ui.studioModel.disabled = locked;
  ui.replaceFile.disabled = locked;
  ui.pasteTextButton.disabled = locked;
  setHidden(ui.startButton, busy);
  setHidden(ui.cancelButton, !busy);
  ui.cancelButton.disabled = false;
  setHidden(ui.upgradeInline, pro || busy || !tooLong && !noFreeRuns);
  ui.upgradeInline.textContent = noFreeRuns ? "Get Studio Pro" : "Unlock full files";
  if (!busy) {
    ui.startButton.textContent = noFreeRuns && selectedFile !== null ? "No free transcriptions left" : currentDocument ? "Transcribe again" : "Transcribe file";
  }
  paintTranslationControls();
}
function formatDownload(sizeMB) {
  if (sizeMB === void 0) return "first use downloads a model";
  return sizeMB >= 1e3 ? `~${(sizeMB / 1e3).toFixed(1)} GB first use` : `~${sizeMB} MB first use`;
}
function modelChoiceValue(candidate) {
  if (candidate === null) return "auto";
  return candidate.id === "qwen" ? `qwen:${candidate.qwenModel}` : candidate.id;
}
function studioModelOptions(language) {
  const options = [
    {
      value: "auto",
      label: "Auto — best for this language",
      candidate: null
    }
  ];
  for (const candidate of studioEngineOrder(language, !gpu)) {
    const config = engineConfig(
      candidate.id,
      { ...settings, language },
      { qwenModel: candidate.qwenModel }
    );
    options.push({
      value: modelChoiceValue(candidate),
      label: config.label,
      candidate
    });
  }
  return options;
}
function populateStudioModelSelect(preferredValue) {
  const options = studioModelOptions(selectedLanguage());
  const wanted = preferredValue ?? modelChoiceValue(studioModelChoice);
  const selected = options.find((option) => option.value === wanted) ?? options[0];
  const fragment = document.createDocumentFragment();
  for (const option of options) {
    const element2 = document.createElement("option");
    element2.value = option.value;
    element2.textContent = option.label;
    element2.selected = option.value === selected.value;
    fragment.append(element2);
  }
  ui.studioModel.replaceChildren(fragment);
  ui.studioModel.value = selected.value;
  studioModelChoice = selected.candidate;
  updateEngineHint();
}
async function readStoredStudioModel() {
  try {
    const stored = await chrome.storage.local.get(STUDIO_MODEL_KEY);
    return typeof stored[STUDIO_MODEL_KEY] === "string" ? stored[STUDIO_MODEL_KEY] : null;
  } catch {
    return null;
  }
}
async function rememberStudioModel(value) {
  try {
    await chrome.storage.local.set({ [STUDIO_MODEL_KEY]: value });
  } catch {
  }
}
function updateEngineHint() {
  const language = selectedLanguage();
  const candidate = studioModelChoice ?? studioEngineOrder(language, !gpu)[0];
  if (!candidate) {
    ui.deviceHint.textContent = "No compatible engine. Choose another spoken language.";
    ui.deviceHint.classList.add("warn");
    return;
  }
  const config = engineConfig(
    candidate.id,
    { ...settings, language },
    { qwenModel: candidate.qwenModel }
  );
  const download = formatDownload(gpu ? config.sizeMB : config.cpuSizeMB ?? config.sizeMB);
  const source = studioModelChoice === null ? `Auto uses ${config.label} · ` : "";
  ui.deviceHint.classList.toggle("warn", !gpu);
  ui.deviceHint.textContent = gpu ? `${source}WebGPU · ${download}` : `${source}CPU mode · ${download} · long files take time`;
}
function populateLanguages() {
  const fragment = document.createDocumentFragment();
  for (const language of SUPPORTED_LANGUAGES) {
    const option = document.createElement("option");
    option.value = language.code;
    option.textContent = language.name;
    fragment.append(option);
  }
  ui.language.replaceChildren(fragment);
  const preferred = SUPPORTED_LANGUAGES.some(
    (language) => language.code === settings.language
  ) ? settings.language : "en";
  ui.language.value = preferred;
}
function populateTranslationOptions() {
  fillLanguageSelect(ui.textSource, SUPPORTED_LANGUAGES, selectedLanguage());
  refreshTextTarget();
  refreshTranscriptTarget();
}
function setDefaultTranslationProvider() {
  const provider = gpu ? "hymt3" : "chrome";
  ui.translateProvider.value = provider;
  ui.textProvider.value = provider;
}
function releaseObjectUrl() {
  ui.player.pause();
  ui.player.removeAttribute("src");
  ui.player.load();
  setHidden(ui.player, true);
  if (selectedObjectUrl !== null) {
    URL.revokeObjectURL(selectedObjectUrl);
    selectedObjectUrl = null;
  }
}
function clearTranscriptView() {
  historyOpenRequest += 1;
  void flushScheduledSave();
  currentDocument = null;
  historyBacked = false;
  historySaveFailed = false;
  segments = [];
  translationRunKind = null;
  transcriptView.clear();
  setHidden(ui.transcriptSection, true);
  hideTranslationProgress();
  ui.translateStatus.textContent = "";
  updateExportMode();
  lastCaptionEnd = 0;
}
async function resetForNewFile() {
  if (busy || translationBusy) return;
  const request = ++fileSelectionRequest;
  if (!await flushScheduledSave()) {
    showError("Could not save the open transcript. Use Retry save before starting a new file.");
    return;
  }
  if (request !== fileSelectionRequest || busy) return;
  releaseObjectUrl();
  selectedFile = null;
  selectedDuration = null;
  durationProbeDone = false;
  clearTranscriptView();
  setHidden(ui.fileCard, true);
  setHidden(ui.dropZone, false);
  clearError();
  hideProgress();
  setStatus("");
  setHidden(ui.paywall, true);
  ui.fileInput.value = "";
  refreshTranscriptTarget();
  updateStartState();
}
async function acceptFile(file) {
  if (translationBusy) {
    showError("Finish or cancel the translation before choosing another file.");
    return;
  }
  if (busy) return;
  ui.fileInput.value = "";
  const request = ++fileSelectionRequest;
  clearError();
  if (!isStudioFile(file)) {
    showError(`Choose an audio or video file: ${STUDIO_FORMAT_LIST}.`);
    return;
  }
  if (file.size > STUDIO_MAX_FILE_BYTES) {
    showError(
      `This file is ${formatBytes(file.size)}. Studio accepts files up to ${formatBytes(
        STUDIO_MAX_FILE_BYTES
      )}.`
    );
    return;
  }
  if (!await flushScheduledSave()) {
    showError("Could not save the open transcript. Use Retry save before choosing another file.");
    return;
  }
  if (request !== fileSelectionRequest || busy) return;
  clearTranscriptView();
  releaseObjectUrl();
  setHidden(ui.textPanel, true);
  selectedFile = file;
  selectedDuration = null;
  durationProbeDone = false;
  selectedObjectUrl = URL.createObjectURL(file);
  ui.player.src = selectedObjectUrl;
  setHidden(ui.player, false);
  canSeek = true;
  refreshTranscriptTarget();
  ui.fileName.textContent = file.name;
  ui.fileDetails.textContent = `${formatBytes(file.size)} · checking duration…`;
  setHidden(ui.fileCard, false);
  setHidden(ui.dropZone, true);
  setHidden(ui.paywall, true);
  hideProgress();
  setStatus("");
  updateLimitNote();
  updateStartState();
  updateEngineHint();
  const target = file;
  void probeDuration(file).then((duration) => {
    if (selectedFile !== target) return;
    selectedDuration = duration;
    durationProbeDone = true;
    ui.fileDetails.textContent = duration === null ? `${formatBytes(file.size)} · duration unavailable` : `${formatBytes(file.size)} · ${formatDuration(duration)}`;
    updateLimitNote();
    updateStartState();
  });
}
function handleFiles(files) {
  const file = files?.[0];
  if (file) void acceptFile(file);
}
function seekTo(samples) {
  if (!canSeek || !ui.player.src) return;
  ui.player.currentTime = samplesToSeconds(samples);
  void ui.player.play().catch(() => {
  });
}
function renderSegments() {
  transcriptView.render(segments);
  updateTranscriptHeading();
}
function updateTranscriptHeading() {
  const title = currentDocument?.title ?? selectedFile?.name ?? "Transcript";
  ui.transcriptHeading.textContent = title;
  const durationSamples = currentDocument?.durationSamples;
  const duration = durationSamples !== void 0 ? ` · ${formatDuration(durationSamples / TRANSCRIPT_SAMPLE_RATE)}` : selectedDuration !== null ? ` · ${formatDuration(selectedDuration)}` : "";
  const saveFailed = currentDocument !== null && historyQueue.failedDocumentId === currentDocument.id;
  const state = !pro ? "free transcription" : saveFailed ? "not saved — retry" : historyBacked ? "saved in history" : "not saved yet";
  const translatedCount = translatedLineCount();
  const translated = currentDocument?.translationLanguage !== void 0 && translatedCount > 0 ? translatedCount === segments.length ? ` · ${translationLanguageName(currentDocument.translationLanguage)} translation` : ` · ${translatedCount} of ${segments.length} lines in ${translationLanguageName(
    currentDocument.translationLanguage
  )}` : "";
  ui.transcriptMeta.textContent = `${segments.length} ${segments.length === 1 ? "line" : "lines"}${duration}${translated} · ${state}`;
  setHidden(ui.retrySaveButton, !saveFailed);
  updateExportMode();
}
function addCaption(event) {
  if (event.kind !== "final" || !event.text.trim()) return;
  if (!pro && !freeRunCounted) {
    freeRunCounted = true;
    freeRunWrite = consumeFreeRun().then((used) => {
      freeRunsUsed = used;
      paintAccess();
    }).catch((error) => {
      console.warn("[brevier studio] could not record the free run", error);
    });
  }
  const startSample = event.startSample !== void 0 ? event.startSample : lastCaptionEnd;
  const endSample = event.endSample !== void 0 && event.endSample > startSample ? event.endSample : startSample + 2 * TRANSCRIPT_SAMPLE_RATE;
  lastCaptionEnd = endSample;
  const id = event.lineId ?? `line-${segments.length + 1}`;
  const existing = segments.findIndex((segment2) => segment2.id === id);
  const next = {
    id,
    startSample,
    endSample,
    text: event.text.trim(),
    ...event.pauseSamples && event.pauseSamples.length > 0 ? { pauseSamples: event.pauseSamples } : {}
  };
  if (existing >= 0) segments[existing] = next;
  else segments.push(next);
  transcriptView.upsert(next);
  updateTranscriptHeading();
}
function scheduleHistorySave() {
  if (!pro || currentDocument === null) return;
  currentDocument.segments = segments;
  historyQueue.schedule(currentDocument);
}
function flushScheduledSave() {
  if (!pro || currentDocument === null) return Promise.resolve(true);
  currentDocument.segments = segments;
  return historyQueue.flush();
}
async function retryHistorySave() {
  if (!pro) return;
  const saved = await historyQueue.retry();
  updateTranscriptHeading();
  if (saved) {
    historySaveFailed = false;
    clearError();
    setStatus("Transcript saved in local history.");
  }
}
function showPaywall() {
  if (pro) return;
  setHidden(ui.paywall, false);
  ui.paywall.scrollIntoView({ behavior: "smooth", block: "nearest" });
}
async function openUpgrade(plan) {
  if (pro) return;
  if (plan === void 0) {
    showPaywall();
    return;
  }
  try {
    const response = await chrome.runtime.sendMessage({
      type: "popup:open-upgrade",
      plan
    });
    if (response?.ok === false) showError(response.error ?? "Could not open the upgrade page.");
    else setStatus("Finish checkout in the new tab, then return here.");
  } catch (error) {
    showError(errorMessage(error));
  }
}
function currentDocumentOrNull() {
  if (currentDocument !== null) return currentDocument;
  if (selectedFile === null || segments.length === 0) return null;
  return {
    id: crypto.randomUUID(),
    title: selectedFile.name,
    language: selectedLanguage(),
    durationSamples: Math.round((selectedDuration ?? 0) * TRANSCRIPT_SAMPLE_RATE),
    createdAt: Date.now(),
    segments
  };
}
function promotePartialTranscript(file) {
  if (currentDocument !== null || segments.length === 0) return;
  segments.sort((a, b) => a.startSample - b.startSample);
  const document2 = {
    id: crypto.randomUUID(),
    title: file.name,
    language: selectedLanguage(),
    durationSamples: Math.max(
      lastCaptionEnd,
      Math.round((selectedDuration ?? 0) * TRANSCRIPT_SAMPLE_RATE)
    ),
    createdAt: Date.now(),
    segments
  };
  currentDocument = document2;
  transcriptView.finish(segments);
  updateTranscriptHeading();
  refreshTranscriptTarget(defaultTranslationTarget(document2.language));
  paintTranslationControls();
  if (!pro) return;
  void historyQueue.saveNow(document2).then((saved) => {
    if (!saved || currentDocument?.id !== document2.id) return;
    historyBacked = true;
    updateTranscriptHeading();
    void refreshHistory();
  });
}
async function copyTranscript() {
  const document2 = currentDocumentOrNull();
  if (!document2) return;
  try {
    await navigator.clipboard.writeText(transcriptPlainText(document2, currentTextMode()));
    ui.copyButton.textContent = "Copied";
    window.setTimeout(() => {
      ui.copyButton.textContent = "Copy";
    }, 1400);
  } catch {
    showError("Could not copy to the clipboard. Use an export instead.");
  }
}
function downloadExport(format) {
  const transcript = currentDocumentOrNull();
  if (!transcript) return;
  if (format !== "txt" && format !== "srt" && !pro) {
    showPaywall();
    return;
  }
  const result = exportTranscript(transcript, format, currentTextMode());
  const url = URL.createObjectURL(
    new Blob([result.text], {
      type: `${result.mime.replace(";charset=utf-8", "")};charset=utf-8`
    })
  );
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = result.filename;
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2e3);
}
async function deleteHistoryEntry(transcript) {
  if (translationBusy) {
    showError("Finish or cancel the translation before deleting transcripts.");
    return;
  }
  if (!window.confirm(`Delete “${transcript.title}” from this device?`)) return;
  historyOpenRequest += 1;
  const deletingCurrent = currentDocument?.id === transcript.id;
  if (deletingCurrent) {
    historyQueue.discard(transcript);
    await historyQueue.idle();
    if (translationBusy) {
      showError("Finish or cancel the translation before deleting transcripts.");
      return;
    }
    historyQueue.discard(transcript);
  }
  try {
    await deleteTranscript(transcript.id);
    if (deletingCurrent && currentDocument?.id === transcript.id) {
      historyBacked = false;
      updateTranscriptHeading();
    }
    await refreshHistory();
  } catch (error) {
    showError(errorMessage(error));
  }
}
async function openHistory(entry) {
  if (translationBusy) {
    showError("Finish or cancel the translation before switching transcripts.");
    return;
  }
  if (busy) return;
  const request = ++historyOpenRequest;
  if (!await flushScheduledSave()) {
    showError("Could not save the open transcript. Use Retry save before switching files.");
    return;
  }
  if (request !== historyOpenRequest || translationBusy) return;
  let transcript;
  try {
    transcript = await getTranscript(entry.id);
  } catch (error) {
    if (request === historyOpenRequest) showError(errorMessage(error));
    return;
  }
  if (request !== historyOpenRequest || translationBusy) return;
  if (transcript === null) {
    showError("That transcript was deleted. Refresh the history list and try again.");
    await refreshHistory();
    return;
  }
  currentDocument = transcript;
  historyBacked = true;
  historySaveFailed = false;
  segments = transcript.segments;
  canSeek = false;
  ui.player.pause();
  setHidden(ui.fileCard, true);
  setHidden(ui.dropZone, true);
  setHidden(ui.transcriptSection, false);
  setHidden(ui.paywall, true);
  clearError();
  hideProgress();
  setStatus(
    `Opened from history · ${formatDuration(
      transcript.durationSamples / TRANSCRIPT_SAMPLE_RATE
    )}. Text and timings are kept; the original audio is not stored.`
  );
  lastCaptionEnd = 0;
  ui.translateStatus.textContent = "";
  hideTranslationProgress();
  renderSegments();
  refreshTranscriptTarget(
    transcript.translationLanguage ?? defaultTranslationTarget(transcript.language)
  );
  paintTranslationControls();
  updateStartState();
}
async function refreshHistory() {
  if (!pro) return;
  const request = ++historyRequest;
  historyView.begin();
  try {
    const documents = await listTranscripts();
    if (request !== historyRequest || !pro) return;
    historyView.render(documents);
  } catch (error) {
    if (request === historyRequest) showError(errorMessage(error));
  }
}
async function startTranscription() {
  if (busy || translationBusy || selectedFile === null) return;
  busy = true;
  cancelRequested = false;
  historyOpenRequest += 1;
  clearError();
  setHidden(ui.paywall, true);
  setHidden(ui.dropZone, true);
  updateStartState();
  setProgress(null, "Starting…");
  setStatus("Preparing Studio…");
  const file = selectedFile;
  try {
    if (!await flushScheduledSave()) {
      throw new Error("Could not save the open transcript. Use Retry save before starting.");
    }
    const acquiredEntitlement = await lease.acquire();
    if (cancelRequested) throw new TranscriptionCancelledError();
    applyEntitlement(acquiredEntitlement);
    freeRunsUsed = await readUsedFreeRuns();
    if (cancelRequested) throw new TranscriptionCancelledError();
    if (!pro && freeRunsLeft(freeRunsUsed) === 0) throw new FreeRunsExhaustedError();
    const maxSeconds = pro ? STUDIO_PRO_MAX_SECONDS : STUDIO_FREE_MAX_SECONDS;
    if (selectedDuration !== null && selectedDuration > maxSeconds + 1) {
      throw new Error(
        pro ? "This file is longer than the 90-minute Studio limit." : "Free Studio accepts files up to 30 minutes. Studio Pro accepts files up to 90 minutes."
      );
    }
    setProgress(null, "Decoding audio…");
    setStatus("Chrome is decoding the file on this device…");
    decodeController = new AbortController();
    const decoded = await decodeStudioFile(file, maxSeconds, {
      signal: decodeController.signal,
      durationSeconds: selectedDuration ?? void 0
    });
    if (cancelRequested) throw new TranscriptionCancelledError();
    const samples = decoded.samples;
    segments = [];
    lastCaptionEnd = 0;
    freeRunCounted = false;
    freeRunWrite = null;
    transcriptView.clear();
    currentDocument = null;
    historyBacked = false;
    historySaveFailed = false;
    translationRunKind = null;
    canSeek = true;
    ui.translateStatus.textContent = "";
    hideTranslationProgress();
    setHidden(ui.transcriptSection, false);
    updateTranscriptHeading();
    const runLanguage = selectedLanguage();
    setProgress(0, "Loading the speech model…");
    setStatus("Loading the best on-device model. First use downloads it once.");
    const active = new BatchTranscriber();
    transcriber = active;
    const result = await active.transcribe(samples, settings, runLanguage, {
      onStatus: (detail) => {
        setStatus(detail);
        if (detail.startsWith("Loading")) setProgress(null, detail);
      },
      onProgress: (progress) => {
        if (progress === null) return;
        const fraction = progress.total !== null && progress.total > 0 ? progress.loaded / progress.total : null;
        setProgress(
          fraction,
          progress.total === null ? `Loading ${progress.model ?? "model"}…` : `Loading ${progress.model ?? "model"} ${Math.round(
            progress.loaded / progress.total * 100
          )}%`
        );
      },
      onEngine: (label) => {
        ui.deviceHint.textContent = `Using ${label} · ${gpu ? "WebGPU" : "CPU"}`;
      },
      onChunk: (fraction) => {
        setProgress(fraction, "Transcribing audio…");
      },
      onCaption: addCaption,
      onLog: (message) => console.info("[brevier studio]", message)
    }, {
      preferSmallModel: !gpu,
      preferredEngine: studioModelChoice ?? void 0
    });
    if (cancelRequested) throw new TranscriptionCancelledError();
    segments.sort((a, b) => a.startSample - b.startSample);
    currentDocument = {
      id: crypto.randomUUID(),
      title: file.name,
      language: runLanguage,
      durationSamples: decoded.samples.length,
      createdAt: Date.now(),
      segments
    };
    transcriptView.finish(segments);
    updateTranscriptHeading();
    refreshTranscriptTarget(defaultTranslationTarget(runLanguage));
    paintTranslationControls();
    if (pro) {
      const saved = await historyQueue.saveNow(currentDocument);
      if (saved) {
        historyBacked = true;
        updateTranscriptHeading();
        await refreshHistory();
      }
    }
    setProgress(1, "Complete");
    setStatus(
      segments.length > 0 ? `Done · ${segments.length} lines · ${result.engine}` : `No speech found · ${result.engine}`
    );
  } catch (error) {
    if (segments.length > 0) promotePartialTranscript(file);
    if (error instanceof FreeRunsExhaustedError) {
      paintAccess();
      hideProgress();
      showPaywall();
      setStatus("You have used both free file transcriptions. Studio Pro continues with unlimited file transcription.");
    } else if (cancelRequested || error instanceof TranscriptionCancelledError) {
      setStatus(
        segments.length > 0 ? `Transcription cancelled · ${segments.length} lines kept.` : "Transcription cancelled."
      );
      setProgress(0, "Cancelled");
    } else {
      showError(errorMessage(error));
      setStatus(
        segments.length > 0 ? `Transcription stopped · ${segments.length} lines kept.` : "Transcription stopped."
      );
      hideProgress();
    }
    if (segments.length === 0) setHidden(ui.transcriptSection, true);
  } finally {
    if (freeRunWrite) await freeRunWrite;
    transcriber = null;
    decodeController = null;
    busy = false;
    cancelRequested = false;
    lease.release();
    setHidden(ui.fileCard, false);
    setHidden(ui.dropZone, true);
    setHidden(ui.cancelButton, true);
    setHidden(ui.startButton, false);
    updateStartState();
  }
}
async function startTranscriptTranslation() {
  if (busy || translationBusy || segments.length === 0) return;
  if (!pro && freeTranslationsLeft(freeTranslationsUsed) === 0) {
    ui.translateStatus.textContent = FREE_TRANSLATIONS_EXHAUSTED;
    showPaywall();
    return;
  }
  const transcript = currentDocumentOrNull();
  if (!transcript) return;
  currentDocument = transcript;
  const source = transcript.language;
  const documentId = transcript.id;
  const rows = segments;
  const target = ui.translateTarget.value;
  if (target === "" || target === source) {
    showError("Choose a target language different from the spoken language.");
    return;
  }
  const selected = new Set(transcriptView.selectedIds());
  const indices = rows.map((_segment, index) => index).filter((index) => {
    const segment2 = rows[index];
    if (segment2.text.trim() === "") return false;
    return selected.size === 0 || selected.has(segment2.id);
  });
  if (indices.length === 0) {
    showError("Select at least one transcript line to translate.");
    return;
  }
  const previousLanguage = transcript.translationLanguage;
  const replacesTranslations = previousLanguage !== void 0 && previousLanguage !== target && hasTranslations();
  if (replacesTranslations) {
    const confirmed = window.confirm(
      `Changing the target from ${translationLanguageName(
        previousLanguage
      )} to ${translationLanguageName(target)} clears the current translations. Continue?`
    );
    if (!confirmed) {
      ui.translateTarget.value = previousLanguage;
      return;
    }
  }
  historyOpenRequest += 1;
  translator.begin();
  translationBusy = true;
  translationRunKind = "transcript";
  clearError();
  ui.translateStatus.textContent = "Preparing translation…";
  setTranslationProgress(null, "Preparing translation…");
  paintTranslationControls();
  updateStartState();
  let completed = 0;
  try {
    applyEntitlement(await lease.acquire());
    freeTranslationsUsed = await readUsedFreeTranslations();
    if (!pro && freeTranslationsLeft(freeTranslationsUsed) === 0) {
      ui.translateStatus.textContent = FREE_TRANSLATIONS_EXHAUSTED;
      showPaywall();
      return;
    }
    if (currentDocument?.id !== documentId || segments !== rows) {
      ui.translateStatus.textContent = "The transcript changed before translation started.";
      return;
    }
    if (translator.isCancelled) return;
    if (replacesTranslations) clearTranslations();
    transcript.translationLanguage = target;
    freeTranslationCounted = false;
    freeTranslationWrite = null;
    const result = await translator.run({
      sourceLanguage: source,
      targetLanguage: target,
      providerId: selectedProvider(ui.translateProvider),
      rows,
      indices,
      callbacks: {
        onProviderProgress: (progress) => {
          if (progress) {
            setTranslationProgress(progress.fraction, progress.detail);
          } else {
            setTranslationProgress(null, "Translating…");
          }
        },
        onStart: (index) => {
          transcriptView.setTranslating(rows[index].id, true);
        },
        onLine: (index, text) => {
          const segment2 = rows[index];
          segment2.translation = text;
          transcriptView.upsert(segment2);
          transcriptView.setTranslating(segment2.id, false);
          completed += 1;
          countFreeTranslation();
        },
        onProgress: (done, total) => {
          setTranslationProgress(done / total, `Translating ${done} of ${total}…`);
        }
      }
    });
    if (result.cancelled) {
      ui.translateStatus.textContent = `Translation cancelled · ${result.completed} of ${result.total} lines done.`;
    } else {
      ui.translateStatus.textContent = `Translated ${result.completed} ${result.completed === 1 ? "line" : "lines"} to ${translationLanguageName(target)}.`;
      ui.exportMode.value = "translation";
    }
  } catch (error) {
    showError(errorMessage(error));
    ui.translateStatus.textContent = completed > 0 ? `Translation stopped after ${completed} lines.` : "Translation failed.";
  } finally {
    if (freeTranslationWrite) await freeTranslationWrite;
    translationBusy = false;
    translationRunKind = null;
    hideTranslationProgress();
    if (currentDocument?.id === documentId) {
      for (const segment2 of rows) transcriptView.setTranslating(segment2.id, false);
      if (!hasTranslations()) delete transcript.translationLanguage;
      scheduleHistorySave();
    }
    updateExportMode();
    updateTranscriptHeading();
    paintQuota();
    updateStartState();
    lease.release();
  }
}
function cancelTranslation() {
  if (!translationBusy) return;
  if (translationRunKind === "transcript") {
    ui.translateStatus.textContent = "Cancelling…";
  } else {
    ui.textStatus.textContent = "Cancelling…";
  }
  translator.cancel();
}
function clearTextResult() {
  if (translationBusy) return;
  textTranslationResult = "";
  ui.textOutput.value = "";
  ui.textStatus.textContent = "";
  hideTextTranslationProgress();
  paintTranslationControls();
}
function openTextPanel() {
  if (translationBusy) return;
  refreshTextTarget();
  setHidden(ui.textPanel, false);
  paintTranslationControls();
  ui.textInput.focus();
}
function closeTextPanel() {
  if (translationRunKind === "text") cancelTranslation();
  setHidden(ui.textPanel, true);
}
async function startTextTranslation() {
  if (translationBusy || busy) return;
  if (!pro && freeTranslationsLeft(freeTranslationsUsed) === 0) {
    ui.textStatus.textContent = FREE_TRANSLATIONS_EXHAUSTED;
    showPaywall();
    return;
  }
  const lines = ui.textInput.value.split(/\r?\n/);
  if (!lines.some((line) => line.trim() !== "")) {
    showError("Paste a transcript first. One line per subtitle row.");
    return;
  }
  if (hasSubtitleTimestamps(ui.textInput.value)) {
    showError(
      "This tool translates plain text. Remove subtitle timestamps (SRT/VTT) first; timed subtitle export is available from a Studio transcript."
    );
    return;
  }
  const source = ui.textSource.value;
  const target = ui.textTarget.value;
  if (source === "" || source === target) {
    showError("Choose a target language different from the source language.");
    return;
  }
  const rows = lines.map((text) => ({ text }));
  const indices = lines.map((_line, index) => index).filter((index) => lines[index].trim() !== "");
  const output = lines.map(() => "");
  translator.begin();
  translationBusy = true;
  translationRunKind = "text";
  textTranslationResult = "";
  ui.textOutput.value = "";
  clearError();
  ui.textStatus.textContent = "Preparing translation…";
  setTextTranslationProgress(null, "Preparing translation…");
  paintTranslationControls();
  updateStartState();
  try {
    applyEntitlement(await lease.acquire());
    freeTranslationsUsed = await readUsedFreeTranslations();
    if (!pro && freeTranslationsLeft(freeTranslationsUsed) === 0) {
      ui.textStatus.textContent = FREE_TRANSLATIONS_EXHAUSTED;
      showPaywall();
      return;
    }
    freeTranslationCounted = false;
    freeTranslationWrite = null;
    const result = await translator.run({
      sourceLanguage: source,
      targetLanguage: target,
      providerId: selectedProvider(ui.textProvider),
      rows,
      indices,
      callbacks: {
        onProviderProgress: (progress) => {
          if (progress) {
            setTextTranslationProgress(progress.fraction, progress.detail);
          } else {
            setTextTranslationProgress(null, "Translating…");
          }
        },
        onLine: (index, text) => {
          output[index] = text;
          textTranslationResult = output.join("\n");
          ui.textOutput.value = textTranslationResult;
          countFreeTranslation();
        },
        onProgress: (done, total) => {
          setTextTranslationProgress(done / total, `Translating ${done} of ${total}…`);
        }
      }
    });
    textTranslationResult = output.join("\n");
    ui.textOutput.value = textTranslationResult;
    ui.textStatus.textContent = result.cancelled ? `Translation cancelled · ${result.completed} of ${result.total} lines done.` : `Translated ${result.completed} ${result.completed === 1 ? "line" : "lines"} to ${translationLanguageName(target)}.`;
  } catch (error) {
    showError(errorMessage(error));
    ui.textStatus.textContent = textTranslationResult.trim() === "" ? "Translation failed." : "Translation stopped before the last line.";
  } finally {
    if (freeTranslationWrite) await freeTranslationWrite;
    translationBusy = false;
    translationRunKind = null;
    hideTextTranslationProgress();
    paintQuota();
    updateStartState();
    lease.release();
  }
}
async function copyTextTranslation() {
  if (textTranslationResult.trim() === "") return;
  try {
    await navigator.clipboard.writeText(textTranslationResult);
    ui.textStatus.textContent = "Copied.";
  } catch {
    showError("Could not copy to the clipboard. Use the download instead.");
  }
}
function downloadTextTranslation() {
  if (textTranslationResult.trim() === "") return;
  const url = URL.createObjectURL(
    new Blob([textTranslationResult], { type: "text/plain;charset=utf-8" })
  );
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "translated.txt";
  document.body.append(anchor);
  anchor.click();
  anchor.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 2e3);
}
function cancelActiveWork() {
  cancelRequested = true;
  decodeController?.abort();
  void transcriber?.cancel();
  translator.cancel();
}
async function cancelTranscription() {
  if (!busy) return;
  ui.cancelButton.disabled = true;
  setStatus("Cancelling…");
  cancelActiveWork();
}
function wireEvents() {
  ui.pickFile.addEventListener("click", () => ui.fileInput.click());
  ui.replaceFile.addEventListener("click", () => ui.fileInput.click());
  ui.fileInput.addEventListener("change", () => handleFiles(ui.fileInput.files));
  ui.dropZone.addEventListener("dragover", (event) => {
    event.preventDefault();
    ui.dropZone.classList.add("is-over");
  });
  ui.dropZone.addEventListener("dragleave", () => {
    ui.dropZone.classList.remove("is-over");
  });
  ui.dropZone.addEventListener("drop", (event) => {
    event.preventDefault();
    ui.dropZone.classList.remove("is-over");
    handleFiles(event.dataTransfer?.files ?? null);
  });
  ui.startButton.addEventListener("click", () => void startTranscription());
  ui.cancelButton.addEventListener("click", () => void cancelTranscription());
  ui.language.addEventListener("change", () => {
    populateStudioModelSelect();
    refreshTranscriptTarget();
    paintTranslationControls();
  });
  ui.studioModel.addEventListener("change", () => {
    studioModelChoice = studioModelOptions(selectedLanguage()).find(
      (option) => option.value === ui.studioModel.value
    )?.candidate ?? null;
    updateEngineHint();
    void rememberStudioModel(ui.studioModel.value);
  });
  ui.pasteTextButton.addEventListener("click", () => openTextPanel());
  ui.textPanelClose.addEventListener("click", () => closeTextPanel());
  ui.textTranslate.addEventListener("click", () => void startTextTranslation());
  ui.textCancel.addEventListener("click", () => cancelTranslation());
  ui.textCopy.addEventListener("click", () => void copyTextTranslation());
  ui.textDownload.addEventListener("click", () => downloadTextTranslation());
  ui.textInput.addEventListener("input", () => clearTextResult());
  ui.textSource.addEventListener("change", () => {
    refreshTextTarget();
    clearTextResult();
  });
  ui.textTarget.addEventListener("change", () => clearTextResult());
  ui.textProvider.addEventListener("change", () => paintTranslationControls());
  ui.translateButton.addEventListener("click", () => void startTranscriptTranslation());
  ui.translateCancel.addEventListener("click", () => cancelTranslation());
  ui.selectAllSegments.addEventListener(
    "change",
    () => transcriptView.setAllSelected(ui.selectAllSegments.checked)
  );
  ui.translateTarget.addEventListener("change", () => paintTranslationControls());
  ui.translateProvider.addEventListener("change", () => paintTranslationControls());
  for (const button of [ui.upgradeButton, ui.upgradeInline, ui.historyUpgrade]) {
    button.addEventListener("click", () => void openUpgrade());
  }
  ui.upgradeMonthly.addEventListener("click", () => void openUpgrade("pro-monthly"));
  ui.upgradeYearly.addEventListener("click", () => void openUpgrade("pro-yearly"));
  ui.newFileButton.addEventListener("click", () => void resetForNewFile());
  ui.retrySaveButton.addEventListener("click", () => void retryHistorySave());
  ui.copyButton.addEventListener("click", () => void copyTranscript());
  ui.exportTxt.addEventListener("click", () => downloadExport("txt"));
  ui.exportMd.addEventListener("click", () => downloadExport("md"));
  ui.exportSrt.addEventListener("click", () => downloadExport("srt"));
  ui.exportVtt.addEventListener("click", () => downloadExport("vtt"));
  ui.refreshHistory.addEventListener("click", () => void refreshHistory());
  ui.noticeButton.addEventListener("click", () => {
    void chrome.tabs.create({ url: chrome.runtime.getURL("notices.html") });
  });
  ui.diagnosticsButton.addEventListener("click", () => {
    void chrome.tabs.create({ url: chrome.runtime.getURL("debug/debug.html") });
  });
  window.addEventListener("focus", () => {
    if (!busy) void refreshEntitlement();
  });
  window.addEventListener("pagehide", () => {
    translator.cancel();
    void flushScheduledSave();
    lease.release();
  });
}
async function adoptLeaseOwner() {
  try {
    await new Promise((resolve) => {
      chrome.tabs.getCurrent((tab) => {
        if (tab?.id !== void 0) lease.adoptTabOwner(tab.id);
        resolve();
      });
    });
  } catch {
  }
}
async function init() {
  ui.diagnosticsButton.classList.toggle("hidden", true);
  ui.fileInput.accept = STUDIO_ACCEPT;
  settings = await loadSettings().catch(() => DEFAULT_SETTINGS);
  freeRunsUsed = await readUsedFreeRuns();
  freeTranslationsUsed = await readUsedFreeTranslations();
  const storedModel = await readStoredStudioModel();
  await adoptLeaseOwner();
  populateLanguages();
  populateTranslationOptions();
  setDefaultTranslationProvider();
  wireEvents();
  paintAccess();
  gpu = await hasWebGpu();
  setDefaultTranslationProvider();
  populateStudioModelSelect(storedModel ?? void 0);
  paintTranslationControls();
  await refreshEntitlement();
}
void init();
