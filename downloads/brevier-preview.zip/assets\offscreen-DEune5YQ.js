import { H as Hymt2TranslationProvider, c as createEngine } from "./provider-B_KqvFy7.js";
import { e as errorMessage, d as isOffscreenMessage, t as translationSignature, f as engineSignature, s as spokenLanguage } from "./settings-9gB2l1gl.js";
import { C as ChromeTranslationProvider, t as translationLanguageName } from "./translation-languages-rIHGiGRb.js";
import { h as hasWebGpu } from "./webgpu-D1jNrLJ3.js";
const CACHE_LIMIT = 300;
const PENDING_LINE_LIMIT = 3;
const LATEST_TEXT_LIMIT = 200;
const PROVISIONAL_GRACE_MS = 1500;
let translatorSequence = 0;
class CaptionTranslator {
  options;
  cache = /* @__PURE__ */ new Map();
  inflight = /* @__PURE__ */ new Map();
  /** Latest final text per line; a correction replaces the earlier text. */
  latestText = /* @__PURE__ */ new Map();
  /** Finals waiting for the single translation slot, keyed by line id. */
  pending = /* @__PURE__ */ new Map();
  /** Promoted interims waiting for their correction decode. */
  provisionalTimers = /* @__PURE__ */ new Map();
  active = false;
  sequence = 0;
  generation = 0;
  /** Unique per instance so a rebuilt translator cannot reuse old line ids. */
  idPrefix = ++translatorSequence;
  constructor(options) {
    this.options = options;
  }
  /** Forward immediately; any translation arrives later via onUpdate. */
  handle(event) {
    if (event.kind !== "final") return event;
    const forwarded = event.lineId ? event : { ...event, lineId: `line-${this.idPrefix}-${++this.sequence}` };
    const lineId = forwarded.lineId;
    const text = forwarded.text.trim();
    if (!lineId || text === "") return forwarded;
    this.clearProvisional(lineId);
    this.latestText.delete(lineId);
    this.latestText.set(lineId, text);
    while (this.latestText.size > LATEST_TEXT_LIMIT) {
      const oldest = this.latestText.keys().next().value;
      if (oldest === void 0) break;
      this.latestText.delete(oldest);
    }
    if (forwarded.provisional) {
      this.provisionalTimers.set(
        lineId,
        setTimeout(() => {
          this.provisionalTimers.delete(lineId);
          if (this.latestText.get(lineId) === text) this.queue(forwarded);
        }, PROVISIONAL_GRACE_MS)
      );
      return forwarded;
    }
    this.queue(forwarded);
    return forwarded;
  }
  /** Drops updates from the previous provider/session. */
  reset() {
    this.generation++;
    this.pending.clear();
    this.latestText.clear();
    for (const timer of this.provisionalTimers.values()) clearTimeout(timer);
    this.provisionalTimers.clear();
  }
  clearProvisional(lineId) {
    const timer = this.provisionalTimers.get(lineId);
    if (timer === void 0) return;
    clearTimeout(timer);
    this.provisionalTimers.delete(lineId);
  }
  /**
   * Queues one final. A newer text for the same line replaces the queued one,
   * and the oldest lines are dropped once the small queue is full, so a slow
   * model cannot build a translation backlog.
   */
  queue(event) {
    const lineId = event.lineId;
    if (!lineId) return;
    this.pending.delete(lineId);
    this.pending.set(lineId, event);
    while (this.pending.size > PENDING_LINE_LIMIT) {
      const oldest = this.pending.keys().next().value;
      if (oldest === void 0) break;
      this.pending.delete(oldest);
    }
    void this.pump();
  }
  /** Runs one translation at a time and always takes the newest waiting line. */
  async pump() {
    if (this.active) return;
    const next = this.takeNext();
    if (!next) return;
    this.active = true;
    try {
      await this.translateLine(next);
    } finally {
      this.active = false;
      void this.pump();
    }
  }
  takeNext() {
    const entries = Array.from(this.pending.entries());
    for (let index = entries.length - 1; index >= 0; index--) {
      const [lineId, event] = entries[index];
      this.pending.delete(lineId);
      if (this.latestText.get(lineId) !== event.text.trim()) continue;
      return event;
    }
    return null;
  }
  async translateLine(event) {
    const generation = this.generation;
    const lineId = event.lineId;
    const text = event.text.trim();
    if (!lineId || text === "") return;
    let lastPartial = "";
    try {
      const translation = await this.translateText(text, (partial) => {
        if (generation !== this.generation) return;
        if (this.latestText.get(lineId) !== text) return;
        const trimmed = partial.trim();
        if (!trimmed || trimmed === lastPartial) return;
        lastPartial = trimmed;
        this.options.onUpdate({ ...event, translation: trimmed, at: Date.now() });
      });
      if (generation !== this.generation) return;
      if (this.latestText.get(lineId) !== text) return;
      this.options.onUpdate({ ...event, translation, at: Date.now() });
    } catch (error) {
      if (generation !== this.generation) return;
      this.options.onError(error instanceof Error ? error : new Error(String(error)));
    }
  }
  translateText(text, onPartial) {
    const cached = this.cache.get(text);
    if (cached !== void 0) return Promise.resolve(cached);
    const existing = this.inflight.get(text);
    if (existing) return existing;
    const request = this.options.provider.translate(text, onPartial).then((translation) => {
      this.inflight.delete(text);
      this.cache.set(text, translation);
      while (this.cache.size > CACHE_LIMIT) {
        const oldest = this.cache.keys().next().value;
        if (oldest === void 0) break;
        this.cache.delete(oldest);
      }
      return translation;
    }).catch((error) => {
      this.inflight.delete(text);
      throw error;
    });
    this.inflight.set(text, request);
    return request;
  }
}
function createTranslationProvider(id) {
  switch (id) {
    case "hymt2":
      return new Hymt2TranslationProvider();
    case "chrome":
    default:
      return new ChromeTranslationProvider();
  }
}
const CHUNK_SIZE = 2048;
const SUSPENDED_GRACE_MS = 5e3;
function tabAudioConstraints(streamId) {
  return {
    audio: {
      // Tab capture only accepts the legacy `mandatory` form; adding standard
      // constraints such as echoCancellation alongside it makes Chrome throw
      // "Malformed constraint". WebRTC processing is bypassed for tab capture
      // anyway, so there is nothing else to disable.
      mandatory: {
        chromeMediaSource: "tab",
        chromeMediaSourceId: streamId
      }
    },
    video: false
  };
}
function describeCaptureError(error) {
  const message = errorMessage(error);
  if (/error starting tab capture/i.test(message)) {
    return "Chrome refused to start tab capture for this tab. This happens on chrome:// or extension pages, or when the tab is already being captured. Open the website that is playing audio and try again.";
  }
  return message;
}
class TabAudioCapture {
  context = null;
  stream = null;
  source = null;
  worklet = null;
  processor = null;
  onEnded = null;
  stopping = false;
  endedReported = false;
  suspensionTimer = null;
  async start(streamId, onFrame, onEnded) {
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia(tabAudioConstraints(streamId));
    } catch (error) {
      throw new Error(describeCaptureError(error));
    }
    if (stream.getAudioTracks().length === 0) {
      stream.getTracks().forEach((track) => track.stop());
      throw new Error("The captured tab did not provide an audio track.");
    }
    this.stream = stream;
    this.stopping = false;
    this.endedReported = false;
    this.onEnded = onEnded ?? null;
    for (const track of stream.getAudioTracks()) {
      track.addEventListener("ended", this.handleTrackEnded);
    }
    const context = new AudioContext({ latencyHint: "interactive" });
    this.context = context;
    let workletReady = false;
    try {
      await Promise.race([
        context.audioWorklet.addModule(chrome.runtime.getURL("pcm-worklet.js")),
        new Promise(
          (_resolve, reject) => setTimeout(() => reject(new Error("Audio worklet timed out.")), 5e3)
        )
      ]);
      workletReady = true;
    } catch {
      workletReady = false;
    }
    if (this.endedReported) {
      throw new Error("Tab audio capture ended while starting.");
    }
    context.addEventListener("statechange", () => {
      if (context.state === "running") {
        this.clearSuspensionTimer();
        return;
      }
      if (context.state === "suspended") {
        void context.resume().catch(() => {
        });
        this.armSuspensionTimer(context);
      }
    });
    const source = context.createMediaStreamSource(stream);
    this.source = source;
    if (workletReady) {
      const worklet = new AudioWorkletNode(context, "pcm-capture", {
        numberOfInputs: 1,
        // A zero-output worklet is not guaranteed to be pulled by the render
        // graph, so it gets a silent output that we connect to the destination.
        // (The processor never writes to it; tab audio passthrough is the direct
        // source -> destination connection below.)
        numberOfOutputs: 1,
        outputChannelCount: [1],
        processorOptions: { chunkSize: CHUNK_SIZE }
      });
      this.worklet = worklet;
      worklet.port.onmessage = (event) => {
        onFrame(event.data, context.sampleRate);
      };
      source.connect(worklet);
      worklet.connect(context.destination);
    } else {
      const processor = context.createScriptProcessor(CHUNK_SIZE, 1, 1);
      processor.onaudioprocess = (event) => {
        onFrame(new Float32Array(event.inputBuffer.getChannelData(0)), context.sampleRate);
      };
      this.processor = processor;
      source.connect(processor);
      processor.connect(context.destination);
    }
    source.connect(context.destination);
    if (context.state === "suspended") {
      await Promise.race([
        context.resume().catch(() => {
        }),
        new Promise((resolve) => setTimeout(resolve, 2e3))
      ]);
    }
  }
  async stop() {
    this.stopping = true;
    this.clearSuspensionTimer();
    try {
      this.worklet?.port.close();
      this.worklet?.disconnect();
      this.processor?.disconnect();
      this.source?.disconnect();
    } catch {
    }
    this.worklet = null;
    this.processor = null;
    this.source = null;
    this.stream?.getTracks().forEach((track) => {
      track.removeEventListener("ended", this.handleTrackEnded);
      track.stop();
    });
    this.stream = null;
    this.onEnded = null;
    const context = this.context;
    this.context = null;
    if (context && context.state !== "closed") {
      await context.close();
    }
  }
  handleTrackEnded = () => {
    this.reportEnded("ended");
  };
  reportEnded(reason) {
    if (this.stopping || this.endedReported) return;
    this.endedReported = true;
    this.onEnded?.(reason);
  }
  armSuspensionTimer(context) {
    if (this.suspensionTimer !== null) return;
    this.suspensionTimer = window.setTimeout(() => {
      this.suspensionTimer = null;
      if (this.context === context && context.state === "suspended") {
        this.reportEnded("suspended");
      }
    }, SUSPENDED_GRACE_MS);
  }
  clearSuspensionTimer() {
    if (this.suspensionTimer !== null) {
      window.clearTimeout(this.suspensionTimer);
      this.suspensionTimer = null;
    }
  }
  get active() {
    return this.context !== null;
  }
}
const MAX_ENGINE_RESTARTS = 2;
const ENGINE_RESTART_WINDOW_MS = 5 * 6e4;
const HEALTH_TIMEOUT_MS = 15e3;
const HEALTH_POLL_MS = 5e3;
const AUDIBLE_RMS = 2e-3;
const AUDIBLE_WINDOW_MS = 5e3;
const CAPTION_STALL_MS = 6e4;
const TRANSLATION_RETRY_MS = 5e3;
const TRANSLATION_RETRY_DELAY_MS = 15e3;
const TRANSLATION_DEATH_RETRY_MS = 2e3;
const MAX_TRANSLATION_RETRIES = 2;
function send(message) {
  void chrome.runtime.sendMessage(message).catch(() => {
  });
}
class OffscreenHost {
  capture = new TabAudioCapture();
  engine = null;
  settings = null;
  /** Settings signature the live engine was built from. */
  engineSignatureValue = "";
  /** Translation layer (null when translation is disabled or failed). */
  translator = null;
  translationProvider = null;
  translationSignatureValue = "";
  translationGeneration = 0;
  /** Latest applyTranslation call; older calls bail after async probes. */
  translationApplyToken = 0;
  translationStatus = "off";
  translationDetail = "";
  translationFraction = null;
  /** Detail shown once translation is ready again after a transient error. */
  translationReadyDetail = "";
  translationAttemptAt = 0;
  translationRetryTimer = null;
  /** Automatic provider rebuilds left after a failure. */
  translationRetries = 0;
  status = "idle";
  detail = "Idle";
  progress = null;
  lastError = null;
  /** Status heartbeat timer used while starting/loading. */
  ticker = null;
  loadingStartedAt = null;
  /** Phase text the ticker appends the elapsed seconds to. */
  loadingBaseDetail = "";
  /** Ready-state health check: audio frames must keep arriving. */
  healthTimer = null;
  lastFrameAt = 0;
  /** Last time the tab was clearly audible / a caption was produced. */
  lastAudibleAt = 0;
  lastCaptionAt = 0;
  /** When the current ready phase began; the watchdog ignores fresh starts. */
  readyAt = 0;
  /** Audio activity reporting (peak RMS since the last report). */
  audioPeak = 0;
  audioReportedAt = 0;
  /**
   * Bumped whenever a new start/stop/rebuild begins. Async continuations from
   * older generations bail out so stale model loads cannot take over a newer
   * session.
   */
  generation = 0;
  /** Runtime engine failures trigger a rebuild instead of ending capture. */
  restarting = false;
  restartTimes = [];
  restartError = "";
  get capturing() {
    return this.capture.active;
  }
  async start(streamId, settings) {
    const generation = ++this.generation;
    this.settings = settings;
    this.lastError = null;
    this.progress = null;
    this.audioPeak = 0;
    this.audioReportedAt = Date.now();
    this.lastFrameAt = Date.now();
    this.lastAudibleAt = 0;
    this.lastCaptionAt = Date.now();
    this.restarting = false;
    this.restartTimes = [];
    send({ type: "offscreen:audio", level: 0 });
    this.setStatus("starting", "Starting…");
    try {
      await this.capture.start(
        streamId,
        (samples, sampleRate) => {
          this.reportAudio(samples);
          this.engine?.pushAudio(samples, sampleRate);
        },
        (reason) => {
          if (generation !== this.generation) return;
          this.generation += 1;
          this.fail(
            new Error(
              reason === "ended" ? "Tab audio capture ended (the tab may have been closed or capture was stopped). Click Start to resume." : "Chrome suspended the audio capture. Click Start to resume."
            )
          );
        }
      );
      if (generation !== this.generation) return;
      this.setStatus("starting", "Audio captured — loading engine…");
      const engine = await this.buildEngine(settings, generation);
      if (!engine || generation !== this.generation) return;
      if (this.status === "error") return;
      this.setStatus("ready", "Captions on");
      void this.applyTranslation(settings);
    } catch (error) {
      if (generation !== this.generation) return;
      await this.teardown();
      this.fail(error);
    }
  }
  async stop() {
    this.generation++;
    await this.teardown();
    this.progress = null;
    this.setStatus("idle", "Idle");
  }
  /**
   * Applies settings while running. Overlay-only changes are ignored here
   * (the content script handles them); engine-relevant changes rebuild the
   * engine but leave the audio capture untouched — the tab stream cannot be
   * re-acquired from the same stream id.
   */
  async updateSettings(settings) {
    this.settings = settings;
    if (!this.capturing) return;
    const translationChanged = translationSignature(settings) !== this.translationSignatureValue;
    const translationRetry = settings.translation.enabled && this.translationStatus === "error" && Date.now() - this.translationAttemptAt >= TRANSLATION_RETRY_MS;
    if (translationChanged || translationRetry) {
      this.clearTranslationRetry();
      void this.applyTranslation(settings);
    } else if (settings.translation.enabled && this.translationStatus === "error") {
      const remaining = TRANSLATION_RETRY_MS - (Date.now() - this.translationAttemptAt);
      if (remaining > 0) this.scheduleTranslationRetry(remaining);
    }
    if (engineSignature(settings) === this.engineSignatureValue) return;
    const generation = ++this.generation;
    this.progress = null;
    this.setStatus("loading", "Applying new engine settings…");
    try {
      const engine = await this.buildEngine(settings, generation);
      if (!engine || generation !== this.generation) return;
      this.setStatus("ready", "Captions on");
    } catch (error) {
      if (generation !== this.generation) return;
      await this.teardown();
      this.fail(error);
    }
  }
  getState() {
    return {
      capturing: this.capturing,
      status: this.status,
      detail: this.detail,
      progress: this.progress,
      error: this.lastError,
      translationStatus: this.translationStatus,
      translationDetail: this.translationDetail,
      translationFraction: this.translationFraction
    };
  }
  async buildEngine(settings, generation) {
    await this.disposeEngine();
    if (generation !== this.generation) return null;
    const engine = createEngine(settings.engine);
    this.engine = engine;
    this.engineSignatureValue = engineSignature(settings);
    const isCurrent = () => generation === this.generation;
    try {
      await engine.initialize({
        settings,
        events: {
          onStatus: (status, detail) => {
            if (!isCurrent()) return;
            this.setStatus(status, detail ?? defaultDetail(status));
          },
          onProgress: (progress) => {
            if (!isCurrent()) return;
            this.progress = progress;
            send({ type: "offscreen:progress", progress });
          },
          onCaption: (event) => {
            if (!isCurrent()) return;
            this.lastCaptionAt = Date.now();
            const forwarded = this.translator ? this.translator.handle(event) : event;
            send({ type: "offscreen:caption", event: forwarded });
          },
          onError: (error) => {
            if (!isCurrent()) return;
            this.handleEngineError(error);
          }
        }
      });
      if (!isCurrent()) {
        await this.disposeSuperseded(engine);
        return null;
      }
      await engine.start();
      if (!isCurrent()) {
        await this.disposeSuperseded(engine);
        return null;
      }
    } catch (error) {
      if (!isCurrent()) {
        await this.disposeSuperseded(engine);
        return null;
      }
      throw error;
    }
    this.progress = null;
    return engine;
  }
  /**
   * A build that lost the generation race must release the worker it started;
   * otherwise an abandoned model load keeps holding GPU memory and bandwidth.
   */
  async disposeSuperseded(engine) {
    if (this.engine === engine) {
      this.engine = null;
      this.engineSignatureValue = "";
    }
    try {
      await engine.dispose();
    } catch {
    }
  }
  async disposeEngine() {
    const engine = this.engine;
    this.engine = null;
    this.engineSignatureValue = "";
    if (!engine) return;
    try {
      await engine.dispose();
    } catch {
    }
  }
  /**
   * A runtime engine failure (lost WebGPU device, stalled decode) rebuilds the
   * engine without dropping the tab stream. Startup failures still fail the
   * session, where Auto's own fallback chain belongs.
   */
  handleEngineError(error) {
    if (this.restarting) return;
    console.error("[brevier] engine error", error);
    this.restartError = errorMessage(error);
    if (this.status !== "ready" || !this.engine) {
      this.fail(error);
      return;
    }
    const now = Date.now();
    this.restartTimes = this.restartTimes.filter((at) => now - at < ENGINE_RESTART_WINDOW_MS);
    if (this.restartTimes.length >= MAX_ENGINE_RESTARTS) {
      this.fail(error);
      return;
    }
    this.restartTimes.push(now);
    void this.restartEngine();
  }
  async restartEngine() {
    const settings = this.settings;
    if (!settings || this.restarting) return;
    this.restarting = true;
    const generation = ++this.generation;
    this.progress = null;
    if (settings.translation.enabled) {
      this.clearTranslationRetry();
      this.translationApplyToken++;
      this.disposeTranslation();
      this.translationSignatureValue = "";
      this.reportTranslation("loading", "Restarting translation…");
    }
    this.setStatus("loading", `Restarting captions… (${this.restartError})`);
    try {
      const engine = await this.buildEngine(settings, generation);
      if (!engine || generation !== this.generation) return;
      this.setStatus("ready", "Captions on");
      if (settings.translation.enabled) void this.applyTranslation(settings);
    } catch (error) {
      if (generation !== this.generation) return;
      await this.disposeEngine();
      this.fail(error);
    } finally {
      this.restarting = false;
    }
  }
  /**
   * Builds (or tears down) the translation layer for the given settings.
   * A language change keeps the loaded Hy-MT2 worker and only swaps its prompt;
   * a provider change or a failed retarget rebuilds from scratch.
   * Failures are surfaced to the popup but never stop the captions.
   */
  async applyTranslation(settings) {
    this.clearTranslationRetry();
    const token = ++this.translationApplyToken;
    const signature = translationSignature(settings);
    const sourceLanguage = spokenLanguage(settings);
    const targetLanguage = settings.translation.targetLanguage;
    if (!settings.translation.enabled) {
      this.disposeTranslation();
      this.translationSignatureValue = signature;
      this.translationRetries = 0;
      this.reportTranslation("off", "");
      return;
    }
    this.translationAttemptAt = Date.now();
    if (sourceLanguage === targetLanguage) {
      this.disposeTranslation();
      this.translationSignatureValue = signature;
      this.reportTranslation(
        "error",
        "The translation target is the same as the spoken language. Pick a different language."
      );
      return;
    }
    const readyDetail = `Translating to ${translationLanguageName(targetLanguage)}`;
    const fallbackToChrome = settings.translation.provider === "hymt2" && !await hasWebGpu();
    if (token !== this.translationApplyToken) return;
    const providerId = fallbackToChrome ? "chrome" : settings.translation.provider;
    const existing = this.translationProvider;
    const reuse = existing && existing.id === providerId && existing.retarget && sourceLanguage !== targetLanguage ? existing : null;
    if (reuse) {
      const generation2 = ++this.translationGeneration;
      this.translationSignatureValue = signature;
      this.translator?.reset();
      this.translator = null;
      this.reportTranslation("loading", "Switching translation language…");
      try {
        await reuse.retarget({
          sourceLanguage,
          targetLanguage,
          onProgress: (progress) => {
            if (generation2 !== this.translationGeneration) return;
            if (progress) {
              this.reportTranslation("loading", progress.detail, progress.fraction);
            }
          }
        });
        if (generation2 !== this.translationGeneration) return;
        if (token !== this.translationApplyToken) return;
        this.translationReadyDetail = readyDetail;
        this.translator = this.createTranslator(reuse, generation2);
        this.translationRetries = 0;
        this.reportTranslation("ready", readyDetail);
        return;
      } catch (error) {
        if (generation2 !== this.translationGeneration) return;
        if (token !== this.translationApplyToken) return;
        this.disposeTranslation();
      }
    } else {
      this.disposeTranslation();
    }
    const generation = this.translationGeneration;
    this.translationSignatureValue = signature;
    this.translationReadyDetail = readyDetail;
    const provider = createTranslationProvider(providerId);
    this.translationProvider = provider;
    this.translator = this.createTranslator(provider, generation);
    const preparing = fallbackToChrome ? "Chrome translation (CPU) — Hy-MT2 needs WebGPU" : "Preparing translation…";
    this.reportTranslation("loading", preparing);
    try {
      await provider.initialize({
        sourceLanguage,
        targetLanguage,
        onProgress: (progress) => {
          if (generation !== this.translationGeneration) return;
          if (!progress) {
            this.reportTranslation("loading", preparing);
            return;
          }
          this.reportTranslation("loading", progress.detail, progress.fraction);
        }
      });
      if (generation !== this.translationGeneration) return;
      this.translationRetries = 0;
      this.reportTranslation("ready", readyDetail);
    } catch (error) {
      if (generation !== this.translationGeneration) return;
      this.disposeTranslation();
      this.reportTranslation("error", errorMessage(error));
      this.scheduleTranslationFailureRetry();
    }
  }
  createTranslator(provider, generation) {
    return new CaptionTranslator({
      provider,
      onUpdate: (event) => {
        if (generation !== this.translationGeneration) return;
        if (this.translationStatus === "error") {
          this.reportTranslation("ready", this.translationReadyDetail || "Translation ready");
        }
        send({ type: "offscreen:caption", event });
      },
      onError: (error) => {
        if (generation !== this.translationGeneration) return;
        const providerDied = this.translationStatus === "ready" && this.translationProvider !== null && !this.translationProvider.available;
        this.reportTranslation("error", error.message);
        if (providerDied) {
          this.disposeTranslation();
          this.scheduleTranslationFailureRetry(TRANSLATION_DEATH_RETRY_MS);
        }
      }
    });
  }
  disposeTranslation() {
    this.translationGeneration++;
    this.translator?.reset();
    this.translator = null;
    const provider = this.translationProvider;
    this.translationProvider = null;
    try {
      provider?.dispose();
    } catch {
    }
  }
  /**
   * Debounced trailing retry: overlay sliders can ping many times while a
   * translation error is showing, but a real retry should still happen.
   */
  scheduleTranslationRetry(delayMs) {
    this.clearTranslationRetry();
    this.translationRetryTimer = window.setTimeout(() => {
      this.translationRetryTimer = null;
      if (this.settings && this.translationStatus === "error") {
        void this.applyTranslation(this.settings);
      }
    }, delayMs);
  }
  /** Retries a failed model build a couple of times with a growing delay. */
  scheduleTranslationFailureRetry(baseDelayMs = TRANSLATION_RETRY_DELAY_MS) {
    if (this.translationRetryTimer !== null) return;
    if (this.translationRetries >= MAX_TRANSLATION_RETRIES) return;
    this.translationRetries += 1;
    this.scheduleTranslationRetry(baseDelayMs * this.translationRetries);
  }
  clearTranslationRetry() {
    if (this.translationRetryTimer !== null) {
      window.clearTimeout(this.translationRetryTimer);
      this.translationRetryTimer = null;
    }
  }
  reportTranslation(status, detail, fraction = null) {
    this.translationStatus = status;
    this.translationDetail = detail;
    this.translationFraction = status === "loading" ? fraction : null;
    send({
      type: "offscreen:translation",
      status,
      detail,
      fraction: this.translationFraction
    });
  }
  async teardown() {
    this.stopHealthWatch();
    this.clearTranslationRetry();
    this.translationApplyToken++;
    this.disposeTranslation();
    this.translationSignatureValue = "";
    this.translationRetries = 0;
    this.reportTranslation("off", "");
    const engine = this.engine;
    this.engine = null;
    this.engineSignatureValue = "";
    if (engine) {
      try {
        await engine.stop();
      } catch {
      }
    }
    await this.capture.stop();
    if (engine) {
      try {
        await engine.dispose();
      } catch {
      }
    }
  }
  /**
   * While the pipeline is starting or loading, resend the status every few
   * seconds with the elapsed time. This gives the popup visible movement and
   * doubles as a heartbeat: if these stop arriving while capture is running,
   * the offscreen document has been torn down by the browser.
   */
  startLoadingTicker(detail) {
    if (detail !== this.loadingBaseDetail) {
      this.loadingBaseDetail = detail;
      this.loadingStartedAt = Date.now();
      this.detail = detail;
    }
    if (this.ticker !== null) return;
    this.ticker = window.setInterval(() => {
      if (this.status !== "loading" && this.status !== "starting") {
        this.stopLoadingTicker();
        return;
      }
      const seconds = Math.round((Date.now() - (this.loadingStartedAt ?? Date.now())) / 1e3);
      this.detail = `${this.loadingBaseDetail} (${seconds}s)`;
      send({ type: "offscreen:status", status: this.status, detail: this.detail });
    }, 5e3);
  }
  stopLoadingTicker() {
    if (this.ticker !== null) {
      window.clearInterval(this.ticker);
      this.ticker = null;
    }
    this.loadingStartedAt = null;
    this.loadingBaseDetail = "";
  }
  /**
   * Reports the captured audio level twice a second so the popup can show
   * whether sound is actually flowing (and distinguish "no audio" from
   * "no speech recognized").
   */
  reportAudio(samples) {
    let sum = 0;
    for (let i = 0; i < samples.length; i++) {
      sum += samples[i] * samples[i];
    }
    const rms = Math.sqrt(sum / samples.length);
    if (rms > this.audioPeak) this.audioPeak = rms;
    const now = Date.now();
    if (rms >= AUDIBLE_RMS) this.lastAudibleAt = now;
    this.lastFrameAt = now;
    if (now - this.audioReportedAt >= 500) {
      this.audioReportedAt = now;
      send({ type: "offscreen:audio", level: this.audioPeak });
      this.audioPeak = 0;
    }
  }
  /**
   * A silent tab still produces audio frames. If frames stop while the
   * pipeline claims to be ready, the capture or renderer wedged; fail loudly
   * instead of showing "Captions on" forever.
   */
  startHealthWatch() {
    if (this.healthTimer !== null) return;
    this.lastFrameAt = Date.now();
    this.healthTimer = window.setInterval(() => {
      if (this.status !== "ready") {
        this.stopHealthWatch();
        return;
      }
      const now = Date.now();
      if (now - this.lastFrameAt > HEALTH_TIMEOUT_MS) {
        this.stopHealthWatch();
        this.fail(
          new Error("Tab audio stopped flowing. Click Start to resume captions.")
        );
        return;
      }
      if (this.engine && !this.restarting && now - this.readyAt >= CAPTION_STALL_MS && now - this.lastAudibleAt <= AUDIBLE_WINDOW_MS && now - this.lastCaptionAt >= CAPTION_STALL_MS) {
        this.stopHealthWatch();
        this.handleEngineError(
          new Error("No captions while the tab was playing audio. Restarting captions…")
        );
      }
    }, HEALTH_POLL_MS);
  }
  stopHealthWatch() {
    if (this.healthTimer !== null) {
      window.clearInterval(this.healthTimer);
      this.healthTimer = null;
    }
  }
  setStatus(status, detail) {
    this.status = status;
    this.detail = detail;
    if (status !== "error") this.lastError = null;
    if (status === "loading" || status === "starting") {
      this.startLoadingTicker(detail);
    } else {
      this.stopLoadingTicker();
    }
    if (status === "ready") {
      this.readyAt = Date.now();
      this.startHealthWatch();
    } else {
      this.stopHealthWatch();
    }
    send({ type: "offscreen:status", status, detail });
  }
  fail(error) {
    this.stopLoadingTicker();
    this.stopHealthWatch();
    this.lastError = errorMessage(error);
    this.status = "error";
    this.detail = this.lastError;
    this.progress = null;
    send({
      type: "offscreen:status",
      status: "error",
      detail: this.lastError,
      error: this.lastError
    });
  }
}
function defaultDetail(status) {
  switch (status) {
    case "idle":
      return "Idle";
    case "starting":
      return "Starting…";
    case "loading":
      return "Loading model…";
    case "ready":
      return "Captions on";
    case "error":
      return "Error";
  }
}
const host = new OffscreenHost();
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!isOffscreenMessage(message)) return false;
  const request = message;
  switch (request.type) {
    case "offscreen:start":
      void host.start(request.streamId, request.settings);
      sendResponse({ ok: true });
      return false;
    case "offscreen:stop":
      void host.stop().finally(() => sendResponse({ ok: true }));
      return true;
    case "offscreen:update-settings":
      void host.updateSettings(request.settings);
      sendResponse({ ok: true });
      return false;
    case "offscreen:get-state":
      sendResponse({ ok: true, state: host.getState() });
      return false;
    default:
      return false;
  }
});
send({ type: "offscreen:status", status: "idle", detail: "Idle" });
