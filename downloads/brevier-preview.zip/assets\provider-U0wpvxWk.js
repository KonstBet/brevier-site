import { S as SUPPORTED_LANGUAGES, h as PARAKEET_TDT_LANGUAGE_CODES, c as PARAKEET_TDT_MODEL, P as PARAKEET_JA_MODEL, Q as QWEN_MODEL, q as qwenModelFor, s as spokenLanguage, e as errorMessage, j as supportsQwenLanguage, k as supportsParakeetTdtLanguage, l as supportsParakeetLanguage, D as DEFAULT_QWEN_MODEL } from "./settings-HWqrYUVe.js";
import { t as translationLanguageName } from "./translation-languages-rIHGiGRb.js";
const MEASURED_TDT_LANGUAGES = /* @__PURE__ */ new Set(["en", "de", "fr", "es", "it"]);
const BEST_MODEL_BY_LANGUAGE = SUPPORTED_LANGUAGES.map((language) => {
  if (PARAKEET_TDT_LANGUAGE_CODES.includes(language.code)) {
    return {
      code: language.code,
      name: language.name,
      engine: "parakeet-tdt",
      model: PARAKEET_TDT_MODEL.id,
      sizeMB: PARAKEET_TDT_MODEL.sizeMB,
      evidence: MEASURED_TDT_LANGUAGES.has(language.code) ? "measured" : "catalog"
    };
  }
  if (language.code === "ja") {
    return {
      code: language.code,
      name: language.name,
      engine: "parakeet",
      model: PARAKEET_JA_MODEL.id,
      sizeMB: PARAKEET_JA_MODEL.sizeMB,
      evidence: "measured"
    };
  }
  return {
    code: language.code,
    name: language.name,
    engine: "qwen",
    model: QWEN_MODEL.id,
    sizeMB: QWEN_MODEL.sizeMB,
    evidence: "catalog"
  };
});
function bestModelFor(code) {
  return BEST_MODEL_BY_LANGUAGE.find((entry) => entry.code === code);
}
class DelegatingEngine {
  inner = null;
  start() {
    return this.inner?.start() ?? Promise.resolve();
  }
  pushAudio(samples, sampleRate) {
    this.inner?.pushAudio(samples, sampleRate);
  }
  stop() {
    return this.inner?.stop() ?? Promise.resolve();
  }
  dispose() {
    return this.inner?.dispose() ?? Promise.resolve();
  }
}
const STOP_TIMEOUT_MS = 3e4;
const INIT_STALL_MS$1 = 12e4;
let lineSessionCounter = 0;
class GpuAsrEngine {
  constructor(id, resolveConfig) {
    this.resolveConfig = resolveConfig;
    this.id = id;
  }
  id;
  worker = null;
  context = null;
  ready = false;
  disposed = false;
  label = "";
  pendingInit = null;
  initTimer = null;
  linePrefix = String(++lineSessionCounter);
  stopWaiters = /* @__PURE__ */ new Map();
  nextStopId = 1;
  async initialize(context) {
    this.context = context;
    this.disposed = false;
    const config = this.resolveConfig(context);
    this.label = config.label;
    context.events.onStatus("loading", `Preparing ${config.label}…`);
    const worker = new Worker(new URL(
      /* @vite-ignore */
      "/assets/worker-UAMMIFPh.js",
      import.meta.url
    ), {
      type: "module"
    });
    this.worker = worker;
    worker.onmessage = (event) => this.handleMessage(event.data);
    worker.onerror = (event) => {
      const error = new Error(event.message || `The ${config.label} worker failed to load.`);
      const pending = this.pendingInit;
      if (pending) {
        this.pendingInit = null;
        this.clearInitTimer();
        pending.reject(error);
        return;
      }
      context.events.onError(error);
    };
    const ortWasmBaseUrl = new URL("/ort/", globalThis.location?.href ?? "http://localhost/").href;
    try {
      await new Promise((resolve, reject) => {
        const id = 1;
        this.pendingInit = { resolve, reject };
        this.armInitTimeout();
        worker.postMessage({
          type: "init",
          id,
          language: config.language,
          family: config.family,
          label: config.label,
          model: config.model,
          dtype: config.dtype,
          sizeMB: config.sizeMB,
          cpuSizeMB: config.cpuSizeMB,
          cpuDtype: config.cpuDtype,
          linePrefix: this.linePrefix,
          ortWasmBaseUrl
        });
      });
    } finally {
      this.clearInitTimer();
    }
    if (this.disposed) {
      throw new Error("The engine stopped before it finished loading.");
    }
    this.ready = true;
  }
  start() {
    return Promise.resolve();
  }
  pushAudio(samples, sampleRate) {
    if (!this.worker || !this.ready) return;
    this.worker.postMessage({ type: "audio", samples, sampleRate });
  }
  stop() {
    const worker = this.worker;
    if (!worker || !this.ready) return Promise.resolve();
    return new Promise((resolve) => {
      const id = this.nextStopId++;
      const timer = setTimeout(() => {
        this.stopWaiters.delete(id);
        resolve();
      }, STOP_TIMEOUT_MS);
      this.stopWaiters.set(id, () => {
        clearTimeout(timer);
        resolve();
      });
      worker.postMessage({ type: "stop", id });
    });
  }
  dispose() {
    this.disposed = true;
    this.clearInitTimer();
    const pending = this.pendingInit;
    this.pendingInit = null;
    pending?.reject(new Error("The engine stopped before it finished loading."));
    const worker = this.worker;
    this.worker = null;
    this.ready = false;
    try {
      worker?.terminate();
    } catch {
    }
    return Promise.resolve();
  }
  armInitTimeout() {
    this.clearInitTimer();
    this.initTimer = setTimeout(() => {
      this.initTimer = null;
      const pending = this.pendingInit;
      this.pendingInit = null;
      void this.dispose();
      pending?.reject(
        new Error(
          "The speech model stalled while loading. Check your connection and click Start again."
        )
      );
    }, INIT_STALL_MS$1);
  }
  clearInitTimer() {
    if (this.initTimer !== null) {
      clearTimeout(this.initTimer);
      this.initTimer = null;
    }
  }
  handleMessage(message) {
    if (this.disposed) return;
    switch (message.type) {
      case "ready":
        this.clearInitTimer();
        this.context?.events.onStatus("ready", `${this.label} ready`);
        this.context?.events.onProgress(null);
        this.pendingInit?.resolve();
        this.pendingInit = null;
        return;
      case "progress":
        if (this.pendingInit) this.armInitTimeout();
        this.context?.events.onProgress({
          loaded: message.fraction === null ? 0 : Math.round(message.fraction * 100),
          total: message.fraction === null ? null : 100,
          file: message.file || `${this.label} model`,
          model: message.model ?? this.label,
          sizeMB: message.sizeMB
        });
        return;
      case "caption":
        this.context?.events.onCaption({
          kind: message.kind ?? "final",
          text: message.text,
          at: Date.now(),
          ...message.lineId ? { lineId: message.lineId } : {},
          ...message.provisional ? { provisional: true } : {}
        });
        return;
      case "stopped": {
        const waiter = this.stopWaiters.get(message.id);
        if (waiter) {
          this.stopWaiters.delete(message.id);
          waiter();
        }
        return;
      }
      case "error": {
        const error = new Error(message.message);
        if (message.id === void 0) {
          console.error("[brevier] ASR worker error", message.message);
          this.context?.events.onError(error);
          return;
        }
        this.clearInitTimer();
        this.pendingInit?.reject(error);
        this.pendingInit = null;
        return;
      }
    }
  }
}
class ParakeetEngine extends GpuAsrEngine {
  constructor() {
    super("parakeet", () => ({
      label: "Parakeet Japanese",
      model: PARAKEET_JA_MODEL.id,
      family: "parakeet",
      dtype: PARAKEET_JA_MODEL.dtype,
      sizeMB: PARAKEET_JA_MODEL.sizeMB,
      cpuSizeMB: PARAKEET_JA_MODEL.cpuSizeMB,
      cpuDtype: PARAKEET_JA_MODEL.cpuDtype
    }));
  }
}
class QwenEngine extends GpuAsrEngine {
  constructor() {
    super("qwen", (context) => {
      const model = qwenModelFor(context.settings.qwenModel);
      return {
        label: `Qwen3-ASR ${model.label}`,
        model: model.id,
        family: "qwen",
        language: context.settings.language,
        sizeMB: model.sizeMB
      };
    });
  }
}
class ParakeetTdtEngine extends GpuAsrEngine {
  constructor() {
    super("parakeet-tdt", () => ({
      label: "Parakeet TDT",
      model: PARAKEET_TDT_MODEL.id,
      family: "parakeet-tdt",
      sizeMB: PARAKEET_TDT_MODEL.sizeMB,
      cpuSizeMB: PARAKEET_TDT_MODEL.cpuSizeMB
    }));
  }
}
const ENGINE_FACTORIES = {
  parakeet: () => new ParakeetEngine(),
  "parakeet-tdt": () => new ParakeetTdtEngine(),
  qwen: () => new QwenEngine()
};
function autoEngineOrder(language) {
  const primary = bestModelFor(language)?.engine;
  const candidates = primary ? [primary, "qwen", "parakeet-tdt", "parakeet"] : ["qwen", "parakeet-tdt", "parakeet"];
  const order = [];
  for (const id of candidates) {
    if (order.includes(id)) continue;
    if (id === "qwen" && !supportsQwenLanguage(language)) continue;
    if (id === "parakeet-tdt" && !supportsParakeetTdtLanguage(language)) continue;
    if (id === "parakeet" && !supportsParakeetLanguage(language)) continue;
    order.push(id);
  }
  return order;
}
function autoSettings(settings) {
  return settings.qwenModel === DEFAULT_QWEN_MODEL ? settings : { ...settings, qwenModel: DEFAULT_QWEN_MODEL };
}
class AutoEngine extends DelegatingEngine {
  id = "auto";
  /** Inner engine still initializing; dispose must be able to cancel it. */
  pending = null;
  disposed = false;
  async initialize(context) {
    this.disposed = false;
    const language = spokenLanguage(context.settings);
    const order = autoEngineOrder(language);
    const settings = autoSettings(context.settings);
    for (const id of order) {
      if (this.disposed) return;
      const engine = ENGINE_FACTORIES[id]();
      this.pending = engine;
      try {
        await engine.initialize({ ...context, settings });
        this.pending = null;
        if (this.disposed) {
          await engine.dispose();
          return;
        }
        this.inner = engine;
        return;
      } catch (error) {
        this.pending = null;
        await engine.dispose();
        if (this.disposed) return;
        const name = id === "qwen" ? "Qwen3-ASR" : id;
        context.events.onLog?.(
          `The ${name} engine is unavailable on this machine; trying the next one: ${errorMessage(error)}`
        );
      }
    }
    if (this.disposed) return;
    throw new Error(
      order.length === 0 ? `No on-device engine supports ${language}. Pick another language.` : "No speech engine could start on this machine."
    );
  }
  dispose() {
    this.disposed = true;
    const pending = this.pending;
    const inner = this.inner;
    this.pending = null;
    this.inner = null;
    return Promise.all([
      pending ? pending.dispose() : Promise.resolve(),
      inner ? inner.dispose() : Promise.resolve()
    ]).then(() => void 0);
  }
}
const registry = new Map([
  ["auto", () => new AutoEngine()],
  ...Object.entries(ENGINE_FACTORIES)
]);
function createEngine(id) {
  const factory = registry.get(id);
  if (!factory) {
    throw new Error(`Unknown transcription engine: ${id}`);
  }
  return factory();
}
const TRANSLATE_TIMEOUT_MS = 6e4;
const INIT_STALL_MS = 12e4;
const PROMPT_TIMEOUT_MS = 3e4;
class LocalLlmTranslationProvider {
  constructor(model) {
    this.model = model;
    this.id = model.providerId;
  }
  id;
  worker = null;
  context = null;
  pending = /* @__PURE__ */ new Map();
  /** Serializes generations so a slow line cannot stack up GPU work. */
  translateChain = Promise.resolve();
  nextId = 1;
  ready = false;
  prompt = "";
  get available() {
    return this.worker !== null && this.ready;
  }
  async initialize(context) {
    this.context = context;
    if (context.sourceLanguage === context.targetLanguage) {
      throw new Error("The translation language is the same as the spoken language.");
    }
    const prompt = this.model.buildPrompt(context.targetLanguage);
    const worker = new Worker(new URL(
      /* @vite-ignore */
      "/assets/translation-worker-DOz8Sg_B.js",
      import.meta.url
    ), {
      type: "module"
    });
    this.worker = worker;
    worker.onmessage = (event) => this.handleMessage(event.data);
    worker.onerror = (event) => {
      this.failAll(new Error(event.message || "The translation worker failed to load."));
    };
    const ortWasmBaseUrl = new URL("/ort/", globalThis.location?.href ?? "http://localhost/").href;
    await new Promise((resolve, reject) => {
      const id = this.nextId++;
      const pending = {
        resolve: () => {
          if (pending.timer !== null) clearTimeout(pending.timer);
          resolve();
        },
        reject,
        timer: null
      };
      const arm = () => {
        if (pending.timer !== null) clearTimeout(pending.timer);
        pending.timer = setTimeout(() => {
          this.pending.delete(id);
          this.dispose();
          reject(
            new Error(
              "The translation model stalled while loading. Check your connection and try again."
            )
          );
        }, INIT_STALL_MS);
      };
      pending.rearm = arm;
      this.pending.set(id, pending);
      arm();
      worker.postMessage({
        type: "init",
        id,
        repo: this.model.repo,
        prompt,
        ortWasmBaseUrl
      });
    });
    this.prompt = prompt;
    this.ready = true;
  }
  /**
   * Reuses the loaded model for a new language pair. Only the instruction
   * prompt changes, so the int4 model and its WebGPU session stay warm.
   */
  async retarget(context) {
    if (!this.worker || !this.ready) {
      throw new Error("The on-device translation model is not ready.");
    }
    if (context.sourceLanguage === context.targetLanguage) {
      throw new Error("The translation language is the same as the spoken language.");
    }
    this.context = context;
    const prompt = this.model.buildPrompt(context.targetLanguage);
    if (prompt === this.prompt) return;
    const id = this.nextId++;
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error("Updating the translation prompt timed out."));
      }, PROMPT_TIMEOUT_MS);
      this.pending.set(id, { resolve: () => resolve(), reject, timer });
      this.worker?.postMessage({
        type: "set-prompt",
        id,
        prompt
      });
    });
    this.prompt = prompt;
  }
  translate(text, onPartial) {
    if (!this.worker || !this.ready) {
      return Promise.reject(new Error("The on-device translation model is not ready."));
    }
    const run = this.translateChain.then(() => this.requestTranslation(text, onPartial));
    this.translateChain = run.catch(() => void 0);
    return run;
  }
  requestTranslation(text, onPartial) {
    if (!this.worker || !this.ready) {
      return Promise.reject(new Error("The on-device translation model is not ready."));
    }
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      const timer = setTimeout(() => {
        this.pending.delete(id);
        this.dispose();
        reject(new Error("The translation request timed out. Restarting translation…"));
      }, TRANSLATE_TIMEOUT_MS);
      this.pending.set(id, { resolve, reject, timer, onPartial });
      this.worker?.postMessage({ type: "translate", id, text });
    });
  }
  dispose() {
    this.failAll(new Error("Translation stopped."));
    const worker = this.worker;
    this.worker = null;
    this.ready = false;
    try {
      worker?.terminate();
    } catch {
    }
  }
  handleMessage(message) {
    if (message.type === "progress") {
      for (const pending2 of this.pending.values()) pending2.rearm?.();
      this.context?.onProgress({
        fraction: message.fraction,
        detail: message.file ? `${this.model.label} · ${message.file}` : this.model.label
      });
      return;
    }
    if (message.type === "partial") {
      this.pending.get(message.id)?.onPartial?.(message.text);
      return;
    }
    const pending = this.pending.get(message.id);
    if (!pending) return;
    this.pending.delete(message.id);
    if (pending.timer !== null) clearTimeout(pending.timer);
    switch (message.type) {
      case "ready":
        this.context?.onProgress(null);
        pending.resolve("");
        break;
      case "prompt-set":
        pending.resolve("");
        break;
      case "result":
        pending.resolve(message.text);
        break;
      case "error":
        pending.reject(new Error(message.message));
        break;
    }
  }
  failAll(error) {
    for (const pending of this.pending.values()) {
      if (pending.timer !== null) clearTimeout(pending.timer);
      pending.reject(error);
    }
    this.pending.clear();
  }
}
function buildHyMtInstruction(targetLanguage) {
  return `Translate the following text into ${translationLanguageName(
    targetLanguage
  )}. Note that you should only output the translated result without any additional explanation:

`;
}
const HYMT3_MODEL_ID = "konstbet/Hy-MT3-1.8B-ONNX";
function buildHymt3Prompt(targetLanguage) {
  return buildHyMtInstruction(targetLanguage);
}
const HYMT3_MODEL = {
  providerId: "hymt3",
  repo: HYMT3_MODEL_ID,
  label: "Hy-MT3 1.8B",
  buildPrompt: buildHymt3Prompt
};
class Hymt3TranslationProvider extends LocalLlmTranslationProvider {
  constructor() {
    super(HYMT3_MODEL);
  }
}
export {
  Hymt3TranslationProvider as H,
  bestModelFor as b,
  createEngine as c
};
