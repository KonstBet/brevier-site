function isOffscreenMessage(message) {
  return typeof message === "object" && message !== null && message.target === "offscreen";
}
function isPopupRequest(message) {
  if (typeof message !== "object" || message === null) return false;
  const type = message.type;
  return type === "popup:start" || type === "popup:stop" || type === "popup:get-state" || type === "popup:settings-changed" || type === "popup:get-entitlement" || type === "popup:open-upgrade" || type === "popup:open-login";
}
function isContentMessage(message) {
  return typeof message === "object" && message !== null && message.type === "content:ready";
}
function isOffscreenEvent(message) {
  if (typeof message !== "object" || message === null) return false;
  const type = message.type;
  if (type === "offscreen:audio") {
    return typeof message.level === "number";
  }
  return type === "offscreen:status" || type === "offscreen:progress" || type === "offscreen:caption" || type === "offscreen:translation" || type === "offscreen:state";
}
function errorMessage(error) {
  if (error instanceof Error) return error.message;
  return String(error);
}
export {
  isOffscreenEvent as a,
  isContentMessage as b,
  isOffscreenMessage as c,
  errorMessage as e,
  isPopupRequest as i
};
