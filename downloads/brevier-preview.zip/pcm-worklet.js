/**
 * AudioWorklet processor that taps the captured tab audio and forwards mono
 * Float32 PCM to the offscreen document.
 *
 * It deliberately does no resampling: the transcription engines accept
 * arbitrary sample rates, so the source rate is forwarded along with each
 * chunk.
 *
 * This file is loaded directly via chrome.runtime.getURL() and must stay a
 * standalone, dependency-free classic worklet module.
 */
class PcmCaptureProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const configured = options?.processorOptions?.chunkSize;
    this.chunkSize = Number.isFinite(configured) && configured > 0 ? configured : 2048;
    this.buffer = new Float32Array(this.chunkSize);
    this.fill = 0;
  }

  process(inputs) {
    const input = inputs[0];
    if (!input || input.length === 0 || !input[0]) {
      return true;
    }

    const frameCount = input[0].length;
    const channels = input.length;

    for (let i = 0; i < frameCount; i++) {
      let sample = 0;
      for (let c = 0; c < channels; c++) {
        sample += input[c][i];
      }
      this.buffer[this.fill++] = sample / channels;

      if (this.fill === this.chunkSize) {
        const chunk = this.buffer;
        this.port.postMessage(chunk, [chunk.buffer]);
        this.buffer = new Float32Array(this.chunkSize);
        this.fill = 0;
      }
    }

    return true;
  }
}

registerProcessor('pcm-capture', PcmCaptureProcessor);
