import { W as WHISPER_LANGUAGES, P as PARAKEET_MODEL, a as WHISPER_MODEL_SIZE_MB, b as WHISPER_MODEL, M as MOONSHINE_LANGUAGES, g as getMoonshineLanguage, r as resolveArch, c as getModelChoice, f as getWhisperLanguage, s as spokenLanguage, h as supportsMoonshineLanguage } from "./region-C_na-waw.js";
import { t as translationLanguageName } from "./translation-languages-BWIVOYyr.js";
function moonshineFallback(code) {
  const language = MOONSHINE_LANGUAGES.find((entry) => entry.code === code);
  if (!language) return void 0;
  const choice = language.models.find((model) => model.default) ?? language.models[0];
  return { engine: "moonshine", arch: choice.arch, sizeMB: choice.sizeMB };
}
const BEST_MODEL_BY_LANGUAGE = WHISPER_LANGUAGES.map((language) => {
  const cpu = moonshineFallback(language.code);
  if (language.code === "en") {
    return {
      code: language.code,
      name: language.name,
      engine: "parakeet",
      model: PARAKEET_MODEL.id,
      sizeMB: PARAKEET_MODEL.sizeMB,
      ...cpu ? { cpu } : {},
      evidence: "measured"
    };
  }
  return {
    code: language.code,
    name: language.name,
    engine: "whisper",
    model: WHISPER_MODEL,
    sizeMB: WHISPER_MODEL_SIZE_MB,
    ...cpu ? { cpu } : {},
    evidence: language.code === "ja" ? "measured" : "catalog"
  };
});
function bestModelFor(code) {
  return BEST_MODEL_BY_LANGUAGE.find((entry) => entry.code === code);
}
class DelegatingEngine {
  inner = null;
  start() {
    return this.inner?.start() ?? Promise.resolve();
  }
  pushAudio(samples, sampleRate) {
    this.inner?.pushAudio(samples, sampleRate);
  }
  stop() {
    return this.inner?.stop() ?? Promise.resolve();
  }
  dispose() {
    return this.inner?.dispose() ?? Promise.resolve();
  }
}
const STOP_TIMEOUT_MS = 3e4;
async function webGpuAvailable() {
  const gpu = navigator.gpu;
  if (!gpu) return false;
  try {
    return await gpu.requestAdapter() !== null;
  } catch {
    return false;
  }
}
class GpuAsrEngine {
  constructor(id, resolveConfig) {
    this.resolveConfig = resolveConfig;
    this.id = id;
  }
  id;
  worker = null;
  context = null;
  ready = false;
  label = "";
  pendingInit = null;
  stopWaiters = /* @__PURE__ */ new Map();
  nextStopId = 1;
  async initialize(context) {
    this.context = context;
    const config = this.resolveConfig(context);
    this.label = config.label;
    context.events.onStatus("loading", `Loading ${config.label} model…`);
    const worker = new Worker(new URL(
      /* @vite-ignore */
      "/assets/whisper-worker-BaGOqNMI.js",
      import.meta.url
    ), {
      type: "module"
    });
    this.worker = worker;
    worker.onmessage = (event) => this.handleMessage(event.data);
    worker.onerror = (event) => {
      context.events.onError(
        new Error(event.message || `The ${config.label} worker failed to load.`)
      );
    };
    const ortWasmBaseUrl = new URL("/ort/", globalThis.location?.href ?? "http://localhost/").href;
    await new Promise((resolve, reject) => {
      const id = 1;
      this.pendingInit = { resolve, reject };
      worker.postMessage({
        type: "init",
        id,
        language: config.language,
        family: config.family,
        label: config.label,
        model: config.model,
        dtype: config.dtype,
        ortWasmBaseUrl
      });
    });
    this.ready = true;
  }
  start() {
    return Promise.resolve();
  }
  pushAudio(samples, sampleRate) {
    if (!this.worker || !this.ready) return;
    this.worker.postMessage({ type: "audio", samples, sampleRate });
  }
  stop() {
    const worker = this.worker;
    if (!worker || !this.ready) return Promise.resolve();
    return new Promise((resolve) => {
      const id = this.nextStopId++;
      const timer = setTimeout(() => {
        this.stopWaiters.delete(id);
        resolve();
      }, STOP_TIMEOUT_MS);
      this.stopWaiters.set(id, () => {
        clearTimeout(timer);
        resolve();
      });
      worker.postMessage({ type: "stop", id });
    });
  }
  dispose() {
    const worker = this.worker;
    this.worker = null;
    this.ready = false;
    try {
      worker?.terminate();
    } catch {
    }
    return Promise.resolve();
  }
  handleMessage(message) {
    switch (message.type) {
      case "ready":
        this.context?.events.onStatus("ready", `${this.label} ready`);
        this.context?.events.onProgress(null);
        this.pendingInit?.resolve();
        this.pendingInit = null;
        return;
      case "progress":
        this.context?.events.onProgress({
          loaded: message.fraction === null ? 0 : Math.round(message.fraction * 100),
          total: message.fraction === null ? null : 100,
          file: message.file ? `Downloading ${message.file}` : `Downloading ${this.label} model`
        });
        return;
      case "caption":
        this.context?.events.onCaption({
          kind: message.kind ?? "final",
          text: message.text,
          at: Date.now(),
          ...message.lineId ? { lineId: message.lineId } : {}
        });
        return;
      case "stopped": {
        const waiter = this.stopWaiters.get(message.id);
        if (waiter) {
          this.stopWaiters.delete(message.id);
          waiter();
        }
        return;
      }
      case "error": {
        const error = new Error(message.message);
        if (message.id === void 0) {
          this.context?.events.onError(error);
          return;
        }
        this.pendingInit?.reject(error);
        this.pendingInit = null;
        return;
      }
    }
  }
}
const ARCH_ENUM_KEY = {
  tiny: "Tiny",
  base: "Base",
  tiny_streaming: "TinyStreaming",
  base_streaming: "BaseStreaming",
  small_streaming: "SmallStreaming",
  medium_streaming: "MediumStreaming"
};
const GPU_WEBGPU_DTYPE = { encoder_model: "fp32", decoder_model_merged: "q4" };
const GPU_FP32_DTYPE = { encoder_model: "fp32", decoder_model_merged: "fp32" };
const GPU_MODELS = {
  en: {
    tiny: { id: "onnx-community/moonshine-tiny-ONNX", dtype: GPU_WEBGPU_DTYPE },
    base: { id: "onnx-community/moonshine-base-ONNX", dtype: GPU_WEBGPU_DTYPE }
  },
  ja: {
    tiny: { id: "wmoto-ai/moonshine-tiny-ja-ONNX", dtype: GPU_FP32_DTYPE },
    base: { id: "onnx-community/moonshine-base-ja-ONNX", dtype: GPU_WEBGPU_DTYPE }
  },
  ko: { tiny: { id: "onnx-community/moonshine-tiny-ko-ONNX", dtype: GPU_WEBGPU_DTYPE } },
  zh: { base: { id: "onnx-community/moonshine-base-zh-ONNX", dtype: GPU_WEBGPU_DTYPE } }
};
function moonshineGpuModel(language, arch) {
  const models = GPU_MODELS[language];
  if (!models) return null;
  if (arch === "tiny" || arch === "tiny_streaming") return models.tiny ?? null;
  if (arch === "base" || arch === "base_streaming") return models.base ?? null;
  return null;
}
function moonshineBaseUrl() {
  return chrome.runtime.getURL("moonshine/");
}
const SANDBOX_PAGE = "sandbox/sandbox.html";
const MODEL_CACHE = "moonshine-models-v1";
const FIRST_EVENT_TIMEOUT_MS = 3e4;
const STALL_TIMEOUT_MS = 9e4;
const STOP_ACK_TIMEOUT_MS = 3e3;
class MoonshineEngine extends DelegatingEngine {
  id = "moonshine";
  async initialize(context) {
    const language = getMoonshineLanguage(context.settings.moonshine.language);
    const arch = resolveArch(language.code, context.settings.moonshine.modelArch);
    const gpuModel = await webGpuAvailable() ? moonshineGpuModel(language.code, arch) : null;
    if (gpuModel) {
      const gpu = new GpuAsrEngine("moonshine", () => ({
        label: "Moonshine (GPU)",
        model: gpuModel.id,
        family: "moonshine",
        dtype: gpuModel.dtype
      }));
      try {
        await gpu.initialize(context);
        this.inner = gpu;
        return;
      } catch (error) {
        await gpu.dispose();
        context.events.onLog?.(
          `Moonshine GPU path failed, using CPU: ${error instanceof Error ? error.message : String(error)}`
        );
      }
    }
    const wasm = new MoonshineWasmEngine();
    this.inner = wasm;
    await wasm.initialize(context);
  }
}
class MoonshineWasmEngine {
  id = "moonshine";
  iframe = null;
  events = null;
  running = false;
  ready = false;
  language = "en";
  arch = "MediumStreaming";
  nextRequestId = 1;
  pendingFiles = /* @__PURE__ */ new Map();
  pendingInit = null;
  pendingStop = null;
  stallTimer = null;
  firstEventTimer = null;
  async initialize(context) {
    const { settings, events } = context;
    this.events = events;
    const language = getMoonshineLanguage(settings.moonshine.language);
    const archId = resolveArch(language.code, settings.moonshine.modelArch);
    const model = getModelChoice(language.code, archId);
    this.language = language.code;
    this.arch = ARCH_ENUM_KEY[archId];
    events.onStatus(
      "loading",
      `Preparing ${language.name} model (${model.sizeMB} MB first run, cached afterwards)…`
    );
    const iframe = document.createElement("iframe");
    iframe.src = chrome.runtime.getURL(SANDBOX_PAGE);
    iframe.hidden = true;
    iframe.setAttribute("aria-hidden", "true");
    document.body.append(iframe);
    this.iframe = iframe;
    window.addEventListener("message", this.onMessage);
    await new Promise((resolve, reject) => {
      this.pendingInit = { resolve, reject };
      this.armFirstEventTimer();
    });
  }
  async start() {
    this.running = true;
  }
  pushAudio(samples, sampleRate) {
    if (!this.running || !this.ready || !this.iframe) return;
    try {
      this.post({ type: "audio", buffer: samples.buffer, sampleRate }, [
        samples.buffer
      ]);
    } catch (error) {
      console.warn("[brevier] failed to forward audio frame", error);
    }
  }
  async stop() {
    this.running = false;
    if (!this.iframe || !this.ready) return;
    await new Promise((resolve) => {
      this.pendingStop = resolve;
      this.post({ type: "stop" });
      window.setTimeout(() => {
        if (this.pendingStop) {
          this.pendingStop = null;
          resolve();
        }
      }, STOP_ACK_TIMEOUT_MS);
    });
  }
  async dispose() {
    this.running = false;
    this.ready = false;
    this.clearStallTimer();
    this.clearFirstEventTimer();
    window.removeEventListener("message", this.onMessage);
    if (this.iframe) {
      try {
        this.iframe.contentWindow?.postMessage({ type: "dispose" }, "*");
      } catch {
      }
      this.iframe.remove();
      this.iframe = null;
    }
    this.pendingInit?.reject(new Error("Engine disposed"));
    this.pendingInit = null;
    this.pendingStop?.();
    this.pendingStop = null;
    for (const pending of this.pendingFiles.values()) {
      pending.reject(new Error("Engine disposed"));
    }
    this.pendingFiles.clear();
  }
  post(message, transfer) {
    const target = this.iframe?.contentWindow;
    if (!target) throw new Error("Sandbox frame is not available");
    if (transfer) target.postMessage(message, "*", transfer);
    else target.postMessage(message, "*");
  }
  onMessage = (event) => {
    if (!this.iframe || event.source !== this.iframe.contentWindow) return;
    const message = event.data;
    if (!message || typeof message !== "object") return;
    switch (message.type) {
      case "sandbox-ready":
        void this.sendInit();
        return;
      case "fetch-files":
        void this.serveFiles(message.requestId, message.files);
        return;
      case "log":
        this.clearFirstEventTimer();
        if (this.stallTimer === null) this.armStallTimer();
        console.info("[brevier][moonshine]", message.message);
        this.events?.onLog?.(message.message);
        return;
      case "ready":
        this.clearFirstEventTimer();
        this.clearStallTimer();
        this.ready = true;
        this.events?.onProgress(null);
        console.info(
          `[brevier] Moonshine ready (sandbox, single-threaded compatibility mode)`
        );
        this.pendingInit?.resolve();
        this.pendingInit = null;
        this.events?.onStatus("ready", "Captions on");
        return;
      case "interim":
        this.events?.onCaption({
          kind: "interim",
          text: message.text,
          lineId: message.lineId,
          at: Date.now()
        });
        return;
      case "final":
        this.events?.onCaption({
          kind: "final",
          text: message.text,
          lineId: message.lineId,
          latencyMs: message.latencyMs,
          at: Date.now()
        });
        return;
      case "stopped":
        this.pendingStop?.();
        this.pendingStop = null;
        return;
      case "error":
        this.fail(new Error(message.message));
        return;
    }
  };
  /** Reads the WASM binary and hands it to the sandbox. */
  async sendInit() {
    try {
      const response = await fetch(`${moonshineBaseUrl()}moonshine.wasm`);
      if (!response.ok) {
        throw new Error(`Could not read moonshine.wasm (${response.status})`);
      }
      const wasm = await response.arrayBuffer();
      this.post({ type: "init", wasm, language: this.language, arch: this.arch }, [wasm]);
    } catch (error) {
      this.fail(error instanceof Error ? error : new Error(String(error)));
    }
  }
  /** Fetches model files for the sandbox, with Cache API persistence. */
  async serveFiles(requestId, files) {
    try {
      const cache = await openModelCache();
      const totalKnown = files.every((file) => typeof file.size === "number");
      const total = totalKnown ? files.reduce((sum, file) => sum + (file.size ?? 0), 0) : null;
      const fetched = [];
      let loaded = 0;
      for (const file of files) {
        const bytes = await fetchFileWithProgress(file.url, cache, (fileLoaded) => {
          this.events?.onProgress({
            loaded: loaded + fileLoaded,
            total,
            file: file.name
          });
        });
        fetched.push({ name: file.name, buffer: bytes.buffer });
        loaded += bytes.byteLength;
        this.events?.onProgress({ loaded, total, file: file.name });
      }
      this.post(
        { type: "files", requestId, files: fetched },
        fetched.map((file) => file.buffer)
      );
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.post({ type: "files-error", requestId, error: message });
    }
  }
  fail(error) {
    this.clearStallTimer();
    this.clearFirstEventTimer();
    if (this.pendingInit) {
      const pending = this.pendingInit;
      this.pendingInit = null;
      pending.reject(error);
      return;
    }
    this.events?.onError(error);
  }
  armFirstEventTimer() {
    this.clearFirstEventTimer();
    this.firstEventTimer = window.setTimeout(() => {
      this.fail(
        new Error("The speech engine sandbox did not respond. Reload the extension and try again.")
      );
    }, FIRST_EVENT_TIMEOUT_MS);
  }
  clearFirstEventTimer() {
    if (this.firstEventTimer !== null) {
      window.clearTimeout(this.firstEventTimer);
      this.firstEventTimer = null;
    }
  }
  armStallTimer() {
    this.clearStallTimer();
    this.stallTimer = window.setTimeout(() => {
      this.fail(
        new Error("Timed out while loading the speech model. Check your connection and try again.")
      );
    }, STALL_TIMEOUT_MS);
  }
  clearStallTimer() {
    if (this.stallTimer !== null) {
      window.clearTimeout(this.stallTimer);
      this.stallTimer = null;
    }
  }
}
async function openModelCache() {
  try {
    if (typeof caches !== "undefined") {
      return await caches.open(MODEL_CACHE);
    }
  } catch {
  }
  return null;
}
async function fetchFileWithProgress(url, cache, onProgress) {
  if (cache) {
    const hit = await cache.match(url);
    if (hit) {
      const buffer = await hit.arrayBuffer();
      onProgress(buffer.byteLength);
      return new Uint8Array(buffer);
    }
  }
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download ${url}: ${response.status} ${response.statusText}`);
  }
  if (cache) {
    await cache.put(url, response.clone());
  }
  if (!response.body) {
    const buffer = await response.arrayBuffer();
    onProgress(buffer.byteLength);
    return new Uint8Array(buffer);
  }
  const reader = response.body.getReader();
  const chunks = [];
  let loaded = 0;
  for (; ; ) {
    const { done, value } = await reader.read();
    if (done) break;
    if (value) {
      chunks.push(value);
      loaded += value.byteLength;
      onProgress(loaded);
    }
  }
  const merged = new Uint8Array(loaded);
  let offset = 0;
  for (const chunk of chunks) {
    merged.set(chunk, offset);
    offset += chunk.byteLength;
  }
  return merged;
}
class ParakeetEngine extends GpuAsrEngine {
  constructor() {
    super("parakeet", () => ({
      label: "Parakeet",
      model: PARAKEET_MODEL.id,
      family: "parakeet",
      dtype: PARAKEET_MODEL.dtype
    }));
  }
}
function whisperLanguage(code) {
  return getWhisperLanguage(code)?.name.toLowerCase();
}
class WhisperEngine extends GpuAsrEngine {
  constructor() {
    super("whisper", (context) => ({
      label: "Whisper",
      model: WHISPER_MODEL,
      family: "whisper",
      language: whisperLanguage(context.settings.whisper.language)
    }));
  }
}
const ENGINE_FACTORIES = {
  moonshine: () => new MoonshineEngine(),
  parakeet: () => new ParakeetEngine(),
  whisper: () => new WhisperEngine()
};
function autoEngineOrder(language, webGpu) {
  if (!webGpu) {
    return supportsMoonshineLanguage(language) ? ["moonshine"] : [];
  }
  const primary = bestModelFor(language)?.engine ?? "whisper";
  const order = [primary];
  if (primary !== "whisper") order.push("whisper");
  if (supportsMoonshineLanguage(language)) order.push("moonshine");
  return order;
}
function describe(error) {
  return error instanceof Error ? error.message : String(error);
}
class AutoEngine extends DelegatingEngine {
  id = "auto";
  async initialize(context) {
    const language = spokenLanguage(context.settings);
    const order = autoEngineOrder(language, await webGpuAvailable());
    for (const id of order) {
      const engine = ENGINE_FACTORIES[id]();
      try {
        await engine.initialize(context);
        this.inner = engine;
        return;
      } catch (error) {
        await engine.dispose();
        context.events.onLog?.(
          `The ${id} engine is unavailable on this machine; trying the next one: ${describe(error)}`
        );
      }
    }
    throw new Error(
      order.length === 0 ? `No on-device engine supports ${language} on this machine yet. Pick another language.` : "No speech engine could start on this machine."
    );
  }
}
const registry = new Map([
  ["auto", () => new AutoEngine()],
  ...Object.entries(ENGINE_FACTORIES)
]);
function createEngine(id) {
  const factory = registry.get(id);
  if (!factory) {
    throw new Error(`Unknown transcription engine: ${id}`);
  }
  return factory();
}
function buildHunyuanPrompt(targetLanguage) {
  return `Translate the following segment into ${translationLanguageName(
    targetLanguage
  )}, without additional explanation.

`;
}
const TRANSLATE_TIMEOUT_MS = 6e4;
class HunyuanTranslationProvider {
  id = "hunyuan";
  worker = null;
  context = null;
  pending = /* @__PURE__ */ new Map();
  nextId = 1;
  ready = false;
  async initialize(context) {
    this.context = context;
    if (context.sourceLanguage === context.targetLanguage) {
      throw new Error("The translation language is the same as the spoken language.");
    }
    const prompt = buildHunyuanPrompt(context.targetLanguage);
    const worker = new Worker(new URL(
      /* @vite-ignore */
      "/assets/hunyuan-worker-dhSTSCOE.js",
      import.meta.url
    ), {
      type: "module"
    });
    this.worker = worker;
    worker.onmessage = (event) => this.handleMessage(event.data);
    worker.onerror = (event) => {
      this.failAll(new Error(event.message || "The translation worker failed to load."));
    };
    const ortWasmBaseUrl = new URL("/ort/", globalThis.location?.href ?? "http://localhost/").href;
    await new Promise((resolve, reject) => {
      const id = this.nextId++;
      this.pending.set(id, { resolve: () => resolve(), reject, timer: null });
      worker.postMessage({
        type: "init",
        id,
        prompt,
        ortWasmBaseUrl
      });
    });
    this.ready = true;
  }
  translate(text) {
    if (!this.worker || !this.ready) {
      return Promise.reject(new Error("The on-device translation model is not ready."));
    }
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error("The translation request timed out."));
      }, TRANSLATE_TIMEOUT_MS);
      this.pending.set(id, { resolve, reject, timer });
      this.worker?.postMessage({ type: "translate", id, text });
    });
  }
  dispose() {
    this.failAll(new Error("Translation stopped."));
    const worker = this.worker;
    this.worker = null;
    this.ready = false;
    try {
      worker?.terminate();
    } catch {
    }
  }
  handleMessage(message) {
    if (message.type === "progress") {
      this.context?.onProgress({
        fraction: message.fraction,
        detail: message.file ? `Downloading ${message.file}` : "Downloading translation model"
      });
      return;
    }
    const pending = this.pending.get(message.id);
    if (!pending) return;
    this.pending.delete(message.id);
    if (pending.timer !== null) clearTimeout(pending.timer);
    switch (message.type) {
      case "ready":
        this.context?.onProgress(null);
        pending.resolve("");
        break;
      case "result":
        pending.resolve(message.text);
        break;
      case "error":
        pending.reject(new Error(message.message));
        break;
    }
  }
  failAll(error) {
    for (const pending of this.pending.values()) {
      if (pending.timer !== null) clearTimeout(pending.timer);
      pending.reject(error);
    }
    this.pending.clear();
  }
}
export {
  HunyuanTranslationProvider as H,
  bestModelFor as b,
  createEngine as c
};
