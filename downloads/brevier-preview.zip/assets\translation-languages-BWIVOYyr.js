function chromeTranslatorApi() {
  const api = globalThis.Translator;
  return api && typeof api.create === "function" ? api : null;
}
async function probeChromeTranslation(sourceLanguage, targetLanguage) {
  const api = chromeTranslatorApi();
  if (!api) return "unsupported";
  if (sourceLanguage === targetLanguage) return "unavailable";
  try {
    const availability = await api.availability({ sourceLanguage, targetLanguage });
    if (availability === "available" || availability === "downloadable" || availability === "downloading") {
      return availability;
    }
    return "unavailable";
  } catch {
    return "unavailable";
  }
}
function downloadMonitor(onFraction) {
  return (monitor) => {
    monitor.addEventListener("downloadprogress", (event) => {
      const loaded = event.loaded;
      if (typeof loaded === "number") onFraction(loaded);
    });
  };
}
async function prepareChromeTranslation(sourceLanguage, targetLanguage, onFraction) {
  const api = chromeTranslatorApi();
  if (!api) {
    throw new Error("Built-in translation is not available in this browser.");
  }
  const translator = await api.create({
    sourceLanguage,
    targetLanguage,
    monitor: onFraction ? downloadMonitor(onFraction) : void 0
  });
  try {
    translator.destroy();
  } catch {
  }
}
function friendlyError(error) {
  if (error instanceof Error && /user gesture/i.test(error.message)) {
    return new Error(
      'The translation model needs a one-time download. Open the popup and click "Prepare translation".'
    );
  }
  return error instanceof Error ? error : new Error(String(error));
}
class ChromeTranslationProvider {
  id = "chrome";
  translator = null;
  async initialize(context) {
    const api = chromeTranslatorApi();
    if (!api) {
      throw new Error(
        "Built-in translation is not available in this browser (needs desktop Chrome 138+)."
      );
    }
    const { sourceLanguage, targetLanguage } = context;
    if (sourceLanguage === targetLanguage) {
      throw new Error("The translation language is the same as the spoken language.");
    }
    const availability = await probeChromeTranslation(sourceLanguage, targetLanguage);
    if (availability === "unavailable") {
      throw new Error(
        `On-device translation from ${sourceLanguage} to ${targetLanguage} is not supported on this device.`
      );
    }
    try {
      this.translator = await api.create({
        sourceLanguage,
        targetLanguage,
        monitor: downloadMonitor((fraction) => {
          context.onProgress({ fraction, detail: "Downloading translation model" });
        })
      });
    } catch (error) {
      throw friendlyError(error);
    }
    context.onProgress(null);
  }
  translate(text) {
    const translator = this.translator;
    if (!translator) {
      return Promise.reject(new Error("Translator is not ready."));
    }
    return translator.translate(text);
  }
  dispose() {
    const translator = this.translator;
    this.translator = null;
    try {
      translator?.destroy();
    } catch {
    }
  }
}
const TRANSLATION_LANGUAGES = [
  { code: "en", name: "English" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "it", name: "Italian" },
  { code: "pt", name: "Portuguese" },
  { code: "nl", name: "Dutch" },
  { code: "pl", name: "Polish" },
  { code: "ru", name: "Russian" },
  { code: "uk", name: "Ukrainian" },
  { code: "cs", name: "Czech" },
  { code: "sk", name: "Slovak" },
  { code: "bg", name: "Bulgarian" },
  { code: "ro", name: "Romanian" },
  { code: "hu", name: "Hungarian" },
  { code: "el", name: "Greek" },
  { code: "sv", name: "Swedish" },
  { code: "no", name: "Norwegian" },
  { code: "da", name: "Danish" },
  { code: "fi", name: "Finnish" },
  { code: "tr", name: "Turkish" },
  { code: "ar", name: "Arabic" },
  { code: "he", name: "Hebrew" },
  { code: "fa", name: "Persian" },
  { code: "hi", name: "Hindi" },
  { code: "bn", name: "Bengali" },
  { code: "ta", name: "Tamil" },
  { code: "ur", name: "Urdu" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "zh", name: "Chinese (Simplified)" },
  { code: "zh-Hant", name: "Chinese (Traditional)" },
  { code: "vi", name: "Vietnamese" },
  { code: "th", name: "Thai" },
  { code: "id", name: "Indonesian" },
  { code: "ms", name: "Malay" },
  { code: "fil", name: "Filipino" },
  { code: "sw", name: "Swahili" },
  { code: "af", name: "Afrikaans" },
  { code: "is", name: "Icelandic" },
  { code: "ga", name: "Irish" },
  { code: "cy", name: "Welsh" },
  { code: "ca", name: "Catalan" },
  { code: "gl", name: "Galician" },
  { code: "eu", name: "Basque" }
];
function getTranslationLanguage(code) {
  return TRANSLATION_LANGUAGES.find((language) => language.code === code);
}
function translationLanguageName(code) {
  return getTranslationLanguage(code)?.name ?? code;
}
export {
  ChromeTranslationProvider as C,
  TRANSLATION_LANGUAGES as T,
  prepareChromeTranslation as a,
  chromeTranslatorApi as c,
  probeChromeTranslation as p,
  translationLanguageName as t
};
