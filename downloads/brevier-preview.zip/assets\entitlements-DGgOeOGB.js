import { j as defaultArchFor } from "./region-C_na-waw.js";
const TRIAL_DURATION_MS = 7 * 24 * 60 * 60 * 1e3;
const ENTITLEMENT_MAX_AGE_MS = 12 * 60 * 60 * 1e3;
const FREE_ENTITLEMENT = {
  status: "free",
  source: "none",
  checkedAt: 0,
  trialStartedAt: null,
  email: null
};
const PRO_GATE_NOTICE = "Free Pro time is used up for today — captions switched to English. It resets tomorrow, or unlock Pro for unlimited.";
const PRO_TRANSLATION_GATE_NOTICE = "Free Pro time is used up for today — switched to Chrome translation. It resets tomorrow, or unlock Pro for unlimited.";
const PRO_BOTH_GATE_NOTICE = "Free Pro time is used up for today — captions switched to English and translation switched to Chrome. It resets tomorrow, or unlock Pro for unlimited.";
const HUNYUAN_REGION_NOTICE = "Hunyuan-MT is not available in your region — translation switched to Chrome.";
const HUNYUAN_REGION_LANGUAGE_NOTICE = "Hunyuan-MT is not available in your region — captions switched to English and translation switched to Chrome.";
function pickTime(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function normalizeEntitlement(input) {
  if (typeof input !== "object" || input === null) return { ...FREE_ENTITLEMENT };
  const raw = input;
  const status = raw.status === "pro" ? "pro" : raw.status === "trial" ? "trial" : "free";
  const source = raw.source === "extpay" ? "extpay" : raw.source === "dev" ? "dev" : "none";
  return {
    status,
    source,
    checkedAt: pickTime(raw.checkedAt) ?? 0,
    trialStartedAt: pickTime(raw.trialStartedAt),
    email: typeof raw.email === "string" ? raw.email : null
  };
}
function isProEntitlement(state, now = Date.now()) {
  if (state.status === "pro") return true;
  if (state.status !== "trial" || state.trialStartedAt === null) return false;
  return now - state.trialStartedAt < TRIAL_DURATION_MS;
}
function entitlementIsStale(state, now = Date.now()) {
  return now - state.checkedAt > ENTITLEMENT_MAX_AGE_MS;
}
function gateSettings(settings, pro, hunyuanAllowed = true) {
  if (pro && hunyuanAllowed) return { settings, blocked: false, notice: null };
  const languageBlocked = settings.moonshine.language !== "en" || settings.whisper.language !== "en";
  const hunyuanSelected = settings.translation.provider === "hunyuan";
  const regionBlocked = hunyuanSelected && !hunyuanAllowed;
  const translationBlocked = hunyuanSelected && (!pro || !hunyuanAllowed);
  if (!languageBlocked && !translationBlocked) {
    return { settings, blocked: false, notice: null };
  }
  const gated = { ...settings };
  if (languageBlocked) {
    gated.moonshine = { ...settings.moonshine, language: "en", modelArch: defaultArchFor("en") };
    gated.whisper = { ...settings.whisper, language: "en" };
  }
  if (translationBlocked) {
    gated.translation = { ...settings.translation, provider: "chrome" };
  }
  const notice = regionBlocked ? languageBlocked ? HUNYUAN_REGION_LANGUAGE_NOTICE : HUNYUAN_REGION_NOTICE : languageBlocked && translationBlocked ? PRO_BOTH_GATE_NOTICE : languageBlocked ? PRO_GATE_NOTICE : PRO_TRANSLATION_GATE_NOTICE;
  return { settings: gated, blocked: true, notice };
}
export {
  FREE_ENTITLEMENT as F,
  TRIAL_DURATION_MS as T,
  entitlementIsStale as e,
  gateSettings as g,
  isProEntitlement as i,
  normalizeEntitlement as n
};
