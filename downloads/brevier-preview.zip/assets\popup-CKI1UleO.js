import { i as isProEntitlement } from "./entitlements-DGgOeOGB.js";
import { s as spokenLanguage, A as ARCH_META, i as isWhisperLanguage, g as getMoonshineLanguage, j as defaultArchFor, M as MOONSHINE_LANGUAGES, c as getModelChoice, k as PARAKEET_LANGUAGES, W as WHISPER_LANGUAGES, d as detectHunyuanRestricted } from "./region-C_na-waw.js";
import { u as updateSettings, l as loadSettings, c as PRO_ALLOWANCE_MS } from "./storage-BlCx6vQE.js";
import { p as probeChromeTranslation, a as prepareChromeTranslation, T as TRANSLATION_LANGUAGES } from "./translation-languages-BWIVOYyr.js";
function formatPlanPrice(plan) {
  const amount = plan.unitAmountCents / 100;
  try {
    return new Intl.NumberFormat(void 0, {
      style: "currency",
      currency: plan.currency
    }).format(amount);
  } catch {
    return `${plan.currency.toUpperCase()} ${amount.toFixed(2)}`;
  }
}
function formatPlanTerm(plan) {
  const unit = plan.interval === "year" ? "year" : plan.interval === "month" ? "month" : plan.interval === "week" ? "week" : plan.interval === "day" ? "day" : null;
  if (unit === null) return "one-time";
  const count = plan.intervalCount ?? 1;
  return count === 1 ? `per ${unit}` : `every ${count} ${unit}s`;
}
function element(id) {
  const found = document.getElementById(id);
  if (!found) throw new Error(`Missing element #${id}`);
  return found;
}
function setHidden(element2, hidden) {
  element2.classList.toggle("hidden", hidden);
}
class ChromeTranslationPanel {
  constructor(getSettings, notifySettingsChanged2) {
    this.getSettings = getSettings;
    this.notifySettingsChanged = notifySettingsChanged2;
    this.prepareButton.addEventListener("click", () => void this.prepare());
  }
  status = element("trChromeStatus");
  prepareButton = element("trPrepare");
  refresh() {
    void this.refreshAsync();
  }
  async refreshAsync() {
    const settings = this.getSettings();
    if (!settings || !settings.translation.enabled || settings.translation.provider !== "chrome") {
      return;
    }
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    if (source === target) {
      this.setStatus("Target language is the same as the spoken language.", false);
      return;
    }
    const availability = await probeChromeTranslation(source, target);
    switch (availability) {
      case "unsupported":
        this.setStatus(
          "Built-in translation is not available in this browser (needs desktop Chrome 138+).",
          false
        );
        break;
      case "unavailable":
        this.setStatus(`This device does not support translation ${source} → ${target}.`, false);
        break;
      case "available":
        this.setStatus(`On-device translation ready (${source} → ${target}).`, false);
        break;
      default:
        this.setStatus(`One-time model download needed (${source} → ${target}).`, true);
        break;
    }
  }
  async prepare() {
    const settings = this.getSettings();
    if (!settings) return;
    const source = spokenLanguage(settings);
    const target = settings.translation.targetLanguage;
    this.prepareButton.disabled = true;
    this.setStatus("Downloading translation model…", true);
    try {
      await prepareChromeTranslation(source, target, (fraction) => {
        this.status.textContent = `Downloading translation model… ${Math.round(fraction * 100)}%`;
      });
      await this.notifySettingsChanged();
      await this.refreshAsync();
    } catch (error) {
      this.status.textContent = error instanceof Error ? error.message : String(error);
    } finally {
      this.prepareButton.disabled = false;
    }
  }
  setStatus(text, showPrepare) {
    this.status.textContent = text;
    setHidden(this.prepareButton, !showPrepare);
  }
}
const ENGINE_INFO = {
  auto: {
    summary: "Picks the best engine for this machine — nothing to configure.",
    facts: [
      { label: "English", value: "Parakeet on a GPU — fastest, live text almost instantly" },
      { label: "Other languages", value: "Whisper on a GPU; Moonshine on CPU-only machines" },
      { label: "Fallback", value: "switches engines automatically if one cannot load" },
      { label: "Privacy", value: "audio never leaves this machine" }
    ]
  },
  parakeet: {
    summary: "Fastest English captions, with top-tier accuracy.",
    facts: [
      { label: "GPU", value: "required (WebGPU)" },
      { label: "Language", value: "English only" },
      { label: "Download", value: "about 640 MB once, then cached" },
      {
        label: "Speed",
        value: "live text while you speak — a partial caption takes tens of milliseconds, and the final line lands as soon as the sentence ends"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  },
  moonshine: {
    summary: "Runs on your CPU — uses your GPU when one is available.",
    facts: [
      { label: "GPU", value: "used when available for tiny/base models, otherwise CPU" },
      { label: "Languages", value: "6" },
      { label: "Download", value: "44–305 MB once, then cached" },
      { label: "Privacy", value: "audio never leaves this machine" }
    ]
  },
  whisper: {
    summary: "Most accurate, but needs a GPU.",
    facts: [
      { label: "GPU", value: "required (WebGPU)" },
      { label: "Languages", value: "99 — pick the spoken one above" },
      { label: "Download", value: "about 1.5 GB once, then cached" },
      {
        label: "Speed",
        value: "live text about two seconds after speech starts; a reasonably fast GPU is recommended — weak integrated GPUs may lag behind speech"
      },
      { label: "Privacy", value: "runs on-device" }
    ]
  }
};
const TRANSLATION_INFO = {
  hunyuan: {
    summary: "Highest-quality on-device translation, but heavy.",
    facts: [
      { label: "Plan", value: "Pro (one-time purchase)" },
      { label: "GPU", value: "required (WebGPU)" },
      { label: "Model", value: "Hunyuan-MT 1.5 (1.8B, q4)" },
      { label: "Download", value: "about 1.3 GB once, then cached" },
      {
        label: "Speed",
        value: "slow — can lag behind speech even on a GPU; a discrete GPU is strongly recommended"
      },
      { label: "Tip", value: "switch to Google Translate (Chrome) if it is too slow" },
      {
        label: "License",
        value: "Tencent HY Community License — not affiliated with or endorsed by Tencent; not licensed for use in the EU, UK or South Korea"
      }
    ]
  },
  chrome: {
    summary: "Instant translation on your CPU — no GPU needed.",
    facts: [
      { label: "Plan", value: "Free" },
      { label: "GPU", value: "not needed" },
      { label: "Download", value: "small language pack per language pair, once" },
      { label: "Speed", value: "instant; the lightest option for slower machines" },
      { label: "Requires", value: "desktop Chrome 138 or newer" }
    ]
  }
};
function moonshineModelInfo(arch, model) {
  const streaming = arch.endsWith("_streaming");
  return {
    summary: ARCH_META[arch].blurb,
    facts: [
      { label: "Download", value: `~${model.sizeMB} MB once, then cached` },
      {
        label: "Live text",
        value: streaming ? "yes — text updates while you speak" : "no — lines appear when a sentence completes"
      },
      { label: "GPU", value: "not needed (runs on your CPU)" }
    ]
  };
}
function renderFacts(container, block) {
  const summary = document.createElement("p");
  summary.className = "info-summary";
  summary.textContent = block.summary;
  const list = document.createElement("ul");
  list.className = "info-list";
  for (const fact of block.facts) {
    const item = document.createElement("li");
    const label = document.createElement("strong");
    label.textContent = `${fact.label}:`;
    item.append(label, document.createTextNode(` ${fact.value}`));
    list.append(item);
  }
  container.replaceChildren(summary, list);
}
class SettingsForm {
  constructor(host) {
    this.host = host;
    this.engine.addEventListener("change", () => {
      const engine = this.engine.value;
      const patch = { engine };
      if (engine !== "moonshine" && this.current) {
        const spoken = spokenLanguage(this.current);
        if (isWhisperLanguage(spoken)) patch.whisper = { language: spoken };
      }
      void this.host.applyPatch(patch);
    });
    this.language.addEventListener("change", () => {
      if (this.lockedLanguage(this.language.value)) {
        this.host.onProRequired("language");
        if (this.current) this.render(this.current);
        return;
      }
      if (this.current?.engine === "moonshine") {
        const language = getMoonshineLanguage(this.language.value);
        void this.host.applyPatch({
          moonshine: { language: language.code, modelArch: defaultArchFor(language.code) }
        });
        return;
      }
      void this.host.applyPatch({ whisper: { language: this.language.value } });
    });
    this.model.addEventListener("change", () => {
      void this.host.applyPatch({ moonshine: { modelArch: this.model.value } });
    });
    this.trEnabled.addEventListener("change", () => {
      void this.host.applyPatch({ translation: { enabled: this.trEnabled.checked } });
    });
    this.trProvider.addEventListener("change", () => {
      if (!this.host.isHunyuanAllowed() && this.trProvider.value === "hunyuan") {
        if (this.current) this.render(this.current);
        return;
      }
      if (this.trProvider.value === "hunyuan" && !this.host.isPro()) {
        this.host.onProRequired("translation");
        if (this.current) this.render(this.current);
        return;
      }
      void this.host.applyPatch({
        translation: { provider: this.trProvider.value }
      });
    });
    this.trTarget.addEventListener("change", () => {
      void this.host.applyPatch({ translation: { targetLanguage: this.trTarget.value } });
    });
    this.trDisplay.addEventListener("change", () => {
      void this.host.applyPatch({
        translation: { display: this.trDisplay.value }
      });
    });
    this.fontSize.addEventListener("input", () => {
      this.fontSizeOut.textContent = `${this.fontSize.value}px`;
      void this.host.applyPatch(
        { overlay: { fontSize: Number(this.fontSize.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.maxLines.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { maxLines: Number(this.maxLines.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.position.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { position: this.position.value } },
        { skipLanguageRefresh: true }
      );
    });
    this.offset.addEventListener("input", () => {
      this.offsetOut.textContent = `${this.offset.value}px`;
      void this.host.applyPatch(
        { overlay: { offset: Number(this.offset.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.opacity.addEventListener("input", () => {
      this.opacityOut.textContent = `${Math.round(Number(this.opacity.value) * 100)}%`;
      void this.host.applyPatch(
        { overlay: { opacity: Number(this.opacity.value) } },
        { skipLanguageRefresh: true }
      );
    });
    this.showInterim.addEventListener("change", () => {
      void this.host.applyPatch(
        { overlay: { showInterim: this.showInterim.checked } },
        { skipLanguageRefresh: true }
      );
    });
    renderFacts(this.trHunyuanInfo, TRANSLATION_INFO.hunyuan);
    renderFacts(this.trChromeInfo, TRANSLATION_INFO.chrome);
  }
  engine = element("engine");
  language = element("language");
  engineNote = element("engineNote");
  modelDetails = element("modelDetails");
  model = element("model");
  modelBlurb = element("modelBlurb");
  translationBody = element("translationBody");
  trEnabled = element("trEnabled");
  trProvider = element("trProvider");
  trProviderHunyuan = element("trProviderHunyuan");
  trTarget = element("trTarget");
  trDisplay = element("trDisplay");
  trHunyuanBox = element("trHunyuanBox");
  trHunyuanInfo = element("trHunyuanInfo");
  trChromeBox = element("trChromeBox");
  trChromeInfo = element("trChromeInfo");
  trRegionNote = element("trRegionNote");
  fontSize = element("fontSize");
  fontSizeOut = element("fontSizeOut");
  maxLines = element("maxLines");
  position = element("position");
  offset = element("offset");
  offsetOut = element("offsetOut");
  opacity = element("opacity");
  opacityOut = element("opacityOut");
  showInterim = element("showInterim");
  current = null;
  /** Last settings snapshot handed to `render`; null before the first render. */
  get settings() {
    return this.current;
  }
  render(settings) {
    this.current = settings;
    this.engine.value = settings.engine;
    renderFacts(this.engineNote, ENGINE_INFO[settings.engine]);
    setHidden(this.modelDetails, settings.engine !== "moonshine");
    this.renderLanguageOptions(settings);
    this.renderModelOptions(settings.moonshine.language, settings.moonshine.modelArch);
    this.renderTranslation(settings);
    this.renderOverlay(settings);
    this.host.onRendered(settings);
  }
  renderLanguageOptions(settings) {
    const selected = spokenLanguage(settings);
    this.language.replaceChildren();
    let options;
    if (settings.engine === "moonshine") {
      options = MOONSHINE_LANGUAGES.map((language) => ({
        code: language.code,
        name: language.name
      }));
    } else if (settings.engine === "parakeet") {
      options = PARAKEET_LANGUAGES;
    } else {
      options = WHISPER_LANGUAGES;
    }
    for (const option of options) {
      const item = document.createElement("option");
      item.value = option.code;
      item.textContent = this.lockedLanguage(option.code) ? `${option.name} — Pro` : option.name;
      item.selected = option.code === selected;
      this.language.append(item);
    }
  }
  /** Languages other than English are part of Pro. */
  lockedLanguage(code) {
    return code !== "en" && !this.host.isPro();
  }
  /** Hunyuan-MT is part of Pro; Chrome translation is free. */
  lockedProvider(provider) {
    return provider === "hunyuan" && !this.host.isPro();
  }
  renderModelOptions(languageCode, selectedArch) {
    const language = getMoonshineLanguage(languageCode);
    this.model.replaceChildren();
    for (const model of language.models) {
      const option = document.createElement("option");
      option.value = model.arch;
      option.textContent = `${ARCH_META[model.arch].label} — ~${model.sizeMB} MB${model.default ? " (default)" : ""}`;
      option.selected = model.arch === selectedArch;
      this.model.append(option);
    }
    const chosen = getModelChoice(languageCode, selectedArch);
    renderFacts(this.modelBlurb, moonshineModelInfo(chosen.arch, chosen));
  }
  renderTranslation(settings) {
    this.trEnabled.checked = settings.translation.enabled;
    setHidden(this.translationBody, !settings.translation.enabled);
    const hunyuanAllowed2 = this.host.isHunyuanAllowed();
    if (hunyuanAllowed2) {
      this.trProviderHunyuan.disabled = false;
      this.trProviderHunyuan.textContent = this.lockedProvider("hunyuan") ? "Hunyuan-MT — best quality (GPU) — Pro" : "Hunyuan-MT — best quality (GPU)";
    } else {
      this.trProviderHunyuan.disabled = true;
      this.trProviderHunyuan.textContent = "Hunyuan-MT — not available in your region";
    }
    const provider = settings.translation.provider === "hunyuan" && !hunyuanAllowed2 ? "chrome" : settings.translation.provider;
    this.trProvider.value = provider;
    this.renderTranslationLanguages(settings.translation.targetLanguage);
    this.trDisplay.value = settings.translation.display;
    setHidden(this.trHunyuanBox, provider !== "hunyuan");
    setHidden(this.trChromeBox, provider !== "chrome");
    setHidden(this.trRegionNote, hunyuanAllowed2);
  }
  renderTranslationLanguages(selected) {
    this.trTarget.replaceChildren();
    const languages = [...TRANSLATION_LANGUAGES];
    if (!languages.some((language) => language.code === selected)) {
      languages.unshift({ code: selected, name: selected });
    }
    for (const language of languages) {
      const option = document.createElement("option");
      option.value = language.code;
      option.textContent = language.name;
      option.selected = language.code === selected;
      this.trTarget.append(option);
    }
  }
  renderOverlay(settings) {
    this.fontSize.value = String(settings.overlay.fontSize);
    this.fontSizeOut.textContent = `${settings.overlay.fontSize}px`;
    this.maxLines.value = String(settings.overlay.maxLines);
    this.position.value = settings.overlay.position;
    this.offset.value = String(settings.overlay.offset);
    this.offsetOut.textContent = `${settings.overlay.offset}px`;
    this.opacity.value = String(settings.overlay.opacity);
    this.opacityOut.textContent = `${Math.round(settings.overlay.opacity * 100)}%`;
    this.showInterim.checked = settings.overlay.showInterim;
  }
}
const TICK_MS = 1e3;
const STALE_AFTER_MS = 2e4;
class StatusView {
  dot = element("statusDot");
  statusText = element("statusText");
  gateNote = element("gateNote");
  staleWarning = element("staleWarning");
  activity = element("activity");
  progressWrap = element("progressWrap");
  progressBar = element("progressBar");
  progressText = element("progressText");
  toggle = element("toggle");
  translationRuntime = element("trRuntime");
  state = null;
  lastStateAt = 0;
  constructor() {
    window.setInterval(() => this.tick(), TICK_MS);
  }
  get capturing() {
    return this.state?.capturing ?? false;
  }
  /** Surfaces a transport-level failure (e.g. messaging the service worker). */
  showError(message) {
    this.statusText.textContent = message;
  }
  render(incoming) {
    const state = {
      ...incoming,
      audioLevel: typeof incoming.audioLevel === "number" ? incoming.audioLevel : 0,
      captionCount: typeof incoming.captionCount === "number" ? incoming.captionCount : 0,
      lastCaptionAt: typeof incoming.lastCaptionAt === "number" ? incoming.lastCaptionAt : null,
      translationStatus: incoming.translationStatus ?? "off",
      translationDetail: typeof incoming.translationDetail === "string" ? incoming.translationDetail : ""
    };
    this.state = state;
    this.lastStateAt = Date.now();
    setHidden(this.staleWarning, true);
    this.renderActivity();
    this.renderTranslationRuntime(state);
    this.statusText.textContent = state.error ?? state.detail;
    this.dot.className = `dot ${state.status}`;
    const gateNotice = typeof state.gateNotice === "string" ? state.gateNotice : "";
    this.gateNote.textContent = gateNotice;
    setHidden(this.gateNote, gateNotice === "");
    this.toggle.textContent = state.capturing ? "Stop captions" : "Start captions";
    this.toggle.classList.toggle("stop", state.capturing);
    this.renderProgress(state);
  }
  /**
   * The offscreen pipeline sends a heartbeat every few seconds while loading,
   * so a long silence means the document was torn down or the engine wedged.
   */
  tick() {
    const state = this.state;
    if (!state) return;
    const loading = state.status === "loading" || state.status === "starting";
    const stale = state.capturing && loading && Date.now() - this.lastStateAt > STALE_AFTER_MS;
    setHidden(this.staleWarning, !stale);
    this.renderActivity();
  }
  renderActivity() {
    const state = this.state;
    if (!state?.capturing) {
      setHidden(this.activity, true);
      return;
    }
    setHidden(this.activity, false);
    const level = typeof state.audioLevel === "number" ? state.audioLevel : 0;
    const audio = level < 3e-3 ? "no audio" : "audio";
    const last = state.lastCaptionAt ? `${Math.max(0, Math.round((Date.now() - state.lastCaptionAt) / 1e3))}s ago` : "—";
    this.activity.textContent = `${audio} ${level.toFixed(3)} · captions ${state.captionCount ?? 0} · last ${last}`;
    this.activity.classList.toggle(
      "warn",
      level < 3e-3 && state.captionCount === 0 && state.status === "ready"
    );
  }
  renderTranslationRuntime(state) {
    if (!state.capturing || state.translationStatus === "off") {
      setHidden(this.translationRuntime, true);
      return;
    }
    setHidden(this.translationRuntime, false);
    this.translationRuntime.classList.toggle("warn", state.translationStatus === "error");
    this.translationRuntime.textContent = state.translationDetail || "Translation";
  }
  renderProgress(state) {
    const showProgress = Boolean(state.progress) || state.status === "loading" || state.status === "starting";
    setHidden(this.progressWrap, !showProgress);
    if (state.progress) {
      const { loaded, total, file } = state.progress;
      if (total && total > 0) {
        const percent = Math.min(100, Math.round(loaded / total * 100));
        this.progressWrap.classList.remove("indeterminate");
        this.progressBar.style.width = `${percent}%`;
        this.progressText.textContent = `${percent}% · ${file}`;
      } else {
        this.progressWrap.classList.add("indeterminate");
        this.progressText.textContent = file;
      }
      setHidden(this.progressText, false);
    } else {
      this.progressWrap.classList.toggle("indeterminate", showProgress);
      setHidden(this.progressText, true);
    }
  }
}
const status = new StatusView();
const toggle = element("toggle");
const tabNote = element("tabNote");
const diagnostics = element("diagnostics");
const notices = element("notices");
const proCard = element("proCard");
const proHeading = element("proHeading");
const proState = element("proState");
const proInfo = element("proInfo");
const proAllowance = element("proAllowance");
const proPlans = element("proPlans");
const proBuy = element("proBuy");
const proLogin = element("proLogin");
let entitlement = null;
let allowanceMsLeft = null;
let plans = [];
const hunyuanAllowed = !detectHunyuanRestricted();
function isPro() {
  return entitlement !== null && isProEntitlement(entitlement);
}
async function loadEntitlement() {
  try {
    const response = await chrome.runtime.sendMessage({
      type: "popup:get-entitlement"
    });
    if (response?.entitlement) entitlement = response.entitlement;
    if (response) {
      allowanceMsLeft = typeof response.proAllowanceMsLeft === "number" ? response.proAllowanceMsLeft : null;
      plans = Array.isArray(response.plans) ? response.plans : [];
    }
  } catch {
  }
  renderProCard();
}
function renderAllowance() {
  if (allowanceMsLeft === null) {
    setHidden(proAllowance, true);
    return;
  }
  setHidden(proAllowance, false);
  const minutes = Math.ceil(allowanceMsLeft / 6e4);
  proAllowance.textContent = minutes > 0 ? `Free Pro time left today: ${minutes} min — resets at midnight.` : "Free Pro time is used up for today — it resets at midnight.";
}
function renderPlans() {
  proPlans.replaceChildren();
  for (const plan of plans) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "pro-plan";
    const price = document.createElement("strong");
    price.className = "pro-plan-price";
    price.textContent = formatPlanPrice(plan);
    const term = document.createElement("span");
    term.className = "pro-plan-term";
    term.textContent = formatPlanTerm(plan);
    button.append(price, term);
    button.addEventListener(
      "click",
      () => openPurchasePage({ type: "popup:open-upgrade", plan: plan.nickname ?? void 0 })
    );
    proPlans.append(button);
  }
  setHidden(proPlans, plans.length === 0);
}
function renderProCard() {
  const pro = isPro();
  setHidden(proCard, false);
  proCard.classList.toggle("is-pro", pro);
  if (pro) {
    proHeading.textContent = "Pro";
    proState.textContent = entitlement?.status === "trial" ? "Trial" : "Unlocked";
    setHidden(proInfo, true);
    setHidden(proAllowance, true);
    setHidden(proPlans, true);
    setHidden(proBuy, true);
    setHidden(proLogin, true);
    return;
  }
  proHeading.textContent = "Unlock Pro";
  proState.textContent = "";
  proInfo.textContent = hunyuanAllowed ? "All languages + Hunyuan-MT translation." : "All 99 languages, transcribed on-device.";
  setHidden(proInfo, false);
  renderAllowance();
  renderPlans();
  setHidden(proBuy, plans.length > 0);
  setHidden(proLogin, false);
}
function onProRequired(kind) {
  if (isPro()) return;
  const minutes = PRO_ALLOWANCE_MS / 6e4;
  proInfo.textContent = kind === "translation" ? `Hunyuan-MT translation is part of Pro — you get ${minutes} free Pro minutes a day, or unlock unlimited with one payment.` : `That language is part of Pro — you get ${minutes} free Pro minutes a day, or unlock unlimited with one payment.`;
  setHidden(proInfo, false);
  proCard.scrollIntoView({ block: "nearest" });
  const firstPlan = proPlans.classList.contains("hidden") ? null : proPlans.querySelector(".pro-plan");
  (firstPlan ?? proBuy).focus();
}
function openPurchasePage(request) {
  void chrome.runtime.sendMessage(request).then((response) => {
    const result = response;
    if (result && result.ok === false && result.error) {
      proInfo.textContent = result.error;
      setHidden(proInfo, false);
      proCard.scrollIntoView({ block: "nearest" });
    }
  }).catch((error) => {
    console.error("[brevier] purchase message failed", error);
    proInfo.textContent = "Could not reach the extension service worker. Reload the extension on chrome://extensions and try again.";
    setHidden(proInfo, false);
    proCard.scrollIntoView({ block: "nearest" });
  });
}
async function notifySettingsChanged() {
  try {
    await chrome.runtime.sendMessage({ type: "popup:settings-changed" });
  } catch {
  }
}
const form = new SettingsForm({
  applyPatch: async (patch, options) => {
    const settings = await updateSettings(patch);
    if (!options?.skipLanguageRefresh) {
      form.render(settings);
    }
    await notifySettingsChanged();
  },
  onRendered: () => chromeTranslation.refresh(),
  isPro,
  isHunyuanAllowed: () => hunyuanAllowed,
  onProRequired
});
const chromeTranslation = new ChromeTranslationPanel(
  () => form.settings,
  notifySettingsChanged
);
function applyState(state) {
  status.render(state);
  const left = typeof state.proAllowanceMsLeft === "number" ? state.proAllowanceMsLeft : null;
  if (left !== allowanceMsLeft) {
    allowanceMsLeft = left;
    renderProCard();
  }
}
toggle.addEventListener("click", () => {
  const capturing = status.capturing;
  toggle.disabled = true;
  void chrome.runtime.sendMessage({ type: capturing ? "popup:stop" : "popup:start" }).then((response) => {
    const state = response?.state;
    if (state) applyState(state);
  }).catch((error) => {
    status.showError(error instanceof Error ? error.message : String(error));
  }).finally(() => {
    toggle.disabled = false;
  });
});
diagnostics.addEventListener("click", () => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("debug/debug.html") });
});
notices.addEventListener("click", () => {
  void chrome.tabs.create({ url: chrome.runtime.getURL("notices.html") });
});
proBuy.addEventListener("click", () => openPurchasePage({ type: "popup:open-upgrade" }));
proLogin.addEventListener("click", () => openPurchasePage({ type: "popup:open-login" }));
chrome.runtime.onMessage.addListener((message) => {
  if (typeof message === "object" && message !== null && message.type === "bg:state") {
    applyState(message.state);
  }
});
const INTERNAL_TAB = /^(chrome|chrome-extension|chrome-untrusted|devtools|edge|about|view-source):/i;
async function checkCapturableTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    const url = tab?.url ?? tab?.pendingUrl ?? "";
    const internal = url !== "" && INTERNAL_TAB.test(url);
    setHidden(tabNote, !internal);
  } catch {
    setHidden(tabNote, true);
  }
}
async function init() {
  proBuy.textContent = hunyuanAllowed ? "Unlock languages + Hunyuan-MT" : "Unlock 99 languages";
  await loadEntitlement();
  let settings = await loadSettings();
  if (!hunyuanAllowed && settings.translation.provider === "hunyuan") {
    settings = await updateSettings({ translation: { provider: "chrome" } });
    await notifySettingsChanged();
  }
  form.render(settings);
  void checkCapturableTab();
  try {
    const response = await chrome.runtime.sendMessage({
      type: "popup:get-state"
    });
    if (response?.state) applyState(response.state);
  } catch {
  }
}
void init();
