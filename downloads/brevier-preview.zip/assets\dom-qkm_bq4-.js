function element(id) {
  const found = document.getElementById(id);
  if (!found) throw new Error(`Missing element #${id}`);
  return found;
}
function setHidden(element2, hidden) {
  element2.classList.toggle("hidden", hidden);
}
export {
  element as e,
  setHidden as s
};
