import { u as SUPPORTED_LANGUAGES, x as PARAKEET_TDT_LANGUAGE_CODES, d as PARAKEET_TDT_MODEL, P as PARAKEET_JA_MODEL, Q as QWEN_MODEL, n as supportsQwenLanguage, m as supportsParakeetTdtLanguage, y as supportsParakeetLanguage, q as qwenModelFor } from "./settings-DWyWJaRh.js";
import { t as translationLanguageName } from "./translation-languages-DuT0gDGk.js";
const MEASURED_TDT_LANGUAGES = /* @__PURE__ */ new Set(["en", "de", "fr", "es", "it"]);
const BEST_MODEL_BY_LANGUAGE = SUPPORTED_LANGUAGES.map((language) => {
  if (PARAKEET_TDT_LANGUAGE_CODES.includes(language.code)) {
    return {
      code: language.code,
      name: language.name,
      engine: "parakeet-tdt",
      model: PARAKEET_TDT_MODEL.id,
      sizeMB: PARAKEET_TDT_MODEL.sizeMB,
      evidence: MEASURED_TDT_LANGUAGES.has(language.code) ? "measured" : "catalog"
    };
  }
  if (language.code === "ja") {
    return {
      code: language.code,
      name: language.name,
      engine: "parakeet",
      model: PARAKEET_JA_MODEL.id,
      sizeMB: PARAKEET_JA_MODEL.sizeMB,
      evidence: "measured"
    };
  }
  return {
    code: language.code,
    name: language.name,
    engine: "qwen",
    model: QWEN_MODEL.id,
    sizeMB: QWEN_MODEL.sizeMB,
    evidence: "catalog"
  };
});
function bestModelFor(code) {
  return BEST_MODEL_BY_LANGUAGE.find((entry) => entry.code === code);
}
function autoEngineOrder(language) {
  const primary = bestModelFor(language)?.engine;
  const candidates = primary ? [primary, "qwen", "parakeet-tdt", "parakeet"] : ["qwen", "parakeet-tdt", "parakeet"];
  const order = [];
  for (const id of candidates) {
    if (order.includes(id)) continue;
    if (id === "qwen" && !supportsQwenLanguage(language)) continue;
    if (id === "parakeet-tdt" && !supportsParakeetTdtLanguage(language)) continue;
    if (id === "parakeet" && !supportsParakeetLanguage(language)) continue;
    order.push(id);
  }
  return order;
}
const STUDIO_QWEN_MODEL = "1.7b";
const STUDIO_QWEN_FALLBACK_MODEL = "0.6b";
function studioEngineOrder(language, preferSmall = false, preferred) {
  const qwenModels = preferSmall ? [STUDIO_QWEN_FALLBACK_MODEL] : [STUDIO_QWEN_MODEL, STUDIO_QWEN_FALLBACK_MODEL];
  const order = supportsQwenLanguage(language) ? qwenModels.map((qwenModel) => ({ id: "qwen", qwenModel })) : [];
  for (const id of autoEngineOrder(language)) {
    if (id === "qwen" && order.some((candidate) => candidate.id === "qwen")) continue;
    order.push({ id });
  }
  if (!preferred) return order;
  const index = order.findIndex(
    (candidate) => candidate.id === preferred.id && (candidate.id !== "qwen" || candidate.qwenModel === preferred.qwenModel)
  );
  if (index <= 0) return order;
  return [order[index], ...order.slice(0, index), ...order.slice(index + 1)];
}
function engineConfig(id, settings, options = {}) {
  switch (id) {
    case "qwen": {
      const model = qwenModelFor(options.qwenModel ?? settings.qwenModel);
      return {
        label: `Qwen3-ASR ${model.label}`,
        model: model.id,
        family: "qwen",
        language: settings.language,
        sizeMB: model.sizeMB
      };
    }
    case "parakeet-tdt":
      return {
        label: "Parakeet TDT",
        model: PARAKEET_TDT_MODEL.id,
        family: "parakeet-tdt",
        sizeMB: PARAKEET_TDT_MODEL.sizeMB,
        cpuSizeMB: PARAKEET_TDT_MODEL.cpuSizeMB
      };
    case "parakeet":
      return {
        label: "Parakeet Japanese",
        model: PARAKEET_JA_MODEL.id,
        family: "parakeet",
        dtype: PARAKEET_JA_MODEL.dtype,
        sizeMB: PARAKEET_JA_MODEL.sizeMB,
        cpuSizeMB: PARAKEET_JA_MODEL.cpuSizeMB,
        cpuDtype: PARAKEET_JA_MODEL.cpuDtype
      };
    default: {
      const exhaustive = id;
      return exhaustive;
    }
  }
}
const STOP_TIMEOUT_MS = 3e4;
const INIT_STALL_MS$1 = 12e4;
const BATCH_FLUSH_TIMEOUT_MS = 10 * 6e4;
let lineSessionCounter = 0;
class GpuAsrEngine {
  constructor(id, resolveConfig) {
    this.resolveConfig = resolveConfig;
    this.id = id;
  }
  id;
  worker = null;
  context = null;
  ready = false;
  disposed = false;
  label = "";
  pendingInit = null;
  initTimer = null;
  linePrefix = String(++lineSessionCounter);
  stopWaiters = /* @__PURE__ */ new Map();
  batchWaiters = /* @__PURE__ */ new Map();
  nextStopId = 1;
  nextBatchId = 1;
  batchMode = false;
  initialize(context) {
    return this.startWorker(context, false);
  }
  /**
   * Loads the same worker in whole-file mode. Batch mode disables interims and
   * every lossy live-stream queue rule; the caller feeds chunks and awaits
   * flushBatch() before sending the next one.
   */
  initializeBatch(context) {
    return this.startWorker(context, true);
  }
  async startWorker(context, batchMode) {
    this.context = context;
    this.disposed = false;
    this.batchMode = batchMode;
    const config = this.resolveConfig(context);
    this.label = config.label;
    context.events.onStatus("loading", `Preparing ${config.label}…`);
    const worker = new Worker(new URL(
      /* @vite-ignore */
      "/assets/worker-B45FG2-j.js",
      import.meta.url
    ), {
      type: "module"
    });
    this.worker = worker;
    worker.onmessage = (event) => this.handleMessage(event.data);
    worker.onerror = (event) => {
      const error = new Error(event.message || `The ${config.label} worker failed to load.`);
      const pending = this.pendingInit;
      if (pending) {
        this.pendingInit = null;
        this.clearInitTimer();
        pending.reject(error);
        return;
      }
      if (this.batchMode) {
        this.ready = false;
        this.rejectBatchWaiters(error);
        this.settleStopWaiters(error);
        try {
          worker.terminate();
        } catch {
        }
        this.worker = null;
      }
      context.events.onError(error);
    };
    const ortWasmBaseUrl = new URL("/ort/", globalThis.location?.href ?? "http://localhost/").href;
    try {
      await new Promise((resolve, reject) => {
        const id = 1;
        this.pendingInit = { resolve, reject };
        this.armInitTimeout();
        worker.postMessage({
          type: "init",
          id,
          mode: batchMode ? "batch" : "live",
          language: config.language,
          family: config.family,
          label: config.label,
          model: config.model,
          dtype: config.dtype,
          sizeMB: config.sizeMB,
          cpuSizeMB: config.cpuSizeMB,
          cpuDtype: config.cpuDtype,
          linePrefix: this.linePrefix,
          ortWasmBaseUrl
        });
      });
    } finally {
      this.clearInitTimer();
    }
    if (this.disposed) {
      throw new Error("The engine stopped before it finished loading.");
    }
    this.ready = true;
  }
  start() {
    return Promise.resolve();
  }
  pushAudio(samples, sampleRate) {
    if (!this.worker || !this.ready) return;
    this.worker.postMessage({ type: "audio", samples, sampleRate });
  }
  /** Batch-only audio feed; use flushBatch() before the next chunk. */
  pushBatchAudio(samples, sampleRate) {
    if (!this.worker || !this.ready || !this.batchMode) {
      throw new Error("The file transcription engine is not ready.");
    }
    this.worker.postMessage({ type: "batch-audio", samples, sampleRate });
  }
  /** Waits until the worker has decoded every full utterance fed so far. */
  flushBatch() {
    const worker = this.worker;
    if (!worker || !this.ready || !this.batchMode) {
      return Promise.reject(new Error("The file transcription engine is not ready."));
    }
    return new Promise((resolve, reject) => {
      const id = this.nextBatchId++;
      const timer = setTimeout(() => {
        this.batchWaiters.delete(id);
        reject(new Error("File transcription timed out while decoding a chunk."));
      }, BATCH_FLUSH_TIMEOUT_MS);
      this.batchWaiters.set(id, {
        resolve: (processedSamples) => {
          clearTimeout(timer);
          resolve(processedSamples);
        },
        reject: (error) => {
          clearTimeout(timer);
          reject(error);
        }
      });
      worker.postMessage({ type: "batch-flush", id });
    });
  }
  stop() {
    const worker = this.worker;
    if (!worker || !this.ready) {
      return this.batchMode ? Promise.reject(new Error("The file transcription engine is not ready.")) : Promise.resolve();
    }
    const batch = this.batchMode;
    return new Promise((resolve, reject) => {
      const id = this.nextStopId++;
      const timer = setTimeout(() => {
        this.stopWaiters.delete(id);
        if (batch) {
          reject(new Error("File transcription timed out while finishing the last lines."));
        } else {
          resolve();
        }
      }, batch ? BATCH_FLUSH_TIMEOUT_MS : STOP_TIMEOUT_MS);
      this.stopWaiters.set(id, {
        resolve: () => {
          clearTimeout(timer);
          resolve();
        },
        reject: (error) => {
          clearTimeout(timer);
          reject(error);
        }
      });
      worker.postMessage({ type: "stop", id });
    });
  }
  dispose() {
    this.disposed = true;
    this.clearInitTimer();
    const pending = this.pendingInit;
    this.pendingInit = null;
    pending?.reject(new Error("The engine stopped before it finished loading."));
    this.rejectBatchWaiters(new Error("File transcription was cancelled."));
    this.settleStopWaiters(
      this.batchMode ? new Error("File transcription was cancelled.") : null
    );
    const worker = this.worker;
    this.worker = null;
    this.ready = false;
    try {
      worker?.terminate();
    } catch {
    }
    return Promise.resolve();
  }
  rejectBatchWaiters(error) {
    for (const waiter of this.batchWaiters.values()) waiter.reject(error);
    this.batchWaiters.clear();
  }
  /** `null` resolves the stop promises (live stop); an Error rejects them. */
  settleStopWaiters(error) {
    for (const waiter of this.stopWaiters.values()) {
      if (error === null) waiter.resolve();
      else waiter.reject(error);
    }
    this.stopWaiters.clear();
  }
  armInitTimeout() {
    this.clearInitTimer();
    this.initTimer = setTimeout(() => {
      this.initTimer = null;
      const pending = this.pendingInit;
      this.pendingInit = null;
      void this.dispose();
      pending?.reject(
        new Error(
          "The speech model stalled while loading. Check your connection and click Start again."
        )
      );
    }, INIT_STALL_MS$1);
  }
  clearInitTimer() {
    if (this.initTimer !== null) {
      clearTimeout(this.initTimer);
      this.initTimer = null;
    }
  }
  handleMessage(message) {
    if (this.disposed) return;
    switch (message.type) {
      case "ready":
        this.clearInitTimer();
        this.context?.events.onStatus("ready", `${this.label} ready`);
        this.context?.events.onProgress(null);
        this.pendingInit?.resolve();
        this.pendingInit = null;
        return;
      case "progress":
        if (this.pendingInit) this.armInitTimeout();
        this.context?.events.onProgress({
          loaded: message.fraction === null ? 0 : Math.round(message.fraction * 100),
          total: message.fraction === null ? null : 100,
          file: message.file || `${this.label} model`,
          model: message.model ?? this.label,
          sizeMB: message.sizeMB
        });
        return;
      case "caption":
        this.context?.events.onCaption({
          kind: message.kind ?? "final",
          text: message.text,
          at: Date.now(),
          ...message.lineId ? { lineId: message.lineId } : {},
          ...message.startSample !== void 0 ? { startSample: message.startSample, endSample: message.endSample } : {},
          ...message.pauseSamples !== void 0 ? { pauseSamples: message.pauseSamples } : {},
          ...message.provisional ? { provisional: true } : {}
        });
        return;
      case "batch-flushed": {
        const waiter = this.batchWaiters.get(message.id);
        if (waiter) {
          this.batchWaiters.delete(message.id);
          waiter.resolve(message.processedSamples);
        }
        return;
      }
      case "stopped": {
        const waiter = this.stopWaiters.get(message.id);
        if (waiter) {
          this.stopWaiters.delete(message.id);
          waiter.resolve();
        }
        return;
      }
      case "error": {
        const error = new Error(message.message);
        const batchWaiter = message.id === void 0 ? void 0 : this.batchWaiters.get(message.id);
        if (batchWaiter) {
          this.batchWaiters.delete(message.id);
          batchWaiter.reject(error);
          return;
        }
        const stopWaiter = message.id === void 0 ? void 0 : this.stopWaiters.get(message.id);
        if (stopWaiter) {
          this.stopWaiters.delete(message.id);
          if (this.batchMode) stopWaiter.reject(error);
          else stopWaiter.resolve();
          return;
        }
        if (message.id === void 0) {
          console.error("[brevier] ASR worker error", message.message);
          this.context?.events.onError(error);
          return;
        }
        this.clearInitTimer();
        this.pendingInit?.reject(error);
        this.pendingInit = null;
        return;
      }
    }
  }
}
const TRANSLATE_TIMEOUT_MS = 6e4;
const INIT_STALL_MS = 12e4;
const PROMPT_TIMEOUT_MS = 65e3;
class LocalLlmTranslationProvider {
  constructor(model) {
    this.model = model;
    this.id = model.providerId;
  }
  id;
  worker = null;
  context = null;
  pending = /* @__PURE__ */ new Map();
  /** Serializes generations so a slow line cannot stack up GPU work. */
  translateChain = Promise.resolve();
  nextId = 1;
  ready = false;
  prompt = "";
  contextPrompt = "";
  get available() {
    return this.worker !== null && this.ready;
  }
  async initialize(context) {
    this.context = context;
    if (context.sourceLanguage === context.targetLanguage) {
      throw new Error("The translation language is the same as the spoken language.");
    }
    const prompt = this.model.buildPrompt(context.targetLanguage);
    const contextPrompt = this.model.buildContextPrompt?.(context.targetLanguage) ?? "";
    const worker = new Worker(new URL(
      /* @vite-ignore */
      "/assets/translation-worker-D6JEWIAI.js",
      import.meta.url
    ), {
      type: "module"
    });
    this.worker = worker;
    worker.onmessage = (event) => this.handleMessage(event.data);
    worker.onerror = (event) => {
      this.ready = false;
      this.failAll(new Error(event.message || "The translation worker failed to load."));
    };
    const ortWasmBaseUrl = new URL("/ort/", globalThis.location?.href ?? "http://localhost/").href;
    await new Promise((resolve, reject) => {
      const id = this.nextId++;
      const pending = {
        resolve: () => {
          if (pending.timer !== null) clearTimeout(pending.timer);
          resolve();
        },
        reject,
        timer: null
      };
      const arm = () => {
        if (pending.timer !== null) clearTimeout(pending.timer);
        pending.timer = setTimeout(() => {
          this.pending.delete(id);
          this.dispose();
          reject(
            new Error(
              "The translation model stalled while loading. Check your connection and try again."
            )
          );
        }, INIT_STALL_MS);
      };
      pending.rearm = arm;
      this.pending.set(id, pending);
      arm();
      worker.postMessage({
        type: "init",
        id,
        repo: this.model.repo,
        prompt,
        ...contextPrompt ? { contextPrompt } : {},
        ortWasmBaseUrl
      });
    });
    this.prompt = prompt;
    this.contextPrompt = contextPrompt;
    this.ready = true;
  }
  /**
   * Reuses the loaded model for a new language pair. Only the instruction
   * prompt changes, so the int4 model and its WebGPU session stay warm.
   */
  async retarget(context) {
    if (!this.worker || !this.ready) {
      throw new Error("The on-device translation model is not ready.");
    }
    if (context.sourceLanguage === context.targetLanguage) {
      throw new Error("The translation language is the same as the spoken language.");
    }
    this.context = context;
    const prompt = this.model.buildPrompt(context.targetLanguage);
    const contextPrompt = this.model.buildContextPrompt?.(context.targetLanguage) ?? "";
    if (prompt === this.prompt && contextPrompt === this.contextPrompt) return;
    const id = this.nextId++;
    await new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error("Updating the translation prompt timed out."));
      }, PROMPT_TIMEOUT_MS);
      this.pending.set(id, { resolve: () => resolve(), reject, timer });
      this.worker?.postMessage({
        type: "set-prompt",
        id,
        prompt,
        ...contextPrompt ? { contextPrompt } : {}
      });
    });
    this.prompt = prompt;
    this.contextPrompt = contextPrompt;
  }
  translate(text, onPartial, context) {
    if (!this.worker || !this.ready) {
      return Promise.reject(new Error("The on-device translation model is not ready."));
    }
    const run = this.translateChain.then(
      () => this.requestTranslation(text, onPartial, context)
    );
    this.translateChain = run.catch(() => void 0);
    return run;
  }
  requestTranslation(text, onPartial, context) {
    if (!this.worker || !this.ready) {
      return Promise.reject(new Error("The on-device translation model is not ready."));
    }
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      const timer = setTimeout(() => {
        this.pending.delete(id);
        this.dispose();
        reject(new Error("The translation request timed out. Restarting translation…"));
      }, TRANSLATE_TIMEOUT_MS);
      this.pending.set(id, { resolve, reject, timer, onPartial });
      this.worker?.postMessage({
        type: "translate",
        id,
        text,
        ...context ? { context } : {}
      });
    });
  }
  dispose() {
    this.failAll(new Error("Translation stopped."));
    const worker = this.worker;
    this.worker = null;
    this.ready = false;
    try {
      worker?.terminate();
    } catch {
    }
  }
  handleMessage(message) {
    if (message.type === "progress") {
      for (const pending2 of this.pending.values()) pending2.rearm?.();
      this.context?.onProgress({
        fraction: message.fraction,
        detail: message.file ? `${this.model.label} · ${message.file}` : this.model.label
      });
      return;
    }
    if (message.type === "partial") {
      this.pending.get(message.id)?.onPartial?.(message.text);
      return;
    }
    const pending = this.pending.get(message.id);
    if (!pending) return;
    this.pending.delete(message.id);
    if (pending.timer !== null) clearTimeout(pending.timer);
    switch (message.type) {
      case "ready":
        this.context?.onProgress(null);
        pending.resolve("");
        break;
      case "prompt-set":
        pending.resolve("");
        break;
      case "result":
        pending.resolve(message.text);
        break;
      case "error":
        pending.reject(new Error(message.message));
        break;
    }
  }
  failAll(error) {
    for (const pending of this.pending.values()) {
      if (pending.timer !== null) clearTimeout(pending.timer);
      pending.reject(error);
    }
    this.pending.clear();
  }
}
function buildHyMtInstruction(targetLanguage) {
  return `Translate the following text into ${translationLanguageName(
    targetLanguage
  )}. Note that you should only output the translated result without any additional explanation:

`;
}
function buildHyMtContextInstruction(targetLanguage) {
  return `Refer to the information above and translate the following text into ${translationLanguageName(
    targetLanguage
  )}. Do not translate the context and do not add any explanation:

`;
}
const HYMT3_MODEL_ID = "konstbet/Hy-MT3-1.8B-ONNX";
function buildHymt3Prompt(targetLanguage) {
  return buildHyMtInstruction(targetLanguage);
}
function buildHymt3ContextPrompt(targetLanguage) {
  return buildHyMtContextInstruction(targetLanguage);
}
const HYMT3_MODEL = {
  providerId: "hymt3",
  repo: HYMT3_MODEL_ID,
  label: "Hy-MT3 1.8B",
  buildPrompt: buildHymt3Prompt,
  buildContextPrompt: buildHymt3ContextPrompt
};
class Hymt3TranslationProvider extends LocalLlmTranslationProvider {
  constructor() {
    super(HYMT3_MODEL);
  }
}
export {
  GpuAsrEngine as G,
  Hymt3TranslationProvider as H,
  autoEngineOrder as a,
  bestModelFor as b,
  engineConfig as e,
  studioEngineOrder as s
};
